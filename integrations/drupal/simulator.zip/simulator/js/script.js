(function (global) {
	"use strict";

	function ResultObserver() {}

	ResultObserver.field = function(name, value) {
		console.log(name + ' => ' + value);
		// do something when the value of the field has been changed
	}

	ResultObserver.button = function(name, what, f0r, uri) {
		console.log(name + ' => ' + what + ':' + f0r);
		// do something when the button has been clicked
	}

	global.ResultObserver = ResultObserver;
}(this));