(function (document, window) {
	'use strict';

	function manageColors() {
		var colorInputs = document.querySelectorAll("#edit-simulator-colors input[type='color']");
		if (null !== colorInputs) {
			colorInputs.forEach( function(color) {
				color.addEventListener('change', function(e) {
					this.nextElementSibling.textContent = this.value;
				});
				color.dispatchEvent(new Event('change'));
			});
		}
	}

	function manageAddingBootstrapClasses() {
		var addingBootstrap = document.querySelector("#edit-simulator-field-adding-bootstrap");
		if (null !== addingBootstrap) {
			addingBootstrap.addEventListener('change', function(e) {
				var bootstrapVersion = document.querySelector('.form-item-simulator-field-bootstrap-version');
				if (null !== bootstrapVersion){
					if (this.checked) {
						bootstrapVersion.classList.remove('simulator-settings-field-hidden');
					} else {
						bootstrapVersion.classList.add('simulator-settings-field-hidden');
					}
				}
			});
			addingBootstrap.dispatchEvent(new Event('change'));
		}
	}

	window.addEventListener('DOMContentLoaded', function(event) {
		manageColors();
		manageAddingBootstrapClasses();
	});

}(document, window));
