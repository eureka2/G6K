(function (document, window) {
	'use strict';

	function manageColors() {
		var colorInputs = document.querySelectorAll("#edit-simulator-colors input[type='color']");
		if (null !== colorInputs) {
			colorInputs.forEach( function(color) {
				color.addEventListener('change', function(e) {
					this.nextElementSibling.textContent = this.value;
				});
				color.dispatchEvent(new Event('change'));
			});
		}
	}

	function manageAddingBootstrapClasses() {
		var addingBootstrap = document.querySelector("#edit-simulator-field-adding-bootstrap");
		if (null !== addingBootstrap) {
			addingBootstrap.addEventListener('change', function(e) {
				var bootstrapVersion = document.querySelector('.form-item-simulator-field-bootstrap-version');
				var addingStyleSheet = document.querySelector('.form-item-simulator-field-adding-bootstrap-stylesheet');
				var addingLibrary = document.querySelector('.form-item-simulator-field-adding-bootstrap-library');
				var addingJQuery = document.querySelector('.form-item-simulator-field-adding-jquery-library');
				if (null !== bootstrapVersion){
					if (this.checked) {
						bootstrapVersion.classList.remove('simulator-settings-field-hidden');
						addingStyleSheet.classList.remove('simulator-settings-field-hidden');
						addingLibrary.classList.remove('simulator-settings-field-hidden');
						addingJQuery.classList.remove('simulator-settings-field-hidden');
					} else {
						bootstrapVersion.classList.add('simulator-settings-field-hidden');
						addingStyleSheet.classList.add('simulator-settings-field-hidden');
						addingLibrary.classList.add('simulator-settings-field-hidden');
						addingJQuery.classList.add('simulator-settings-field-hidden');
					}
				}
			});
			addingBootstrap.dispatchEvent(new Event('change'));
		}
	}

	window.addEventListener('DOMContentLoaded', function(event) {
		manageColors();
		manageAddingBootstrapClasses();
	});

}(document, window));
