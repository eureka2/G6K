<?php declare(strict_types=1);

/*
The MIT License (MIT)

Copyright (c) 2021 Jacques Archimède

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

namespace Drupal\simulator\Service;

class SimulatorAPIService {

	public function url($simulator = null, $baseUrl = null) {
		$this->check($simulator);
		if (null === $baseUrl) {
			$config = \Drupal::config('simulator.adminsettings');
			$baseUrl = $config->get('simulator_server_url');
		}
		$scheme = \Drupal::request()->getScheme();
		return preg_replace("/^https?/", $scheme, $baseUrl) . "/" . $simulator . "/api";
	}

	public function attributes(string $simulator = null) {
		$this->check($simulator);
		$url = \Drupal::service('simulator.api')->url($simulator) . '/json';
		[$ok, $api] = $this->fetch($url);
		if ($ok) {
			$api = json_decode($api, true);
			return $api['data']['attributes'];
		} else {
			return [ 'title' => $api ];
		}
	}

	public function simulators($baseUrl = null) {
		$url = \Drupal::service('simulator.api')->url('simulators', $baseUrl);
		[$ok, $api] = $this->fetch($url);
		$simulators = [];
		if ($ok) {
			$api = json_decode($api, true);
			$data = $api['included']['data'];
			foreach($data as $simu) {
				$simulators[] = $simu['id'];
			}
			return $simulators;
		}
		return false;
	}

	public function markup(string $simulator = null) {
		$this->check($simulator);
		$url = \Drupal::service('simulator.api')->url($simulator) . '/html';

		$config = \Drupal::config('simulator.adminsettings');

		$options = [
			'markup' => $config->get('simulator_server_url') ?? '', // 'fragment' or 'page'
			'primaryColor' => $config->get('simulator_primary_color') ?? '#2b4e6b', // optional
			'secondaryColor' => $config->get('simulator_secondary_color') ?? '#c0c0c0', // optional
			'fontFamily' => $config->get('simulator_field_font_family') ?? 'Arial, Verdana', // optional
			'fontSize' => $config->get('simulator_field_font_size') ?? '1em', // optional
			'breadcrumbColor' => $config->get('simulator_breadcrumb_color') ?? '#2b4e6b', // optional
			'tabColor' => $config->get('simulator_tab_color') ?? '#2b4e6b', // optional
			'globalErrorColor' => $config->get('simulator_global_error_color') ?? '#ff0000', // optional
			'globalWarningColor' => $config->get('simulator_global_warning_color') ?? '#800000', // optional
			'fieldErrorColor' => $config->get('simulator_field_error_color') ?? '#ff0000', // optional
			'fieldWarningColor' => $config->get('simulator_field_warning_color') ?? '#800000', // optional
		];
		if ($config->get ( 'simulator_field_adding_bootstrap' ) == 1) {
			$body['bootstrap'] = $config->get('simulator_field_bootstrap_version') ?? ''; // bootstrap version
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer = $config->get('simulator_field_observer' . $i) ?? '';
			if ($observer != '') {
				[$simu, $field] = explode(":", $observer);
				if ($simu == $simulator) {
					$body[$field] = 'ResultObserver.field';
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer = $config->get('simulator_button_observer' . $i) ?? '';
			if ($observer != '') {
				[$simu, $field] = explode(":", $observer);
				if ($simu == $simulator) {
					$body[$field] = 'ResultObserver.button';
				}
			}
		}
		[$ok, $markup] = $this->fetch($url, $options);
		return $markup;
	}

	protected function fetch(string $url, array $options = []) {
		try {
			$client = \Drupal::httpClient();
			$request = $client->request('POST', $url, [
				'form_params' => $options,
				'verify' => false
			]);
		}
		catch (\Exception $e){
			watchdog_exception('simulator', $e);
			return [false, "Oops, something went wrong.  Please try again later.  #:" . $e->getMessage()];
		}
		$statusCode = $request->getStatusCode();
		$response = $request->getBody()->getContents();
		return [$statusCode == 200, $response];
	}

	protected function check(&$simulator) {
		if ($simulator === null) {
			$currentUrl = \Drupal\Core\Url::fromRoute('<current>')->toString();
			$simulator = end(explode("/", $currentUrl));
		}
	}

}