<?php declare(strict_types=1);

/**
 * @file
 * Contains Drupal\simulator\Form\SimulatorSettingsForm.
 */

/*
The MIT License (MIT)

Copyright (c) 2021 Jacques Archimède

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

namespace Drupal\simulator\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Drupal\user\UserInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\Core\Path\CurrentPathStack;
use Symfony\Component\HttpFoundation\RequestStack;
use Drupal\user\UserAuth;

class SimulatorSettingsForm extends ConfigFormBase {

	/**
	 * Current Path Stack object.
	 *
	 * @var \Drupal\Core\Path\CurrentPathStack
	*/
	protected $currentPath;

	/**
	 * Request Path Stack object.
	 *
	 * @var \Symfony\Component\HttpFoundation\RequestStack
	 */
	protected $requestStack;

	/**
	 * UserAuth object.
	 *
	 * @var \Drupal\user\UserAuth
	*/
	protected $userAuth;

	/**
	 * Constructs a AccountSettingsTabForm object.
	 *
	 * @param \Drupal\Core\Path\CurrentPathStack $current_path
	 *   Current user.
	*/
	public function __construct(CurrentPathStack $current_path, RequestStack $request_stack, UserAuth $user_auth) {
		$this->currentPath = $current_path;
		$this->requestStack = $request_stack;
		$this->userAuth = $user_auth;
	}

	/**
	* {@inheritdoc}
	*/
	public static function create(ContainerInterface $container) {
		return new self(
			$container->get('path.current'),
			$container->get('request_stack'),
			$container->get('user.auth')
		);
	}

	/**
	 * {@inheritdoc}
	 */
	protected function getEditableConfigNames() {
		return [
			'simulator.adminsettings',
		];
	}

	/**
	 * {@inheritdoc}
	 */
	public function getFormId() {
		return 'simulator_form';
	}

	/**
	 * {@inheritdoc}
	 */
	public function buildForm(array $form, FormStateInterface $form_state) {
		$user = $this->currentUser();
		$current_path = explode('/', $this->currentPath->getPath());
		$roles = $user->getRoles();
		if(!in_array('administrator', $roles) && $current_path[2] != $user->id()) {
			throw new AccessDeniedHttpException();
		}
		$form['#attached']['library'][] = 'simulator/settings';

		$config = $this->config('simulator.adminsettings');
		$form['simulator_settings'] = [
			'#type' => 'container',
			'#default_tab' => 'edit-simulator_server',
		];
		$form['simulator_server'] = [
			'#type' => 'details',
			'#title' => $this->t('G6K API Server'),
			'#open' => true,
			'#group' => 'simulator_settings',
			'#tree' => false,
		];
		$form['simulator_server']['simulator_server_url'] = [
			'#type' => 'url',
			'#title' => $this->t('Base url of the server'),
			'#description' => $this->t('Enter the absolute url pointing to the public directory of the API server'),
			'#default_value' => $config->get('simulator_server_url') ?? '',
			'#required' => true,
			'#attributes' => [ 'class' => [ 'simulator_server_url' ] ],
		];
		$form['simulator_colors'] = [
			'#type' => 'details',
			'#title' => $this->t('Colors settings'),
			'#group' => 'simulator_settings',
			'#tree' => false
		];
		$form['simulator_colors']['simulator_primary_color'] = [
			'#type' => 'color',
			'#title' => $this->t('Primary color'),
			'#description' => $this->t('Primary color'),
			'#default_value' =>  $config->get('simulator_primary_color') ?? '#2b4e6b',
			'#attributes' => [ 'class' => [ 'simulator_primary_color' ] ],
		];
		$form['simulator_colors']['simulator_secondary_color'] = [
			'#type' => 'color',
			'#title' => $this->t('Secondary color'),
			'#description' => $this->t('Secondary color'),
			'#default_value' =>  $config->get('simulator_secondary_color') ?? '#c0c0c0',
			'#attributes' => [ 'class' => [ 'simulator_secondary_color' ] ],
		];
		$form['simulator_colors']['simulator_breadcrumb_color'] = [
			'#type' => 'color',
			'#title' => $this->t('Breadcrumb trail color'),
			'#description' => $this->t('Color of the active step in the breadcrumb trail'),
			'#default_value' =>  $config->get('simulator_breadcrumb_color') ?? '#2b4e6b',
			'#attributes' => [ 'class' => [ 'simulator_breadcrumb_color' ] ],
		];
		$form['simulator_colors']['simulator_tab_color'] = [
			'#type' => 'color',
			'#title' => $this->t('Tab color'),
			'#description' => $this->t('Tab color'),
			'#default_value' =>  $config->get('simulator_tab_color') ?? '#2b4e6b',
			'#attributes' => [ 'class' => [ 'simulator_tab_color' ] ],
		];
		$form['simulator_colors']['simulator_global_error_color'] = [
			'#type' => 'color',
			'#title' => $this->t('Global error color'),
			'#description' => $this->t('Global error color'),
			'#default_value' =>  $config->get('simulator_global_error_color') ?? '#ff0000',
			'#attributes' => [ 'class' => [ 'simulator_global_error_color' ] ],
		];
		$form['simulator_colors']['simulator_global_warning_color'] = [
			'#type' => 'color',
			'#title' => $this->t('Global warning color'),
			'#description' => $this->t('Global warning color'),
			'#default_value' =>  $config->get('simulator_global_warning_color') ?? '#800000',
			'#attributes' => [ 'class' => [ 'simulator_global_warning_color' ] ],
		];
		$form['simulator_colors']['simulator_field_error_color'] = [
			'#type' => 'color',
			'#title' => $this->t('Field error color'),
			'#description' => $this->t('Field error color'),
			'#default_value' =>  $config->get('simulator_field_error_color') ?? '#ff0000',
			'#attributes' => [ 'class' => [ 'simulator_field_error_color' ] ],
		];
		$form['simulator_colors']['simulator_field_warning_color'] = [
			'#type' => 'color',
			'#title' => $this->t('Field warning color'),
			'#description' => $this->t('Field warning color'),
			'#default_value' =>  $config->get('simulator_field_warning_color') ?? '#800000',
			'#attributes' => [ 'class' => [ 'simulator_field_warning_color' ] ],
		];
		$form['simulator_font'] = [
			'#type' => 'details',
			'#title' => $this->t('Font settings'),
			'#group' => 'simulator_settings',
			'#tree' => false
		];
		$form['simulator_font']['simulator_field_font_family'] = [
			'#type' => 'textfield',
			'#title' => $this->t('Font family'),
			'#description' => $this->t('Enter the font names separated by commas'),
			'#default_value' =>  $config->get('simulator_field_font_family') ?? 'Arial, Verdana',
			'#attributes' => [ 'class' => [ 'simulator_field_font_family' ] ],
		];
		$form['simulator_font']['simulator_field_font_size'] = [
			'#type' => 'textfield',
			'#title' => $this->t('Font size'),
			'#description' => $this->t('Enter the font size as a number followed by a unit (ex: 1em, 14px, etc.)'),
			'#default_value' =>  $config->get('simulator_field_font_size') ?? '1em',
			'#attributes' => [ 'class' => [ 'simulator_field_font_size' ] ],
		];
		$form['simulator_markup'] = [
			'#type' => 'details',
			'#title' => $this->t('Markup settings'),
			'#group' => 'simulator_settings',
			'#tree' => false,
		];
		$form['simulator_markup']['simulator_field_html_markup'] = [
			'#type' => 'select',
			'#title' => $this->t('HTML Markup'),
			'#description' => $this->t('HTML Markup'),
			'#default_value' =>  $config->get('simulator_field_html_markup') ?? 'fragment',
			'#options' => [
				'fragment' => $this->t('html fragment only'),
				'page' => $this->t('full html page'),
			],
			'#attributes' => [ 'class' => [ 'simulator_field_html_markup' ] ],
		];
		$form['simulator_markup']['simulator_field_adding_bootstrap'] = [
			'#type' => 'checkbox',
			'#title' => $this->t('Adding Bootstrap classes'),
			'#description' => $this->t('Check this box if you want bootstrap classes to be added to the relevant markup allowing bootstrap styles to apply'),
			'#default_value' =>  $config->get('simulator_field_adding_bootstrap') ?? 0,
			'#return_value' => 1,
			'#attributes' => [ 'class' => [ 'simulator_field_adding_bootstrap' ] ],
		];
		$form['simulator_markup']['simulator_field_bootstrap_version'] = [
			'#type' => 'textfield',
			'#title' => $this->t('Bootstrap version'),
			'#description' => $this->t('Enter the three groups of digits of the version number separated by periods'),
			'#default_value' =>  $config->get('simulator_field_bootstrap_version') ?? '',
			'#attributes' => [ 'class' => [ 'simulator_field_bootstrap_version' ] ],
		];
		$form['simulator_fields_observer'] = [
			'#type' => 'details',
			'#title' => $this->t('Data observer'),
			'#description' => $this->t('Enter the data to observe with the following format: &lt;simulator name>:&lt;data name>'),
			'#group' => 'simulator_settings',
			'#tree' => false,
		];
		for ($i = 1; $i <= 5; $i++) {
			$form['simulator_fields_observer']['simulator_field_observer' . $i] = [
				'#type' => 'textfield',
				'#title' => sprintf($this->t('Data %d'), $i),
				'#default_value' =>  $config->get('simulator_field_observer' . $i) ?? '',
				'#attributes' => [ 'class' => [ 'simulator_field_observer' ] ],
			];
		}
		$form['simulator_buttons_observer'] = [
			'#type' => 'details',
			'#title' => $this->t('Buttons observer'),
			'#description' => $this->t('Enter the button to observe with the following format: &lt;simulator name>:&lt;button name>'),
			'#group' => 'simulator_settings',
			'#tree' => false
		];
		for ($i = 1; $i <= 5; $i++) {
			$form['simulator_buttons_observer']['simulator_button_observer' . $i] = [
				'#type' => 'textfield',
				'#title' => sprintf($this->t('Button %d'), $i),
				'#default_value' =>  $config->get('simulator_button_observer' . $i) ?? '',
				'#attributes' => [ 'class' => [ 'simulator_button_observer' ] ],
			];
		}
		return parent::buildForm($form, $form_state);
	}

	/**
	 * {@inheritdoc}
	 */
	public function validateForm(array &$form, FormStateInterface $form_state) {
		$serverUrl = $form_state->getValue('simulator_server_url');
		$simulators = \Drupal::service('simulator.api')->simulators($serverUrl);
		if ($simulators === false) {
			$form_state->setErrorByName(
				'simulator_server_url',
				sprintf($this->t("The server '%s' is not responding or is not a G6K API server."), $serverUrl)
			);
			return;
		}
		$fontSize = $form_state->getValue('simulator_field_font_size', '');
		if ($fontSize != '') {
			$allowedSizes = [ 'xx-small', 'x-small', 'small', 'medium', 'large', 'x-large', 'xx-large', 'larger', 'smaller', 'inherit', 'initial', 'unset' ];
			if (! in_array($fontSize, $allowedSizes)) {
				if (! preg_match("/^\d+(\.\d+)?(px|pt|pc|ex|cm|mm|in|em|rem|%)$/", $fontSize)) {
					$form_state->setErrorByName(
						'simulator_field_font_size',
						sprintf($this->t("The font size '%s' is invalid."), $fontSize)
					);
				}
			}
		}
		$addingBootstrap = $form_state->getValue('simulator_field_adding_bootstrap', 0);
		$bootstrapVersion = $form_state->getValue('simulator_field_bootstrap_version', '');
		if ($addingBootstrap != 1) {
			if ($bootstrapVersion != '') {
				$form_state->setErrorByName(
					'simulator_field_bootstrap_version',
					$this->t('The bootstrap version must be empty')
				);
			}
		} else {
			if ($bootstrapVersion == '') {
				$form_state->setErrorByName(
					'simulator_field_bootstrap_version',
					$this->t('The bootstrap version is required')
				);
			} elseif (!preg_match("/^\d+\.\d+\.\d+$/", $bootstrapVersion)) {
				$form_state->setErrorByName(
					'simulator_field_bootstrap_version',
					$this->t('The bootstrap version is not in the required format')
				);
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer =  $form_state->getValue('simulator_field_observer' . $i, '');
			if ($observer != '') {
				if (!preg_match("/^([\-\w]+):[\-\w]+$/", $observer, $m)) {
					$form_state->setErrorByName(
						'simulator_field_observer' . $i,
						sprintf($this->t("The data '%s' to observe is not in the required format"), $observer ),
					);
				} elseif (! in_array($m[1], $simulators)) {
					$form_state->setErrorByName(
						'simulator_field_observer' . $i,
						sprintf($this->t("The simulator '%s' is not known by the API server"), $m[1] ),
					);
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer =  $form_state->getValue('simulator_button_observer' . $i, '');
			if ($observer != '') {
				if (!preg_match("/^([\-\w]+):[\-\w]+$/", $observer, $m)) {
					$form_state->setErrorByName(
						'simulator_button_observer' . $i,
						sprintf($this->t("The button '%s' to observe is not in the required format"), $observer ),
					);
				} elseif (! in_array($m[1], $simulators)) {
					$form_state->setErrorByName(
						'simulator_button_observer' . $i,
						sprintf($this->t("The simulator '%s' is not known by the API server"), $m[1] ),
					);
				}
			}
		}
	}

	/**
	* {@inheritdoc}
	*/
	public function submitForm(array &$form, FormStateInterface $form_state) {
		parent::submitForm($form, $form_state);
		$config = $this->config('simulator.adminsettings');
		$config
		->set('simulator_server_url', $form_state->getValue('simulator_server_url', ''))
		->set('simulator_primary_color', $form_state->getValue('simulator_primary_color', '#2b4e6b'))
		->set('simulator_secondary_color', $form_state->getValue('simulator_secondary_color', '#c0c0c0'))
		->set('simulator_breadcrumb_color', $form_state->getValue('simulator_breadcrumb_color', '#2b4e6b'))
		->set('simulator_tab_color', $form_state->getValue('simulator_tab_color', '#2b4e6b'))
		->set('simulator_global_error_color', $form_state->getValue('simulator_global_error_color', '#ff0000'))
		->set('simulator_global_warning_color', $form_state->getValue('simulator_global_warning_color', '#800000'))
		->set('simulator_field_error_color', $form_state->getValue('simulator_field_error_color', '#ff0000'))
		->set('simulator_field_warning_color', $form_state->getValue('simulator_field_warning_color', '#800000'))
		->set('simulator_field_font_family', $form_state->getValue('simulator_field_font_family', 'Arial, Verdana'))
		->set('simulator_field_font_size', $form_state->getValue('simulator_field_font_size', '1em'))
		->set('simulator_field_html_markup', $form_state->getValue('simulator_field_html_markup', 'fragment'))
		->set('simulator_field_adding_bootstrap', $form_state->getValue('simulator_field_adding_bootstrap', 0))
		->set('simulator_field_bootstrap_version', $form_state->getValue('simulator_field_bootstrap_version', ''));
		for ($i = 1; $i <= 5; $i++) {
			$config->set('simulator_field_observer' . $i, $form_state->getValue('simulator_field_observer' . $i, ''));
			$config->set('simulator_button_observer' . $i, $form_state->getValue('simulator_button_observer' . $i, ''));
		}
		$config->save();
	}
}