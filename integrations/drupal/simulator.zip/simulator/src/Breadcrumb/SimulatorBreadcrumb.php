<?php declare(strict_types=1);

namespace Drupal\simulator\Breadcrumb;

use Drupal\Core\Breadcrumb\BreadcrumbBuilderInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Breadcrumb\Breadcrumb;
use Drupal\Core\Link;

class SimulatorBreadcrumb implements BreadcrumbBuilderInterface {

	public function applies(RouteMatchInterface $route_match) {
		$parameters = $route_match->getParameters()->all();
		return isset($parameters['simu']);

	}

	public function build(RouteMatchInterface $route_match) {
		$breadcrumb = new Breadcrumb();
		$breadcrumb->addCacheContexts(["url"]);
		$breadcrumb->addLink(Link::createFromRoute(t('Home'), '<front>'));
		$request = \Drupal::request();
		$route_match = \Drupal::routeMatch();
		$title = \Drupal::service('title_resolver')->getTitle($request, $route_match->getRouteObject());
		if (!empty($title)) {
			$breadcrumb->addLink(Link::createFromRoute($title, '<none>'));
		}
		$parameters = $route_match->getParameters()->all();
		if (isset($parameters['simu'])) {
		}
		return $breadcrumb;
	}

}
