<?php

/*
The MIT License (MIT)

Copyright (c) 2021 Jacques Archimède

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

namespace Drupal\simulator\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Render\Markup;

/**
 * Provides a 'simulator' Block.
 *
 * @Block(
 *   id = "simulator_block",
 *   admin_label = @Translation("Simulator block"),
 *   category = @Translation("Simulator"),
 * )
 */
class SimulatorBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
	public function build() {
		$api = \Drupal::service('simulator.api');
		$html = $api->markup();
		$attributes = $api->attributes();
		\Drupal::service('page_cache_kill_switch')->trigger();
		return [
			'#markup' => Markup::create($html),
			'#title' => $attributes['title'],
			'#cache' => [
				'max-age' => 0
			],
			'#attached' => [
				'library' => [
					'simulator/assets',
				]
			]
		];
	}

}