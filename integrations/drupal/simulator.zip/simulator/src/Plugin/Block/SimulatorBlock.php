<?php

namespace Drupal\simulator\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Render\Markup;

/**
 * Provides a 'simulator' Block.
 *
 * @Block(
 *   id = "simulator_block",
 *   admin_label = @Translation("Simulator block"),
 *   category = @Translation("Simulator"),
 * )
 */
class SimulatorBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
	public function build() {
		$api = \Drupal::service('simulator.api');
		$html = $api->markup();
		$attributes = $api->attributes();
		return [
			'#markup' => Markup::create($html),
			'#title' => $attributes['title'],
			'#attached' => [
				'library' => [
					'simulator/assets',
				]
			]
		];
	}

}