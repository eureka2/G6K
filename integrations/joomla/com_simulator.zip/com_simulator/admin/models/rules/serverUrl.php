<?php

use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Http\HttpFactory;

class JFormRuleServerUrl extends JFormRule {

	public function test(SimpleXMLElement $element, $value, $group = null, JRegistry $input = null, JForm $form = null) {
		$attrs = $element->attributes();
		if ($attrs->name == 'simulator_api_server_url') {
			$uri = Uri::getInstance();
			$serverUrl = preg_replace("|https?://|", $uri->getScheme() . '://', $value);
			$url = $serverUrl . '/simulators/api';
			$http = HttpFactory::getHttp();
			$http->setOption('transport.curl', [
				CURLOPT_SSL_VERIFYHOST => 0,
				CURLOPT_SSL_VERIFYPEER => false
			]);
			$response = $http->post($url, []);
			if ($response->code == 200) {
				$body = json_decode($response->body, true);
				$body = $body['included']['data'];
				$simulators = [];
				foreach($body as $simulator) {
					$simulators[] = $simulator['id'];
				}
				if (count($simulators) == 0) {
					$element->addAttribute('message', JText::sprintf("COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_API_SERVER_NOT_RESPONDING_ERROR", $value));
					return false;
				}
			} else {
				$element->addAttribute('message', JText::sprintf("COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_API_SERVER_NOT_RESPONDING_ERROR", $value));
				return false;
			}
		}
		return true;
	}
}