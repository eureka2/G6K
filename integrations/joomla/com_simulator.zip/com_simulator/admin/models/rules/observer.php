<?php

use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Http\HttpFactory;

class JFormRuleObserver extends JFormRule {

	public function test(SimpleXMLElement $element, $value, $group = null, JRegistry $input = null, JForm $form = null) {
		$attrs = $element->attributes();
		if (preg_match("/_observer\d$/", $attrs->name) && $value != '') {
			if (!preg_match("/^([\-\w]+):[\-\w]+$/", $value, $m)) {
				if (preg_match("/_data_/", $attrs->name)) {
					$element->addAttribute('message', JText::sprintf("COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_OBSERVER_ERROR1", $value));
				} else {
					$element->addAttribute('message', JText::sprintf("COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_OBSERVER_ERROR2", $value));
				}
				return false;
			} else {
				$simu = $m[1];
				$uri = Uri::getInstance();
				$serverUrl = $input->get('simulator_api_server_url', '');
				$serverUrl = preg_replace("|https?://|", $uri->getScheme() . '://', $serverUrl);
				$url = $serverUrl . '/simulators/api';
				$http = HttpFactory::getHttp();
				$http->setOption('transport.curl', [
					CURLOPT_SSL_VERIFYHOST => 0,
					CURLOPT_SSL_VERIFYPEER => false
				]);
				$response = $http->post($url, $options);
				if ($response->code == 200) {
					$body = json_decode($response->body, true);
					$body = $body['included']['data'];
					$simulators = [];
					foreach($body as $simulator) {
						$simulators[] = $simulator['id'];
					}
					if (! in_array($simu, $simulators)) {
						$element->addAttribute('message', JText::sprintf("COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_OBSERVER_ERROR3", $simu));
						return false;
					}
				} else {
					$element->addAttribute('message', JText::sprintf("COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_OBSERVER_ERROR3", $simu));
					return false;
				}
			}
		}
		return true;
	}
}