<?php declare(strict_types=1);

class JFormRuleBootstrap extends JFormRule {

	public function test(SimpleXMLElement $element, $value, $group = null, JRegistry $input = null, JForm $form = null) {
		$attrs = $element->attributes();
		if ($attrs->name == 'simulator_markup_bootstrap_version') {
			$adding = $input->get('simulator_markup_bootstrap', 0);
			if ($adding == 0) {
				if ($value !== null && $value != '') {
					$element->addAttribute('message', JText::_('COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_BOOTSTRAP_VERSION_ERROR1'));
					return false;
				}
			} elseif ($value === null || $value == '') {
				$element->addAttribute('message', JText::_('COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_BOOTSTRAP_VERSION_ERROR2'));
				return false;
			} elseif (!preg_match("/^\d+\.\d+\.\d+$/", $value)) {
				$element->addAttribute('message', JText::_('COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_BOOTSTRAP_VERSION_ERROR3'));
				return false;
			}
		}
		return true;
	}
}