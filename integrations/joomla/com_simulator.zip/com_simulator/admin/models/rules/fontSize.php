<?php

class JFormRuleFontSize extends JFormRule {

	public function test(SimpleXMLElement $element, $value, $group = null, JRegistry $input = null, JForm $form = null) {
		$attrs = $element->attributes();
		if ($attrs->name == 'simulator_font_size' && $value != '') {
			$allowedSizes = [ 'xx-small', 'x-small', 'small', 'medium', 'large', 'x-large', 'xx-large', 'larger', 'smaller', 'inherit', 'initial', 'unset' ];
			if (! in_array($value, $allowedSizes)) {
				if (! preg_match("/^\d+(\.\d+)?(px|pt|pc|ex|cm|mm|in|em|rem|%)$/", $value)) {
					$element->addAttribute('message', JText::sprintf("COM_SIMULATOR_SIMULATOR_FIELD_SIMULATOR_FONT_SIZE_ERROR", $value));
					return false;
				}
			}
		}
		return true;
	}
}