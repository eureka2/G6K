<?php

use Joomla\CMS\Uri\Uri;

/**
 * @package     Joomla.Administrator
 * @subpackage  com_simulator
 *
 * @copyright   Copyright (C) 2021 Eureka2 All rights reserved.
 * @license     MIT
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * Simulator Model
 *
 * @since  0.0.1
 */
class SimulatorModelSimulator extends JModelItem
{
	/**
	 * @var string message
	 */
	protected $message;

	/**
	 * Get the message
         *
	 * @return  string  The message to be displayed to the user
	 */
	public function getMsg() {
		if (!isset($this->message))	{
			$app = JFactory::getApplication();
			$jinput = $app->input;
			$params = $app->getParams();
			$simu = $jinput->get('simu', 'demo');
			$this->message = $this->markup($simu, $params);
		}

		return $this->message;
	}

	protected function markup(string $simulator, $params) {
		$uri = Uri::getInstance();
		$serverUrl = $params->get('simulator_api_server_url');
		$serverUrl = preg_replace("|https?://|", $uri->getScheme() . '://', $serverUrl);
		$url = $serverUrl . '/' . $simulator . '/api/html';

		$options = [
			'markup' => $params->get('simulator_markup_type'), // 'fragment' or 'page'
			'bootstrap' => $params->get('simulator_markup_bootstrap_version'), // bootstrap version
			'primaryColor' => $params->get('simulator_primary_color'), // optional
			'secondaryColor' => $params->get('simulator_secondary_color'), // optional
			'fontFamily' => $params->get('simulator_font_family'), // optional
			'fontSize' => $params->get('simulator_font_size'), // optional
			'breadcrumbColor' => $params->get('simulator_breadcrumb_color'), // optional
			'tabColor' => $params->get('simulator_tab_color'), // optional
			'globalErrorColor' => $params->get('simulator_global_error_color'), // optional
			'globalWarningColor' => $params->get('simulator_global_warning_color'), // optional
			'fieldErrorColor' => $params->get('simulator_field_error_color'), // optional
			'fieldWarningColor' => $params->get('simulator_field_warning_color') // optional
		];
		$bootstrap = $params->get('simulator_markup_bootstrap');
		if ('1' !== $bootstrap) {
			unset($options['bootstrap']);
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer = $params->get('simulator_data_observer' . $i);
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer = $params->get('simulator_button_observer' . $i);
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.button';
					}
				}
			}
		}
		[$ok, $markup] = $this->fetch($url, $options);
		return $markup;
	}

	protected function fetch(string $url, array $options = []) {
		$postfields = implode("&", array_map(
			function($key, $value) {
				return $key . '=' . urlencode($value);
			},
			array_keys($options),
			array_values($options)
		));
		$curl = curl_init();
		curl_setopt_array($curl, [
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_SSL_VERIFYHOST => 0,
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_POST => 1, 
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => $postfields
		]);

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
			return [false, "Oops, something went wrong.  Please try again later.  #:" . $err];
		} else {
			return [true, $response];
		}
	}
}