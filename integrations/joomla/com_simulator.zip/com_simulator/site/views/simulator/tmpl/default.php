<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_simulator
 *
 * @copyright   Copyright (C) 2021 Eureka2 All rights reserved.
 * @license     MIT
 */
 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<?php echo $this->msg; ?>