<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_simulator
 *
 * @copyright   Copyright (C) 2021 Eureka2 All rights reserved.
 * @license     MIT
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.view');

/**
 * HTML View class for the Simulator Component
 *
 * @since  0.0.1
 */
class SimulatorViewSimulator extends JViewLegacy
{
	/**
	 * Display the Simulator view
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 */
	function display($tpl = null)
	{
		$params = JFactory::getApplication()->getParams("com_simulator");

		// Set Meta Description
		if ($description = $params->get('menu-meta_description'))
			$this->document->setDescription($description);
		// Set Meta Keywords
		if ($keywords = $params->get('menu-meta_keywords'))
			$this->document->setMetadata('keywords', $keywords);

		$this->document->addStyleSheet(JUri::base(true) . "/media/com_simulator/css/style.css", array('version' => 'auto'));
		$this->document->addScript(JUri::base(true) . "/media/com_simulator/js/script.js", '');


		// Assign data to the view
		$this->msg = $this->get('Msg');

		// Check for errors.
		if (count($errors = $this->get('Errors')))
		{
			JLog::add(implode('<br />', $errors), JLog::WARNING, 'jerror');

			return false;
		}

		// Display the view
		parent::display($tpl);
	}
}