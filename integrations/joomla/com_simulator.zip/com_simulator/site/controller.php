<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_simulator
 *
 * @copyright   Copyright (C) 2021 Eureka2 All rights reserved.
 * @license     MIT
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
jimport('joomla.application.component.controller');
/**
 * Simulator Component Controller
 *
 * @since  0.0.1
 */
class SimulatorController extends JControllerLegacy
{
}