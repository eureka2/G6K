<?php declare(strict_types=1);

defined('_JEXEC') or die;

class SimulatorRouter extends JComponentRouterBase {

	public function build(&$query) {
		$segments = [];
		if (isset($query['simu'])) {
			$segments[] = $query['simu'];
			unset($query['simu']);
		}
		return $segments;
	}

	public function parse(&$segments) {
		$vars = [];
		$vars['option'] = 'com_simulator';
		if (count($segments) > 1) {
			if ($segments[0] == 'simulator') {
				$vars['simu'] = $segments[1];
			} else {
				$vars['simu'] = $segments[0];
			}
		} elseif (count($segments) > 0 && $segments[0] != 'simulator') {
			$vars['simu'] = $segments[0];
			
		}
		return $vars;
	}
 
	public function preprocess($query) {
		return $query;
	}
}

function simulatorBuildRoute(&$query) {
	$router = new SimulatorRouter;

	return $router->build($query);
}

function simulatorParseRoute(&$segments) {
	$router = new SimulatorRouter;

	return $router->parse($segments);
}
