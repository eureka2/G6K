<?php namespace ProcessWire;


class Simulators extends WireData implements Module, ConfigurableModule {

	public static function getModuleInfo() {
		return [
			'title' => __('G6K Integration', __FILE__), 
			'version' => 101, 
			'summary' => __('Allows integration of simulators developped with G6K', __FILE__),
			'singular' => true, 
			'autoload' => true, 
			'icon' => 'calculator' 
		];
	}

	public function getModuleConfigInputfields(array $data) {
		$form = $this->wire(new InputfieldWrapper());
		$modules = $this->wire('modules');
		$modules->get('JqueryWireTabs');

		$tab = new InputfieldWrapper();
		$tab->attr('id', 'tab_api_server');
		$tab->attr('title', __('G6K API server'));
		$tab->attr('class', 'WireTab');
		$markup = $this->modules->get('InputfieldMarkup');
		$markup->label = __('G6K API server');
		$f = $modules->get('InputfieldURL');
		$f->attr('name', 'simulator_base_url');
		$f->attr('value', !empty($data['simulator_base_url']) ? $data['simulator_base_url'] : '');
		$f->label = __('Base url of the server');
		$f->description = __('Enter the absolute url pointing to the public directory of the API server');
		$f->columnWidth = 50;
		$markup->add($f);
		$tab->add($markup);
		$form->add($tab);

		$tab = new InputfieldWrapper();
		$tab->attr('id', 'tab_markup');
		$tab->attr('title', __('Markup'));
		$tab->attr('class', 'WireTab');
		$markup = $this->modules->get('InputfieldMarkup');
		$markup->label = __('Markup');
		$f = $modules->get('InputfieldSelect'); 
		$f->attr('name', 'simulator_markup');
		$f->attr('value', !empty($data['simulator_markup']) ? $data['simulator_markup'] : 'fragment');
		$f->label = __('HTML Markup'); 
		$f->addOption('fragment', __('html fragment only'));
		$f->addOption('page', __('full html page'));
		$f->optionColumns = 1; 
		$f->columnWidth = 33; 
		$markup->add($f);

		$f = $modules->get('InputfieldCheckbox'); 
		$f->attr('name', 'simulator_adding_bootstrap_classes'); 
		$f->label = __('Adding Bootstrap classes');
		$f->description = __('Check this box if you want bootstrap classes to be added to the relevant markup allowing bootstrap styles to apply');
		if(!empty($data['simulator_adding_bootstrap_classes'])) $f->attr('checked', 'checked'); 
		$f->optionColumns = 1; 
		$f->columnWidth = 34;
		$markup->add($f);

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_bootstrap_version');
		$f->attr('value', !empty($data['simulator_bootstrap_version']) ? $data['simulator_bootstrap_version'] : '');
		$f->label = __('Bootstrap version');
		$f->description = __('Enter the three groups of digits of the version number separated by periods');
		$f->columnWidth = 50;
		$markup->add($f);

		$f = $modules->get('InputfieldCheckbox'); 
		$f->attr('name', 'simulator_adding_bootstrap_stylesheet'); 
		$f->label = __('Adding Bootstrap stylesheet');
		$f->description = __('if this field is checked, the Bootstrap stylesheet will be loaded by the API from bootstrapcdn.');
		if(!empty($data['simulator_adding_bootstrap_stylesheet'])) $f->attr('checked', 'checked'); 
		$f->optionColumns = 1; 
		$f->columnWidth = 34;
		$markup->add($f);

		$f = $modules->get('InputfieldCheckbox'); 
		$f->attr('name', 'simulator_adding_bootstrap_library'); 
		$f->label = __('Adding Bootstrap library');
		$f->description = __('if this field is checked, Bootstrap library will be loaded by the API from bootstrapcdn.');
		if(!empty($data['simulator_adding_bootstrap_library'])) $f->attr('checked', 'checked'); 
		$f->optionColumns = 1; 
		$f->columnWidth = 34;
		$markup->add($f);

		$f = $modules->get('InputfieldCheckbox'); 
		$f->attr('name', 'simulator_adding_jquery_library'); 
		$f->label = __('Adding jQuery library');
		$f->description = __('if this field is checked, the jQuery library will be loaded by the API from code.jquery.com.');
		if(!empty($data['simulator_adding_jquery_library'])) $f->attr('checked', 'checked'); 
		$f->optionColumns = 1; 
		$f->columnWidth = 34;
		$markup->add($f);
		$tab->add($markup);
		$form->add($tab);

		$tab = new InputfieldWrapper();
		$tab->attr('id', 'tab_colors');
		$tab->attr('title', __('Colors'));
		$tab->attr('class', 'WireTab');
		$markup = $this->modules->get('InputfieldMarkup');
		$markup->label = __('Colors');

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_primary_color');
		$f->attr('value', !empty($data['simulator_primary_color']) ? $data['simulator_primary_color'] : '#2b4e6b');
		$f->label = __('Primary color');
		$f->columnWidth = 25;
		$markup->add($f);

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_secondary_color');
		$f->attr('value', !empty($data['simulator_secondary_color']) ? $data['simulator_secondary_color'] : '#c0c0c0');
		$f->label = __('Secondary color');
		$f->columnWidth = 25;
		$markup->add($f);

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_breadcrumb_color');
		$f->attr('value', !empty($data['simulator_breadcrumb_color']) ? $data['simulator_breadcrumb_color'] : '#2b4e6b');
		$f->label = __('Breadcrumb color');
		$f->columnWidth = 25;
		$markup->add($f);

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_tab_color');
		$f->attr('value', !empty($data['simulator_tab_color']) ? $data['simulator_tab_color'] : '#2b4e6b');
		$f->label = __('Tab color');
		$f->columnWidth = 25;
		$markup->add($f);

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_global_error_color');
		$f->attr('value', !empty($data['simulator_global_error_color']) ? $data['simulator_global_error_color'] : '#ff0000');
		$f->label = __('Global error color');
		$f->columnWidth = 25;
		$markup->add($f);

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_global_warning_color');
		$f->attr('value', !empty($data['simulator_global_warning_color']) ? $data['simulator_global_warning_color'] : '#800000');
		$f->label = __('Global warning color');
		$f->columnWidth = 25;
		$markup->add($f);

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_field_error_color');
		$f->attr('value', !empty($data['simulator_field_error_color']) ? $data['simulator_field_error_color'] : '#ff0000');
		$f->label = __('Field error color');
		$f->columnWidth = 25;
		$markup->add($f);

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_field_warning_color');
		$f->attr('value', !empty($data['simulator_field_warning_color']) ? $data['simulator_field_warning_color'] : '#800000');
		$f->label = __('Field warning color');
		$f->columnWidth = 25;
		$markup->add($f);
		$tab->add($markup);
		$form->add($tab);

		$tab = new InputfieldWrapper();
		$tab->attr('id', 'tab_font');
		$tab->attr('title', __('Font'));
		$tab->attr('class', 'WireTab');
		$markup = $this->modules->get('InputfieldMarkup');
		$markup->label = __('Font');

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_font_family');
		$f->attr('value', !empty($data['simulator_font_family']) ? $data['simulator_font_family'] : 'Arial, Verdana');
		$f->label = __('Font family');
		$f->description = __('Enter the font names separated by commas');
		$f->columnWidth = 50;
		$markup->add($f);

		$f = $modules->get('InputfieldText');
		$f->attr('name', 'simulator_font_size');
		$f->attr('value', !empty($data['simulator_font_size']) ? $data['simulator_font_size'] : '1em');
		$f->label = __('Font size');
		$f->description = __('Enter the font size as a number followed by a unit (ex: 1em, 14px, etc.)');
		$f->columnWidth = 50;
		$markup->add($f);
		$tab->add($markup);
		$form->add($tab);

		$tab = new InputfieldWrapper();
		$tab->attr('id', 'tab_data_observers');
		$tab->attr('title', __('Data observers'));
		$tab->attr('class', 'WireTab');
		$markup = $this->modules->get('InputfieldMarkup');
		$markup->label = __('Data observers');

		for ($i = 1; $i <= 5; $i++) {
			$f = $modules->get('InputfieldText');
			$f->attr('name', 'simulator_data' . $i . '_observer');
			$f->attr('value', !empty($data['simulator_data' . $i . '_observer']) ? $data['simulator_data' . $i . '_observer'] : '');
			$f->label = sprintf(__('Data %d'), $i);
			$f->description = __('Enter the data to observe with the following format: <simulator name>:<data name>');
			$f->columnWidth = 50;
			$markup->add($f);
		}
		$tab->add($markup);
		$form->add($tab);

		$tab = new InputfieldWrapper();
		$tab->attr('id', 'tab_buttons_observers');
		$tab->attr('title', __('Buttons observers'));
		$tab->attr('class', 'WireTab');
		$markup = $this->modules->get('InputfieldMarkup');
		$markup->label = __('Buttons observers');

		for ($i = 1; $i <= 5; $i++) {
			$f = $modules->get('InputfieldText');
			$f->attr('name', 'simulator_button' . $i . '_observer');
			$f->attr('value', !empty($data['simulator_button' . $i . '_observer']) ? $data['simulator_button' . $i . '_observer'] : '');
			$f->label = sprintf(__('Button %d'), $i);
			$f->description = __('Enter the button to observe with the following format: <simulator name>:<button name>');
			$f->columnWidth = 50;
			$markup->add($f);
		}
		$tab->add($markup);
		$form->add($tab);

		return $form;
	}

	public function ready() {
		error_log("ready");
		$this->addHookBefore('AdminTheme::getExtraMarkup', function (HookEvent $event) {
			$input = $this->wire('input'); 
			$pageUrl = $input->httpUrl();
			$name = $input->get('name');
			if (preg_match("|/admin/module/edit|", $pageUrl) && $name === 'Simulators') {
				$user = $this->wire->user;
				$lang = substr($user->language->name, 0, 2);
				$config = $this->wire->config;
				$url = $config->urls($this);
				$config->styles->add($url."css/settings.css");
				$config->scripts->add($url."js/lang/".$lang.".js");
				$config->scripts->add($url."js/settings.js");
			}
		});
	}

	public function init() {
		$this->addHookAfter('Page::render', $this, 'renderPage'); 
	}

	public function getLangCode($lang) {
		if ($lang == 'default') {
			return 'en';
		} else {
			return substr($lang, 0, 2);
		}
	}

	public function install() {
		$config = $this->wire->config;
		$languages = $this->wire('languages');
		foreach($languages as $language) {
			$lang = $this->getLangCode($language->name);
			$langfile = __DIR__ . '/lang/' . $lang . '.json';
			$path = $config->paths->files . $language->id;
			$file = $path . "/site--modules--simulators--simulators-module-php.json";
			if (file_exists($langfile) && !file_exists($file)) {
				copy($langfile, $file);
			}
		}
	}

	public function uninstall() {
		$config = $this->wire->config;
		$languages = $this->wire('languages');
		foreach($languages as $language) {
			$lang = $this->getLangCode($language->name);
			$path = $config->paths->files . $language->id;
			$file = $path . "/site--modules--simulators--simulators-module-php.json";
			if (file_exists($file)) {
				unlink($file);
			}
		}
	}

	public function renderSimulator($matches) {
		[$ok, $response] = $this->fetch($matches[1], $this->options($matches[1]));
		return $response;
	}

	public function renderPage($event) {
		$page = $event->object; 
		if($page->template == 'admin') return;
		$html = $event->return;
		if (preg_match('/\[simulator\s+name="([\w-]+)"\s*\]/', $html)) {
			$html = preg_replace_callback('/\[simulator\s+name="([\w-]+)"\s*\]/', [$this, 'renderSimulator'], $html);
			if ($html !== null) {
				$config = $this->wire->config;
				$url = $config->urls($this);
				$html = str_replace("</head>", '<link rel="stylesheet" type="text/css" href="' . $url .'css/style.css"></head>', $html);
				$html = str_replace("</body>", '<script type="text/javascript" src="' . $url .'js/script.js"></script></body>', $html);
				$event->return = $html;
			}
		}
	}

	private function url($simulator) {
		$baseUrl = $this->get('simulator_base_url');
		$baseUrl = preg_replace("|^https?|", $this->wire('input')->scheme(), $baseUrl);
		return $baseUrl . '/' . $simulator . '/api';
	}

	private function options($simulator) {
		$options = [
			'markup' => $this->get('simulator_markup')  ?? 'fragment', // 'fragment' or 'page'
			'primaryColor' => $this->get('simulator_primary_color')  ?? '#2b4e6b', // optional
			'secondaryColor' => $this->get('simulator_secondary_color')  ?? '#c0c0c0', // optional
			'breadcrumbColor' => $this->get('simulator_breadcrumb_color')  ?? '#2b4e6b', // optional
			'tabColor' => $this->get('simulator_tab_color')  ?? '#2b4e6b', // optional
			'globalErrorColor' => $this->get('simulator_global_error_color')  ?? '#ff0000', // optional
			'globalWarningColor' => $this->get('simulator_global_warning_color')  ?? '#800000', // optional
			'fieldErrorColor' => $this->get('simulator_field_error_color')  ?? '#ff0000', // optional
			'fieldWarningColor' => $this->get('simulator_field_warning_color')  ?? '#800000', // optional
			'fontFamily' => $this->get('simulator_font_family')  ?? 'Arial, Verdana', // optional
			'fontSize' => $this->get('simulator_font_size')  ?? '1em', // optional
		];
		$bootstrap = $this->get('simulator_adding_bootstrap_classes')  ?? '0';
		if ('1' == $bootstrap) {
			$options['bootstrap'] = $this->get('simulator_bootstrap_version')  ?? ''; // bootstrap version;
			$options['addBootstrapStylesheet'] = $this->get('simulator_adding_bootstrap_stylesheet')  ?? '0' == '1' ? 'true' : 'false';
			$options['addBootstrapScript'] = $this->get('simulator_adding_bootstrap_library')  ?? '0' == '1' ? 'true' : 'false'; 
			$options['addJQueryScript'] = $this->get('simulator_adding_jquery_library')  ?? '0'  == '1' ? 'true' : 'false';
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_data' . $i . '_observer';
			$observer = $this->get('$field')  ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_button' . $i . '_observer';
			$observer = $this->get('$field')  ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.button';
					}
				}
			}
		}
		return $options;
	}

	private function fetch($simulator, $options = []) {

		$url = $this->url($simulator) . '/html';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $options);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$response = curl_exec($ch);
		$ok = true;
		if (curl_error($ch)) {
			$response = "Oops something went wrong : " . curl_error($ch);
			$ok = false;
		}
		curl_close ($ch);

		return [$ok, $response];

	}

}
