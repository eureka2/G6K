<?php

if(!defined('e107_INIT')) {
	exit;
}

class simulator_url {

	function config() {
		$config = [];

		// simulator with title or ID
		$config['simulator_id'] = [
			// Matched against url, and if true, redirected to 'redirect' below.
			'regex'    => '^simulator/(.*)$',
			// {wrapper_id} is substituted with database value when parsed by e107::url();
			'sef'      => 'simulator/{simulator_name}',
			// File-path of what to load when the regex returns true.
			'redirect' => '{e_PLUGIN}simulator/simulator.php?$1'
		];
		return $config;
	}
}