CREATE TABLE `simulator` (
  `simulator_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `simulator_name` varchar(255) DEFAULT NULL,
  `simulator_title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`simulator_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;
