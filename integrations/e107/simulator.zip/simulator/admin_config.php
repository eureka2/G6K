<?php

require_once('../../class2.php');

e107::lan('simulator', true, true);
if (!getperms('P')) {
	e107::redirect('admin');
	exit;
}

class simulator_adminArea extends e_admin_dispatcher {

	protected $modes = [
		'main'	=> [
			'controller' 	=> 'simulator_ui',
			'path' 			=> null,
			'ui' 			=> 'simulator_form_ui',
			'uipath' 		=> null
		],
	];

	protected $adminMenu = [
		'main/list'		=> ['caption'=> LAN_MANAGE, 'perm' => 'P'],
		'main/create'	=> ['caption'=> LAN_CREATE, 'perm' => 'P'],
		'main/prefs'	=> ['caption'=> LAN_SIMULATOR_MENU_DESCRIPTION, 'perm' => 'P'],
	];

	protected $adminMenuAliases = [
		'main/edit'	=> 'main/list'
	];

	protected $menuTitle = LAN_SIMULATOR_PLUGIN_NAME;
}

class simulator_ui extends e_admin_ui {

	protected $pluginTitle		= LAN_SIMULATOR_PLUGIN_NAME;
	protected $pluginName		= 'simulator';
//	protected $eventName		= 'simulator-'; // remove comment to enable event triggers in admin. 
	protected $table			= 'simulator';
	protected $pid				= 'simulator_id';
	protected $perPage			= 10; 
	protected $batchDelete		= true;
	protected $batchExport     = true;
	protected $batchCopy		= true;

	protected $listOrder		= 'simulator_id DESC';

	protected $fields = [
		'checkboxes' => [
			'title' 	=> '', 
			'type' 		=> null, 
			'data' 		=> null, 
			'width' 	=> '5%', 
			'thclass' 	=> 'center', 
			'forced' 	=> '1', 
			'class' 	=> 'center', 
			'toggle' 	=> 'e-multiselect',  
		],
		'simulator_id' => [
			'title' 	 => 'id', 
			'type' 		 => 'number', 
			'data' 		 => 'int', 
			'width' 	 => '5%', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_name' => [
			'title' 	 => LAN_SIMULATOR_NAME,
			'type' 		 => 'text', 
			'data' 		 => 'str', 
			'width'  	 => 'auto', 
			'inline'  	 => true, 
			'help'  	 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',  
		],
		'simulator_title' => [
			'title' 	 => LAN_SIMULATOR_TITLE,
			'type' 		 => 'text', 
			'data' 		 => 'str', 
			'width'  	 => 'auto', 
			'inline'  	 => true, 
			'help'  	 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',  
		],
		'options' => [
			'title' 	=> LAN_OPTIONS, 
			'type' 		=> null, 
			'data' 		=> null, 
			'width' 	=> '10%', 
			'thclass' 	=> 'center last', 
			'class' 	=> 'center last', 
			'forced' 	=> '1',  
		],
	];

	protected $fieldpref = ['simulator_id', 'simulator_name', 'simulator_title'];

	protected $preftabs = [
		LAN_SIMULATOR_G6K_API_SERVER_TAB,
		LAN_SIMULATOR_MARKUP_TAB,
		LAN_SIMULATOR_COLORS_TAB,
		LAN_SIMULATOR_FONT_TAB,
		LAN_SIMULATOR_DATA_OBSERVERS_TAB,
		LAN_SIMULATOR_BUTTONS_OBSERVERS_TAB
	];

	protected $prefs = [
		'simulator_base_url' => [ 
			'title' 	 => LAN_SIMULATOR_BASE_URL_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 0, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_BASE_URL_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_markup' => [ 
			'title' 	 => LAN_SIMULATOR_HTML_MARKUP_TITLE, 
			'type' 		 => 'dropdown', 
			'tab' 		 => 1, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => [ 'optArray' =>
				[
					'fragment' => LAN_SIMULATOR_HTML_MARKUP_FRAGMENT,
					'page' => LAN_SIMULATOR_HTML_MARKUP_PAGE
				]
			],
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_adding_bootstrap_classes' => [ 
			'title' 	 => LAN_SIMULATOR_BOOTSTRAP_CLASSES_TITLE, 
			'type' 		 => 'checkbox', 
			'tab' 		 => 1, 
			'data' 		 => 'int', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_BOOTSTRAP_CLASSES_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_bootstrap_version' => [ 
			'title' 	 => LAN_SIMULATOR_BOOTSTRAP_VERSION_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 1, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_BOOTSTRAP_VERSION_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_adding_bootstrap_stylesheet' => [ 
			'title' 	 => LAN_SIMULATOR_BOOTSTRAP_STYLESHEET_TITLE, 
			'type' 		 => 'checkbox', 
			'tab' 		 => 1, 
			'data' 		 => 'int', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_BOOTSTRAP_STYLESHEET_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_adding_bootstrap_library' => [ 
			'title' 	 => LAN_SIMULATOR_BOOTSTRAP_LIBRARY_TITLE, 
			'type' 		 => 'checkbox', 
			'tab' 		 => 1, 
			'data' 		 => 'int', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_BOOTSTRAP_LIBRARY_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_adding_jquery_library' => [ 
			'title' 	 => LAN_SIMULATOR_BOOTSTRAP_JQUERY_TITLE, 
			'type' 		 => 'checkbox', 
			'tab' 		 => 1, 
			'data' 		 => 'int', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_BOOTSTRAP_JQUERY_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_primary_color' => [ 
			'title' 	 => LAN_SIMULATOR_PRIMARY_COLOR_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 2, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_secondary_color' => [ 
			'title' 	 => LAN_SIMULATOR_SECONDARY_COLOR_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 2, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_breadcrumb_color' => [ 
			'title' 	 => LAN_SIMULATOR_BREADCRUMB_COLOR_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 2, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_tab_color' => [ 
			'title' 	 => LAN_SIMULATOR_TAB_COLOR_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 2, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_global_error_color' => [ 
			'title' 	 => LAN_SIMULATOR_GLOBAL_ERROR_COLOR_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 2, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_global_warning_color' => [ 
			'title' 	 => LAN_SIMULATOR_GLOBAL_WARNING_COLOR_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 2, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_field_error_color' => [ 
			'title' 	 => LAN_SIMULATOR_FIELD_ERROR_COLOR_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 2, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_field_warning_color' => [ 
			'title' 	 => LAN_SIMULATOR_FIELD_WARNING_COLOR_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 2, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => '', 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_font_family' => [ 
			'title' 	 => LAN_SIMULATOR_FONT_FAMILY_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 3, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_FONT_FAMILY_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_font_size' => [ 
			'title' 	 => LAN_SIMULATOR_FONT_SIZE_TITLE, 
			'type' 		 => 'text', 
			'tab' 		 => 3, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_FONT_SIZE_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_data1_observer' => [ 
			'title' 	 => LAN_SIMULATOR_DATA1_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 4, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_data2_observer' => [ 
			'title' 	 => LAN_SIMULATOR_DATA2_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 4, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_data3_observer' => [ 
			'title' 	 => LAN_SIMULATOR_DATA3_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 4, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_data4_observer' => [ 
			'title' 	 => LAN_SIMULATOR_DATA4_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 4, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_data5_observer' => [ 
			'title' 	 => LAN_SIMULATOR_DATA5_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 4, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_button1_observer' => [ 
			'title' 	 => LAN_SIMULATOR_BUTTON1_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 5, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_button2_observer' => [ 
			'title' 	 => LAN_SIMULATOR_BUTTON2_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 5, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_button3_observer' => [ 
			'title' 	 => LAN_SIMULATOR_BUTTON3_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 5, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_button4_observer' => [ 
			'title' 	 => LAN_SIMULATOR_BUTTON4_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 5, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
		'simulator_button5_observer' => [ 
			'title' 	 => LAN_SIMULATOR_BUTTON5_OBSERVER_TITLE,
			'type' 		 => 'text', 
			'tab' 		 => 5, 
			'data' 		 => 'str', 
			'width' 	 => 'auto', 
			'help' 		 => LAN_SIMULATOR_DATA_OBSERVER_DESCRIPTION, 
			'readParms'  => '', 
			'writeParms' => '', 
			'class' 	 => 'left', 
			'thclass' 	 => 'left',
		],
	]; 

	public function init() {
		if(!e107::isInstalled('simulator')) {
			e107::getMessage()->addWarning("This plugin is not yet installed. Saving and loading of preference or table data will fail.");
		}
		$action	= $this->getAction();
		if ($action == 'prefs') {
			e107::css('simulator','css/settings.css');
			if (file_exists(__DIR__ . '/js/lang/' . e_LANGUAGE . '.js')) {
				$language = e_LANGUAGE;
			} else {
				$language = 'English';
			}
			e107::js('simulator','js/lang/' . e_LANGUAGE . '.js');
			e107::js('simulator','js/settings.js');
		}
		$id = $this->getId();

		if($action == 'edit'){
			$name = e107::getDb()->retrieve('simulator', 'simulator_name', 'simulator_id='.$id);
			$sef_name = eHelper::title2sef($name); 
			
			$urlparms = [
				'simulator_name' => $sef_name
			];

			$sef_url = SITEURLBASE.e107::url('simulator', 'simulator_id', $urlparms);
			
			$sef_link = '<a target="_blank" href="'.$sef_url.'">'.$sef_url.'</a>';

			$urltext = e107::getParser()->lanVars(LAN_SIMULATOR_URL, [$sef_link]);
			e107::getMessage()->addInfo($urltext);
		}
	}

	// ------- Customize Create --------

	public function beforeCreate($new_data,$old_data) {
		return $new_data;
	}

	public function afterCreate($new_data, $old_data, $id) {
		$simulator_name = $new_data['simulator_name'];
		$sef_name 	= eHelper::title2sef($simulator_name); 

		$urlparms = [
			'simulator_name' => $sef_name,
		];

		$sef_url = SITEURLBASE.e107::url('simulator', 'simulator_id', $urlparms);
			
		$sef_link 	= '<a target="_blank" href="'.$sef_url.'">'.$sef_url.'</a>';
		$urltext = e107::getParser()->lanVars(LAN_SIMULATOR_URL, [$sef_link]);
		e107::getMessage()->addSuccess($urltext);
	}

	public function onCreateError($new_data, $old_data) {
		// do something
	}

	// ------- Customize Update --------

	public function beforeUpdate($new_data, $old_data, $id) {
		return $new_data;
	}

	public function afterUpdate($new_data, $old_data, $id) {
		// do something
	}

	public function onUpdateError($new_data, $old_data, $id) {
		// do something
	}

	// left-panel help menu area. (replaces e_help.php used in old plugins)
	public function renderHelp() {
		$caption = LAN_HELP;
		switch($this->getAction()) {
			case 'list':
				$text = LAN_SIMULATOR_MANAGE_HELP;
				break;
			case 'create':
				$text = LAN_SIMULATOR_CREATE_HELP;
				break;
			case 'prefs':
				$text = LAN_SIMULATOR_PREFS_HELP;
				break;
			default:
				$text = '';
		}
		return ['caption'=>$caption,'text'=> $text];
	}

}

class simulator_form_ui extends e_admin_form_ui {
}

new simulator_adminArea();
require_once(e_ADMIN."auth.php");
e107::getAdminUI()->runPage();
require_once(e_ADMIN."footer.php");
exit;

