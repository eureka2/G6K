<?php

if (!defined('e107_INIT')) { exit; }

class simulator_shortcodes extends e_shortcode {

	function __construct() {
		e107::lan('simulator', false, true);
	}

	function sc_simulator($parm = []) {
		require_once(e_PLUGIN."simulator/simulator_class.php");

		$name = vartrue($parm['name']);
		$name = preg_replace("/^\"|\"$/", "", $name);

		$simulator = new Simulator(); 
		$simulator = $simulator->render($name);
		e107::css('simulator','css/style.css');
		e107::js('simulator','js/script.js');
		return $simulator;
	}
}