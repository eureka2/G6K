<?php

if (!defined('e107_INIT')){
	require_once("../../class2.php");
}

// Make this page inaccessible when plugin is not installed.
if(!e107::isInstalled('simulator')) {
	e107::redirect();
	exit;
}

// Load required files and set initial variables
e107::lan('simulator', false, true); 
require_once(e_PLUGIN."simulator/simulator_class.php");

$caption = '';
$error = '';
$simulator_name = '';
// Initiate the wrapper class; 
$simulator = new Simulator(); 

// Retrieve query and check for wrap_pass
[$simulator_name] = explode('/', e_QUERY, 1);

// Set caption
$title = e107::getDb()->retrieve("simulator", "simulator_title", "simulator_name='".$simulator_name."'");
$caption = empty($title) ? LAN_SIMULATOR_NAME : $title; 
define('e_PAGETITLE', $caption); 

// Render the page
require_once(HEADERF);

$text = $simulator->render($simulator_name);
e107::css('simulator','css/style.css');
e107::js('simulator','js/script.js');
$ns->tablerender($caption, e107::getMessage()->render().$text);

require_once(FOOTERF);
exit;