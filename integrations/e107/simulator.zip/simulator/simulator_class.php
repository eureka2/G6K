<?php

class Simulator {

	private function scheme() {
		$isHttps = 
			(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
			|| (isset($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https')
			|| (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
			|| (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443)
		;
		return $isHttps ? 'https' : 'http';
	}

	private function url($simulator) {
		$baseUrl = e107::pref('simulator', 'simulator_base_url');
		$scheme = $this->scheme();
		$baseUrl = preg_replace("/^https?/", $scheme, $baseUrl);
		return $baseUrl . '/' . $simulator . '/api';
	}

	public function attributes($simulator) {
		$url = $this->url($simulator) . '/json';
		[$ok, $api] = $this->fetch($url);
		if ($ok) {
			$api = json_decode($api, true);
			return $api['data']['attributes'];
		} else {
			return [ 'title' => $api, 'description' => $api ];
		}
	}

	public function simulators($baseUrl = null) {
		$url = $this->url($simulator) . '/json';
		[$ok, $api] = $this->fetch($url);
		$simulators = [];
		if ($ok) {
			$api = json_decode($api, true);
			$data = $api['included']['data'];
			foreach($data as $simu) {
				$simulators[] = $simu['id'];
			}
			return $simulators;
		}
		return false;
	}

	private function options($simulator) {
		$settings =  (object)e107::pref('simulator');
		$options = [
			'markup' => $settings->simulator_markup ?? 'fragment', // 'fragment' or 'page'
			'primaryColor' => $settings->simulator_primary_color ?? '#2b4e6b', // optional
			'secondaryColor' => $settings->simulator_secondary_color ?? '#c0c0c0', // optional
			'breadcrumbColor' => $settings->simulator_breadcrumb_color ?? '#2b4e6b', // optional
			'tabColor' => $settings->simulator_tab_color ?? '#2b4e6b', // optional
			'globalErrorColor' => $settings->simulator_global_error_color ?? '#ff0000', // optional
			'globalWarningColor' => $settings->simulator_global_warning_color ?? '#800000', // optional
			'fieldErrorColor' => $settings->simulator_field_error_color ?? '#ff0000', // optional
			'fieldWarningColor' => $settings->simulator_field_warning_color ?? '#800000', // optional
			'fontFamily' => $settings->simulator_font_family ?? 'Arial, Verdana', // optional
			'fontSize' => $settings->simulator_font_size ?? '1em', // optional
		];
		$bootstrap = $settings->simulator_adding_bootstrap_classes ?? '0';
		if ('1' === $bootstrap) {
			$options['bootstrap'] = $settings->simulator_bootstrap_version ?? ''; // bootstrap version;
			$options['addBootstrapStylesheet'] = $settings->simulator_adding_bootstrap_stylesheet ?? '0' == '1' ? 'true' : 'false';
			$options['addBootstrapScript'] = $settings->simulator_adding_bootstrap_library ?? '0' == '1' ? 'true' : 'false'; 
			$options['addJQueryScript'] = $settings->simulator_adding_jquery_library ?? '0'  == '1' ? 'true' : 'false';
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_data' . $i . '_observer';
			$observer = $settings->$field ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_button' . $i . '_observer';
			$observer = $settings->$field ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.button';
					}
				}
			}
		}
		return $options;
	}

	public function render($simulator) {
		$url = $this->url($simulator) . '/html';
		[$ok, $response] = $this->fetch($url, $this->options($simulator));
		return $response;
	}

	private function fetch($url, $options = []) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $options);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$response = curl_exec($ch);
		$ok = true;
		if (curl_error($ch)) {
			$response = "Oops something went wrong : " . curl_error($ch);
			$ok = false;
		}
		curl_close ($ch);

		return [$ok, $response];

	}

}
