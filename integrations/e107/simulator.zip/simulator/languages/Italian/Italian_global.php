<?php

define("LAN_SIMULATOR_PLUGIN_NAME",  "Simulatore");
define("LAN_SIMULATOR_DESC",  "Integrazione G6K.");
define("LAN_SIMULATOR_SUMM",  "Permite la integración de simuladores desarrollados con G6K");