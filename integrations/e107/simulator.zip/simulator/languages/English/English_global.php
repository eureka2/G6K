<?php

define("LAN_SIMULATOR_PLUGIN_NAME", "Simulator");
define("LAN_SIMULATOR_DESC",  "G6K Integration.");
define("LAN_SIMULATOR_SUMM",  "This plugin allows integration of simulators developped with G6K.");