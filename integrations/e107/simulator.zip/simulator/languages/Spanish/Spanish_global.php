<?php

define("LAN_SIMULATOR_PLUGIN_NAME",  "Simulador");
define("LAN_SIMULATOR_DESC",  "Integración G6K.");
define("LAN_SIMULATOR_SUMM",  "Este complemento permite la integración de simuladores desarrollados con G6K.");