<?php

define("LAN_SIMULATOR_PLUGIN_NAME",  "Simulateur");
define("LAN_SIMULATOR_DESC",  "Intégration G6K");
define('LAN_SIMULATOR_SUMM', "Ce plugin permet l\'intégration de simulateurs développés avec G6K");
