<?php

define("LAN_SIMULATOR_PLUGIN_NAME",  "Simulador");
define("LAN_SIMULATOR_DESC",  "Integração G6K.");
define("LAN_SIMULATOR_SUMM",  "Este plugin permite a integração de simuladores desenvolvidos com G6K.");