<?php

namespace Simulator\Config;

use SilverStripe\Forms\TabSet;
use SilverStripe\Forms\FieldList;
use SilverStripe\Forms\TextField;
use SilverStripe\Forms\DropdownField;
use SilverStripe\Forms\CheckboxField;
use SilverStripe\ORM\DataExtension;
use SilverStripe\View\Requirements;
use SilverStripe\Control\Controller;

class SimulatorConfigExtension extends DataExtension {

	private static $db = [
		'simulator_baseURL' => 'Varchar',
		'simulator_markup' => 'Varchar',
		'simulator_primaryColor' => 'Varchar',
		'simulator_secondaryColor' => 'Varchar',
		'simulator_breadcrumbColor' => 'Varchar',
		'simulator_tabColor' => 'Varchar',
		'simulator_globalErrorColor' => 'Varchar',
		'simulator_globalWarningColor' => 'Varchar',
		'simulator_fieldErrorColor' => 'Varchar',
		'simulator_fieldWarningColor' => 'Varchar',
		'simulator_fontFamily' => 'Varchar',
		'simulator_fontSize' => 'Varchar',
		'simulator_addBootstrapClasses' => 'Boolean',
		'simulator_bootstrapVersion' => 'Varchar',
		'simulator_addBootstrapStylesheet' => 'Boolean',
		'simulator_addBootstrapScript' => 'Boolean',
		'simulator_addJQueryScript' => 'Boolean',
		'simulator_data1' => 'Varchar',
		'simulator_data2' => 'Varchar',
		'simulator_data3' => 'Varchar',
		'simulator_data4' => 'Varchar',
		'simulator_data5' => 'Varchar',
		'simulator_button1' => 'Varchar',
		'simulator_button2' => 'Varchar',
		'simulator_button3' => 'Varchar',
		'simulator_button4' => 'Varchar',
		'simulator_button5' => 'Varchar'
	];

	public function __construct() {
		$path = Controller::curr()->getRequest()->getURL();
		if (preg_match("|^admin/settings|", $path)) {
			Requirements::css('simulators/css/settings.css');
			Requirements::javascript('simulators/javascript/settings.js');
			Requirements::javascript('silverstripe/admin:client/dist/js/i18n.js');
			Requirements::add_i18n_javascript('simulators/javascript/lang');
		}
		parent::__construct();
	}

	public function updateCMSFields(FieldList $fields) 
	{
		if (!$fields->fieldByName('Root.simulator')) {
			$fields->addFieldToTab('Root', TabSet::create('simulator', _t(__CLASS__ . '.SIMULATORS', 'Simulators')));
		}
		$fields->findOrMakeTab('Root.simulator.BaseURL', _t(__CLASS__ . '.G6KAPISERVER', "G6K API Server"));
		$fields->addFieldsToTab('Root.simulator.BaseURL', [
			new TextField('simulator_baseURL',  _t(__CLASS__ . '.BASEURL', 'Base url of the server'))
		]);
		$fields->findOrMakeTab('Root.simulator.Markup', _t(__CLASS__ . '.MARKUP', 'Markup'));
		$fields->addFieldsToTab('Root.simulator.Markup', [
			DropdownField::create( 'simulator_markup', _t(__CLASS__ . '.HTMLMARKUP', 'HTML Markup'), [
				'fragment' => _t(__CLASS__ . '.HTMLFRAGMENT', 'HTML fragment only'),
				'page' => _t(__CLASS__ . '.FULLHTML', 'Full HTML page')
			]),
			new CheckboxField ('simulator_addBootstrapClasses', _t(__CLASS__ . '.BOOTSTRAPCLASSES', 'Adding Bootstrap classes'), '0'),
			new TextField('simulator_bootstrapVersion', _t(__CLASS__ . '.BOOTSTRAPVERSION', 'Bootstrap version'), ''),
			new CheckboxField ('simulator_addBootstrapStylesheet', _t(__CLASS__ . '.BOOTSTRAPSTYLESHEET', 'Adding Bootstrap stylesheet'), '0'),
			new CheckboxField ('simulator_addBootstrapScript', _t(__CLASS__ . '.BOOTSTRAPLIBRARY', 'Adding Bootstrap library'), '0'),
			new CheckboxField ('simulator_addJQueryScript', _t(__CLASS__ . '.JQUERYLIBRARY', 'Adding jQuery library'), '0') 
		]);
		$fields->findOrMakeTab('Root.simulator.Colors', _t(__CLASS__ . '.COLORS', 'Colors'));
		$fields->addFieldsToTab('Root.simulator.Colors', [
			new TextField('simulator_primaryColor', _t(__CLASS__ . '.PRIMARYCOLOR', 'Primary color'), '#2b4e6b'),
			new TextField('simulator_secondaryColor', _t(__CLASS__ . '.SECONDARYCOLOR', 'Secondary color'), '#c0c0c0'),
			new TextField('simulator_breadcrumbColor', _t(__CLASS__ . '.BREADCRUMBCOLOR', 'Breadcrumb color'), '#2b4e6b'),
			new TextField('simulator_tabColor', _t(__CLASS__ . '.TABCOLOR', 'Tab color'), '#2b4e6b'),
			new TextField('simulator_globalErrorColor', _t(__CLASS__ . '.GLOBALERRORCOLOR', 'Global error color'), '#ff0000'),
			new TextField('simulator_globalWarningColor', _t(__CLASS__ . '.GLOBALWARNINGCOLOR', 'Global warning color'), '#800000'),
			new TextField('simulator_fieldErrorColor', _t(__CLASS__ . '.FIELDERRORCOLOR', 'Field error color'), '#ff0000'),
			new TextField('simulator_fieldWarningColor', _t(__CLASS__ . '.FIELDWARNINGCOLOR', 'Field warning color'), '#800000')
		]);
		$fields->findOrMakeTab('Root.simulator.Font', _t(__CLASS__ . '.FONT', 'Font'));
		$fields->addFieldsToTab('Root.simulator.Font', [
			new TextField('simulator_fontFamily', _t(__CLASS__ . '.FONTFAMILY', 'Font family'), 'Arial, Verdana'),
			new TextField('simulator_fontSize', _t(__CLASS__ . '.FONTSIZE', 'Font size'), '1em')
		]);
		$fields->findOrMakeTab('Root.simulator.DataObservers', _t(__CLASS__ . '.DATAOBSERVERS', 'Data Observers'));
		$fields->addFieldsToTab('Root.simulator.DataObservers', [
			new TextField('simulator_data1', _t(__CLASS__ . '.DATA1', 'Data 1'), ''),
			new TextField('simulator_data2', _t(__CLASS__ . '.DATA2', 'Data 2'), ''),
			new TextField('simulator_data3', _t(__CLASS__ . '.DATA3', 'Data 3'), ''),
			new TextField('simulator_data4', _t(__CLASS__ . '.DATA4', 'Data 4'), ''),
			new TextField('simulator_data5', _t(__CLASS__ . '.DATA5', 'Data 5'), '')
		]);
		$fields->findOrMakeTab('Root.simulator.ButtonsObservers', _t(__CLASS__ . '.BUTTONSOBSERVERS', 'Buttons Observers'));
		$fields->addFieldsToTab('Root.simulator.ButtonsObservers', [
			new TextField('simulator_button1', _t(__CLASS__ . '.BUTTON1', 'Button 1'), ''),
			new TextField('simulator_button2', _t(__CLASS__ . '.BUTTON2', 'Button 2'), ''),
			new TextField('simulator_button3', _t(__CLASS__ . '.BUTTON3', 'Button 3'), ''),
			new TextField('simulator_button4', _t(__CLASS__ . '.BUTTON4', 'Button 4'), ''),
			new TextField('simulator_button5', _t(__CLASS__ . '.BUTTON5', 'Button 5'), '')
		]);
	}
}