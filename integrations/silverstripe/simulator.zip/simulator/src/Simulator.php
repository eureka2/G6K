<?php

namespace Simulator\ShortCode;

use SilverStripe\CMS\Model\SiteTree;
use Silverstripe\SiteConfig\SiteConfig;
use SilverStripe\View\Requirements;
use SilverStripe\Control\Director;

class Simulator extends SiteTree {

	private static $casting = [
		'simulator' => 'HTMLText'
	];

	private static function url($simulator, $baseUrl = null) {
		if (null === $baseUrl) {
			$config = SiteConfig::current_site_config();
			$baseUrl = $config->simulator_baseURL;
		}
		if (Director::is_https()) {
			$baseUrl = preg_replace("|^http:|", "https:", $baseUrl);
		} else {
			$baseUrl = preg_replace("|^https:|", "http:", $baseUrl);
		}
		return $baseUrl . '/' . $simulator . '/api';
	}

	private static function attributes(string $simulator = null) {
		$url = self::url($simulator) . '/json';
		[$ok, $api] = self::fetch($url);
		if ($ok) {
			$api = json_decode($api, true);
			return $api['data']['attributes'];
		} else {
			return [ 'title' => $api, 'description' => $api ];
		}
	}

	private static function simulators($baseUrl = null) {
		$url = self::url('simulators', $baseUrl);
		[$ok, $api] = self::fetch($url);
		$simulators = [];
		if ($ok) {
			$api = json_decode($api, true);
			$data = $api['included']['data'];
			foreach($data as $simu) {
				$simulators[] = $simu['id'];
			}
			return $simulators;
		}
		return false;
	}

	private static function options($simulator) {
		$config = SiteConfig::current_site_config();
		$options = [
			'markup' => $config->simulator_markup ?? 'fragment', // 'fragment' or 'page'
			'primaryColor' => $config->simulator_primaryColor ?? '#2b4e6b', // optional
			'secondaryColor' => $config->simulator_secondaryColor ?? '#c0c0c0', // optional
			'breadcrumbColor' => $config->simulator_breadcrumbColor ?? '#2b4e6b', // optional
			'tabColor' => $config->simulator_tabColor ?? '#2b4e6b', // optional
			'globalErrorColor' => $config->simulator_globalErrorColor ?? '#ff0000', // optional
			'globalWarningColor' => $config->simulator_globalWarningColor ?? '#800000', // optional
			'fieldErrorColor' => $config->simulator_fieldErrorColor ?? '#ff0000', // optional
			'fieldWarningColor' => $config->simulator_fieldWarningColor ?? '#800000', // optional
			'fontFamily' => $config->simulator_fontFamily ?? 'Arial, Verdana', // optional
			'fontSize' => $config->simulator_fontSize ?? '1em', // optional
		];
		$bootstrap = $config->simulator_addBootstrapClasses ?? '0';
		if ('1' === $bootstrap) {
			$options['bootstrap'] = $config->simulator_bootstrapVersion ?? ''; // bootstrap version;
			$options['addBootstrapStylesheet'] = $config->simulator_addBootstrapStylesheet ?? '0' == '1' ? 'true' : 'false';
			$options['addBootstrapScript'] = $config->simulator_addBootstrapScript ?? '0' == '1' ? 'true' : 'false'; 
			$options['addJQueryScript'] = $config->simulator_addJQueryScript ?? '0'  == '1' ? 'true' : 'false';
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_data' . $i;
			$observer = $config->$field ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_button' . $i;
			$observer = $config->$field ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		return $options;
	}

	public static function parse_shortcode($arguments, $content = null, $parser = null, $tagName) {
		self::render($arguments, $content, $parser, $tagName);
	}

	public static function render($arguments, $content = null, $parser = null, $tagName) {
		Requirements::css('simulators/css/style.css');
		Requirements::javascript('simulators/javascript/script.js');
		$simulator = $arguments['name'];
		$options = self::options($simulator); 
		[$ok, $markup] = self::fetch(self::url($simulator) . '/html', $options);
		return $markup;
	}

	public static function fetch(string $url, array $options = []) {
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST"); 
		curl_setopt($ch, CURLOPT_FAILONERROR, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $options);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		$result = curl_exec($ch);
		if (!curl_errno($ch)){
			$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			$ok = $status == 200;
		} else {
			$ok = false;
			$result =  "Oops, something went wrong. Please try again later. " . $url . " #: " . curl_error($ch);
		}
		curl_close($ch);
		return [$ok, $result];
		
	}
}