window.addEventListener('DOMContentLoaded', function(event) {

	var baseServerUrl = null;
	var baseServerUrlValidated = '';
	var addingBootstrap = null;
	var bootstrapVersion = null;
	var addingStyleSheet = null;
	var addingLibrary = null;
	var addingJQuery = null;
	var fontSize = null;
	var dataObservers = [];
	var buttonObservers = [];
	var simulators = null;

	function fetchSimulators() {
		return new Promise(function (resolve, reject) {
			var xhr = new XMLHttpRequest();
			xhr.open('POST', baseServerUrl.value + '/simulators/api', true);
			// xhr.responseType = 'json';
			xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			xhr.onload = function() {
				if (xhr.status === 200) {
					var response = JSON.parse(xhr.responseText);
					response = response['included']['data'];
					var simus =  [];
					response.forEach (simu => simus.push(simu.id));
					resolve(simus);
				} else {
					reject(null);
				}
			};
			xhr.onerror  = function() {
				reject(null);
			};
			xhr.send(null);
		});
	}

	function hide(input) {
		if (input !== null) {
			var container = input.closest('.form-group');
			if (container !== null) {
				container.classList.add('simulator-settings-field-hidden');
			}
		}
	}

	function show(input) {
		if (input !== null) {
			var container = input.closest('.form-group');
			if (container !== null) {
				container.classList.remove('simulator-settings-field-hidden');
			}
		}
	}

	async function validateBaseServerUrl(callback) {
		if (baseServerUrl.value === '') {
			addError(baseServerUrl, ss.i18n._t("Simulator.BASE_URL_REQUIRED"));
		} else if (!/^https?:\/\/.+$/.test(baseServerUrl.value)) {
			addError(baseServerUrl, ss.i18n._t("Simulator.BASE_URL_INVALID"));
		} else {
			try {
				if (baseServerUrlValidated != baseServerUrl.value || simulators === null) {
					addNotice(baseServerUrl, ss.i18n.sprintf(ss.i18n._t("Simulator.BASE_URL_ACCESS"), baseServerUrl.value), 50);
					simulators = await fetchSimulators();
					if (simulators === null) {
						baseServerUrl.closest('.form-group').classList.add('has-error');
						return;
					}
				}
				baseServerUrlValidated = baseServerUrl.value;
				removeError(baseServerUrl);
				callback && callback();
			} catch(error) {
				addError(baseServerUrl, ss.i18n.sprintf(ss.i18n._t("Simulator.BASE_URL_NOT_RESPONDING"), baseServerUrl.value));
			}
		}
	}

	function validateFontSize() {
		if (fontSize.value !== '') {
			var allowedSizes = [ 'xx-small', 'x-small', 'small', 'medium', 'large', 'x-large', 'xx-large', 'larger', 'smaller', 'inherit', 'initial', 'unset' ];
			if (allowedSizes.indexOf(fontSize.value) < 0) {
				if (!/^\d+(\.\d+)?(px|pt|pc|ex|cm|mm|in|em|rem|%)$/.test(fontSize.value)) {
					addError(fontSize, ss.i18n.sprintf(ss.i18n._t("Simulator.FONTSIZE_INVALID"), fontSize.value));
					return false;
				}
			}
		}
		removeError(fontSize);
		return true;
	}

	function validateBootstrapVersion() {
		if (addingBootstrap.checked) {
			if (bootstrapVersion.value == '') { 
				addError(bootstrapVersion, ss.i18n._t("Simulator.BOOTSTRAP_VERSION_REQUIRED"));
				return false;
			} else if (!/^\d+\.\d+\.\d+$/.test(bootstrapVersion.value)) {
				addError(bootstrapVersion, ss.i18n._t("Simulator.BOOTSTRAP_VERSION_INVALID"));
				return false;
			}
		} else if (bootstrapVersion.value !== '') {
			addError(bootstrapVersion, ss.i18n._t("Simulator.BOOTSTRAP_VERSION_NOT_EMPTY"));
			return false;
		}
		removeError(bootstrapVersion);
		return true;
	}

	function validateDataObserver(num) {
		var observer = dataObservers[num];
		if (observer.value != '') {
			var m = observer.value.match(/^([\-\w]+):[\-\w]+$/);
			if (m) {
				if (simulators !== null && simulators.indexOf(m[1]) < 0) {
					addError(observer, ss.i18n.sprintf(ss.i18n._t("Simulator.SIMULATOR_UNKNOWN"), m[1]));
					return false;
				}
			} else {
				addError(observer, ss.i18n.sprintf(ss.i18n._t("Simulator.DATA_OBSERVER_INVALID"), observer.value));
				return false;
			}
		}
		removeError(observer);
		return true;
	}

	function validateDataObservers() {
		var ok = true;
		for (var i = 0; i < 5; i++) {
			if (dataObservers[i]) {
				if (!validateDataObserver(i)) {
					ok = false;
				}
			}
		}
		return ok;
	}

	function validateButtonObserver(num) {
		var observer = buttonObservers[num];
		if (observer.value != '') {
			var m = observer.value.match(/^([\-\w]+):[\-\w]+$/);
			if (m) {
				if (simulators !== null && simulators.indexOf(m[1]) < 0) {
					addError(observer, ss.i18n.sprintf(ss.i18n._t("Simulator.SIMULATOR_UNKNOWN"), m[1]));
					return false;
				}
			} else {
				addError(observer, ss.i18n.sprintf(ss.i18n._t("Simulator.BUTTON_OBSERVER_INVALID"), observer.value));
				return false;
			}
		}
		removeError(observer);
		return true;
	}

	function validateButtonObservers() {
		var ok = true;
		for (var i = 0; i < 5; i++) {
			if (buttonObservers[i]) {
				if (!validateButtonObserver(i)) {
					ok = false;
				}
			}
		}
		return ok;
	}

	function addError(input, error, duration) {
		var messageField = input.parentElement.querySelector('.simulator-alert');
		messageField.textContent = error;
		messageField.classList.remove('simulator-settings-field-hidden');
		input.closest('.form-group').classList.add('has-error');
		input.closest('.form-group').classList.remove('has-notice');
		if (duration) {
			setTimeout(function(e) {
				removeError(input);
			}, duration * 1000);
		}
	}

	function addNotice(input, notice, duration) {
		var messageField = input.parentElement.querySelector('.simulator-alert');
		messageField.textContent = notice;
		messageField.classList.remove('simulator-settings-field-hidden');
		input.closest('.form-group').classList.add('has-notice');
		input.closest('.form-group').classList.remove('has-error');
		if (duration) {
			setTimeout(function(e) {
				removeNotice(input);
			}, duration * 1000);
		}
	}

	function removeError(input) {
		var messageField = input.parentElement.querySelector('.simulator-alert');
		messageField.textContent = '';
		messageField.classList.add('simulator-settings-field-hidden');
		input.closest('.form-group').classList.remove('has-error');
	}

	function removeNotice(input) {
		var messageField = input.parentElement.querySelector('.simulator-alert');
		messageField.textContent = '';
		messageField.classList.add('simulator-settings-field-hidden');
		input.closest('.form-group').classList.remove('has-notice');
	}

	function addMessageField(input) {
		var messageField = document.createElement('div');
		messageField.classList.add('simulator-alert', 'simulator-settings-field-hidden');
		input.parentElement.appendChild(messageField);
	}

	function fixColorField(input, deflt) {
		if (input.value == '') {
			input.value = deflt;
		}
		var colorSpan = document.createElement('span');
		colorSpan.textContent = input.value;
		colorSpan.classList.add('simulator-color-value');
		var color = input.insertAdjacentElement('afterend', colorSpan);
		input.type = 'color';
		input.classList.replace('text', 'simulator-color');
		input.addEventListener('change', function(e) {
			colorSpan.textContent = this.value;
		});
	}

	function validateAll() {
		return validateBootstrapVersion()
			&& validateFontSize()
			&& validateDataObservers()
			&& validateButtonObservers();
	}

	function register(input) {
		if (input.name == 'simulator_baseURL') {
			addMessageField(input);
			if (baseServerUrl === null) {
				baseServerUrl = input;
			} else if (baseServerUrl !== input) {
				baseServerUrl = input;
				simulators = null;
			}
			baseServerUrl.addEventListener('blur', function(e) {
				validateBaseServerUrl();
			});
		} else if (input.name == 'simulator_addBootstrapClasses') {
			addingBootstrap = input;
			addingBootstrap.addEventListener('change', function(e) {
				if (this.checked) {
					show(bootstrapVersion);
					show(addingStyleSheet);
					show(addingLibrary);
					show(addingJQuery);
				} else {
					hide(bootstrapVersion);
					hide(addingStyleSheet);
					hide(addingLibrary);
					hide(addingJQuery);
				}
			});
			var form = addingBootstrap.closest('form');
			if (form !== null) {
				var submitButton = form.querySelector("button[type='submit']");
				submitButton.addEventListener('click', function(e) {
					if (baseServerUrlValidated == '' || baseServerUrlValidated != baseServerUrl.value) {
						e.stopPropagation();
						e.preventDefault();
						validateBaseServerUrl(function() {
							if (validateAll()) {
								submitButton.dispatchEvent(new MouseEvent('click'));
							}
						});
					} else if (! validateAll()) {
						e.stopPropagation();
						e.preventDefault();
					}
				});
			}
			setTimeout(function() {
				addingBootstrap.dispatchEvent(new Event('change'));
			}, 0);
		} else if (input.name == 'simulator_bootstrapVersion') {
			addMessageField(input);
			bootstrapVersion = input;
			bootstrapVersion.addEventListener('blur', function(e) {
				if (! validateBootstrapVersion()) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_addBootstrapStylesheet') {
			addingStyleSheet = input;
		} else if (input.name == 'simulator_addBootstrapScript') {
			addingLibrary = input;
		} else if (input.name == 'simulator_addJQueryScript') {
			addingJQuery = input;
		} else if (input.name == 'simulator_fontSize') {
			addMessageField(input);
			fontSize = input;
			fontSize.addEventListener('blur', function(e) {
				if (! validateFontSize()) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_primaryColor') {
			fixColorField(input, '#2b4e6b');
		} else if (input.name == 'simulator_secondaryColor') {
			fixColorField(input, '#c0c0c0');
		} else if (input.name == 'simulator_breadcrumbColor') {
			fixColorField(input, '#2b4e6b');
		} else if (input.name == 'simulator_tabColor') {
			fixColorField(input, '#2b4e6b');
		} else if (input.name == 'simulator_globalErrorColor') {
			fixColorField(input, '#ff0000');
		} else if (input.name == 'simulator_globalWarningColor') {
			fixColorField(input, '#800000');
		} else if (input.name == 'simulator_fieldErrorColor') {
			fixColorField(input, '#ff0000');
		} else if (input.name == 'simulator_fieldWarningColor') {
			fixColorField(input, '#800000');
		} else if (input.name == 'simulator_data1') {
			addMessageField(input);
			dataObservers[0] = input;
			dataObservers[0].addEventListener('blur', function(e) {
				if (! validateDataObserver(0)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_data2') {
			addMessageField(input);
			dataObservers[1] = input;
			dataObservers[1].addEventListener('blur', function(e) {
				if (! validateDataObserver(1)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_data3') {
			addMessageField(input);
			dataObservers[2] = input;
			dataObservers[2].addEventListener('blur', function(e) {
				if (! validateDataObserver(2)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_data4') {
			addMessageField(input);
			dataObservers[3] = input;
			dataObservers[3].addEventListener('blur', function(e) {
				if (! validateDataObserver(3)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_data5') {
			addMessageField(input);
			dataObservers[4] = input;
			dataObservers[4].addEventListener('blur', function(e) {
				if (! validateDataObserver(4)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_button1') {
			addMessageField(input);
			buttonObservers[0] = input;
			buttonObservers[0].addEventListener('blur', function(e) {
				if (! validateButtonObserver(0)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_button2') {
			addMessageField(input);
			buttonObservers[1] = input;
			buttonObservers[1].addEventListener('blur', function(e) {
				if (! validateButtonObserver(1)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_button3') {
			addMessageField(input);
			buttonObservers[2] = input;
			buttonObservers[2].addEventListener('blur', function(e) {
				if (! validateButtonObserver(2)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_button4') {
			addMessageField(input);
			buttonObservers[3] = input;
			buttonObservers[3].addEventListener('blur', function(e) {
				if (! validateButtonObserver(3)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'simulator_button5') {
			addMessageField(input);
			buttonObservers[4] = input;
			buttonObservers[4].addEventListener('blur', function(e) {
				if (! validateButtonObserver(4)) {
					e.preventDefault();
				}
			});
		}
	}

	var inputs = document.querySelectorAll("input:not([type='hidden']), select");
	inputs.forEach( input => {
		register(input);
	});
});

