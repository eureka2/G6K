(function () {

	if (typeof tinymce !== 'undefined') {
		var plugin = document.currentScript.src;
		tinymce.PluginManager.add('simulators', function(editor, url) {
			var translate = tinymce.util.I18n.translate;
			if (editor.ui) {
				var openDialog = function () {
					return editor.windowManager.open({
						title: translate('Insert simulator'),
						body: {
							type: 'panel',
							items: [
								{
									type: 'input',
									name: 'name',
									label: translate('Simulator name')
								}
							]
						},
						buttons: [
							{
								type: 'button',
								text: translate('Close')
							},
							{
								type: 'submit',
								text: translate('Save'),
								primary: true
							}
						],
						onSubmit: function (api) {
							var data = api.getData();
							/* Insert content when the window form is submitted */
							editor.insertContent('[simulator,name="' + data.name + '"]');
							api.close();
						}
					});
				};
				/* Add a button that opens a window */
				editor.ui.registry.addButton('simulators', {
					text: translate('Insert simulator'),
					'class': 'mce_shortcode',
					onAction: function () {
						/* Open window */
						openDialog();
					}
				});
				/* Adds a menu item, which can then be included in any menu via the menu/menubar configuration */
				editor.ui.registry.addMenuItem('simulators', {
					text: translate('Insert simulator'),
					onAction: function() {
						/* Open window */
						openDialog();
					}
				});
			} else {
				editor.addButton('simulators', {
					tooltip: translate('Insert simulator'),
					image: plugin.replace(/javascript\/editor\/.+$/, 'images/simulators.png'),
					onclick: function() {
						editor.windowManager.open({
							title: translate('Insert simulator'),
							body: [
								{
									type: 'textbox',
									name: 'name',
									label: translate('Simulator name')
								}
							],
							onsubmit: function (api) {
								/* Insert content when the window form is submitted */
								editor.insertContent('[simulator,name="' + api.data.name + '"]');
							}
						});
					}
				});
			}
		});
		tinymce.PluginManager.requireLangPack('simulators', 'fr_FR,en,es,pt_BR,pt_PT,it');
	}

})();

