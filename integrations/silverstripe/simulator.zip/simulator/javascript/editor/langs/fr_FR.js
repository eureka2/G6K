tinymce.addI18n('fr_FR', {
    'Simulator name': 'Nom du simulateur',
    'Close': 'Fermer',
    'Save': 'Enregistrer',
    'Insert simulator': 'Insérer un simulateur',
    'Insert simulator plugin': "Plugin d'insertion de simulateurs"
});
