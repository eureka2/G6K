tinymce.addI18n('es', {
     'Simulator name': 'Nombre del simulador',
     'Close': 'Cerca',
     'Save': 'Guardar',
     'Insert simulator': 'Insertar un simulador',
     'Insert simulator plugin': 'Insertar complemento de simulador'
});
