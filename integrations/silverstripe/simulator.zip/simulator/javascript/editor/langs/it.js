tinymce.addI18n('it', {
     "Simulator name": "Nome del simulatore",
     "Close": "Chiudi",
     "Save": "Salva",
     'Insert simulator': 'Inserisci un simulatore',
     "Insert simulator plugin": "Inserisci plug-in del simulatore"
});
