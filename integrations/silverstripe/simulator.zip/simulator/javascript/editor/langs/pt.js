tinymce.addI18n('pt', {
     'Simulator name': 'Nome do simulador',
     'Close': 'Fechar',
     'Save': 'Salvar',
     'Insert simulator': 'Insira um simulador',
     'Insert simulator plugin': 'Inserir plugin do simulador'
});
