tinymce.addI18n('en', {
    'Simulator name': 'Simulator name',
    'Close': 'Close',
    'Save': 'Save',
    'Insert simulator': 'Insert simulator',
    'Insert simulator plugin': 'Insert simulator plugin'
});
