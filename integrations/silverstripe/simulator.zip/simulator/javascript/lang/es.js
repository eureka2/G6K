if (typeof(ss) === 'undefined' || typeof(ss.i18n) === 'undefined') {
  if (typeof(console) !== 'undefined') {
    console.error('Class ss.i18n not defined');
  }
} else {
  ss.i18n.addDictionary('es', {
     "Simulator.BASE_URL_REQUIRED": "Se requiere la URL base del servidor",
     "Simulator.BASE_URL_INVALID": "La URL base del servidor no es válida",
     "Simulator.BASE_URL_ACCESS": "Acceso al servidor '%s' en curso ....",
     "Simulator.BASE_URL_NOT_RESPONDING": "El servidor '%s' no responde o no es un servidor API G6K.",
     "Simulator.FONTSIZE_INVALID": "El tamaño de fuente '%s' no es válido.",
     "Simulator.BOOTSTRAP_VERSION_REQUIRED": "Se requiere la versión de arranque",
     "Simulator.BOOTSTRAP_VERSION_INVALID": "La versión de arranque no tiene el formato requerido",
     "Simulator.BOOTSTRAP_VERSION_NOT_EMPTY": "La versión de arranque debe estar vacía",
     "Simulator.SIMULATOR_UNKNOWN": "El servidor API no conoce el simulador '%s'",
     "Simulator.DATA_OBSERVER_INVALID": "Los datos '%s' a observar no están en el formato requerido",
     "Simulator.BUTTON_OBSERVER_INVALID": "El botón '%s' a observar no está en el formato requerido"
   });
}
