if (typeof(ss) === 'undefined' || typeof(ss.i18n) === 'undefined') {
  if (typeof(console) !== 'undefined') {
    console.error('Class ss.i18n not defined');
  }
} else {
  ss.i18n.addDictionary('it', {
     "Simulator.BASE_URL_REQUIRED": "È richiesto l'URL di base del server",
     "Simulator.BASE_URL_INVALID": "L'URL di base del server non è valido",
     "Simulator.BASE_URL_ACCESS": "Accesso al server '%s' in corso ....",
     "Simulator.BASE_URL_NOT_RESPONDING": "Il server '%s' non risponde o non è un server API G6K.",
     "Simulator.FONTSIZE_INVALID": "La dimensione del carattere '%s' non è valida.",
     "Simulator.BOOTSTRAP_VERSION_REQUIRED": "La versione bootstrap è richiesta",
     "Simulator.BOOTSTRAP_VERSION_INVALID": "La versione bootstrap non è nel formato richiesto",
     "Simulator.BOOTSTRAP_VERSION_NOT_EMPTY": "La versione bootstrap deve essere vuota",
     "Simulator.SIMULATOR_UNKNOWN": "Il simulatore '%s' non è conosciuto dal server API",
     "Simulator.DATA_OBSERVER_INVALID": "I dati '%s' da osservare non sono nel formato richiesto",
     "Simulator.BUTTON_OBSERVER_INVALID": "Il pulsante '%s' da osservare non è nel formato richiesto"
  });
}
