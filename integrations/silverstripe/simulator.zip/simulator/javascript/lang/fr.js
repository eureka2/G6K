if (typeof(ss) === 'undefined' || typeof(ss.i18n) === 'undefined') {
  if (typeof(console) !== 'undefined') {
    console.error('Class ss.i18n not defined');
  }
} else {
  ss.i18n.addDictionary('fr', {
     "Simulator.BASE_URL_REQUIRED": "L'URL de base du serveur est requise",
     "Simulator.BASE_URL_INVALID": "L'URL de base du serveur est invalide",
     "Simulator.BASE_URL_ACCESS": "Accès au serveur '%s' en cours ....",
     "Simulator.BASE_URL_NOT_RESPONDING": "Le serveur '%s' ne répond pas ou n'est pas un serveur API G6K.",
     "Simulator.FONTSIZE_INVALID": "La taille de police '%s' n'est pas valide.",
     "Simulator.BOOTSTRAP_VERSION_REQUIRED": "La version de Bootstrap est requise",
     "Simulator.BOOTSTRAP_VERSION_INVALID": "La version de Bootstrap n'est pas au format requis",
     "Simulator.BOOTSTRAP_VERSION_NOT_EMPTY": "La version de Bootstrap ne doit pas être renseignée",
     "Simulator.SIMULATOR_UNKNOWN": "Le simulateur '%s' n'est pas connu du serveur d'API",
     "Simulator.DATA_OBSERVER_INVALID": "La donnée '%s' à observer n'est pas au format requis",
     "Simulator.BUTTON_OBSERVER_INVALID": "Le bouton '%s' à observer n'est pas au format requis"
  });
}
