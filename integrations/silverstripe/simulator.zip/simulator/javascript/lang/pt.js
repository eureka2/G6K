if (typeof(ss) === 'undefined' || typeof(ss.i18n) === 'undefined') {
  if (typeof(console) !== 'undefined') {
    console.error('Class ss.i18n not defined');
  }
} else {
  ss.i18n.addDictionary('pt', {
     "Simulator.BASE_URL_REQUIRED": "O url base do servidor é obrigatório",
     "Simulator.BASE_URL_INVALID": "O url base do servidor é inválido",
     "Simulator.BASE_URL_ACCESS": "Acesso ao servidor '%s' em andamento ....",
     "Simulator.BASE_URL_NOT_RESPONDING": "O servidor '%s' não está respondendo ou não é um servidor G6K API.",
     "Simulator.FONTSIZE_INVALID": "O tamanho da fonte '%s' é inválido.",
     "Simulator.BOOTSTRAP_VERSION_REQUIRED": "A versão bootstrap é necessária",
     "Simulator.BOOTSTRAP_VERSION_INVALID": "A versão do bootstrap não está no formato necessário",
     "Simulator.BOOTSTRAP_VERSION_NOT_EMPTY": "A versão do bootstrap deve estar vazia",
     "Simulator.SIMULATOR_UNKNOWN": "O simulador '%s' não é conhecido pelo servidor API",
     "Simulator.DATA_OBSERVER_INVALID": "Os dados '%s' a serem observados não estão no formato exigido",
     "Simulator.BUTTON_OBSERVER_INVALID": "O botão '%s' a ser observado não está no formato exigido"
  });
}
