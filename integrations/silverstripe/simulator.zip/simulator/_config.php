<?php

use SilverStripe\View\Parsers\ShortcodeParser;
use Simulator\ShortCode\Simulator;
use SilverStripe\Forms\HTMLEditor\HtmlEditorConfig;
use SilverStripe\Core\Manifest\ModuleLoader;

// HtmlEditorConfig::get('cms')->enablePlugins('simulator');

$configs = array_keys(HtmlEditorConfig::get_available_configs_map());
$name = end($configs);
$editor = HtmlEditorConfig::get($name);
$pluginPath = ModuleLoader::getModule('simulators')->getResource('javascript/editor/editor.js')->getURL();
$editor->enablePlugins(['simulators' => $pluginPath]);
$editor->addButtonsToLine(2, 'simulators');

$contentCSS = (array)$editor->getOption('editor_css');
$contentCSS[] = ModuleLoader::getModule('simulators')->getResource('css/editor.css')->getURL();
$editor->setOption('editor_css', $contentCSS);

ShortcodeParser::get('default')->register('simulator', [Simulator::class, 'render']);
