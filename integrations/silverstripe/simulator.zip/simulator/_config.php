<?php

use SilverStripe\View\Parsers\ShortcodeParser;
use Simulator\ShortCode\Simulator;
use SilverStripe\i18n\i18n;

ShortcodeParser::get('default')->register('simulator', [Simulator::class, 'render']);
i18n::set_locale('fr_FR');