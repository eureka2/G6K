<?php

if (!defined("_ECRIRE_INC_VERSION")) {
	return;
}

function filtre_set_name($set) {
	$name = _request('name') ?? request('nom');
	return $name ? $name : 'demo';
}

function simulateur_token() {
	return substr(md5(rand(0, 1000000) . 'simulateur'), 0, 6);
}

function simulateur_url($simulator = null, $baseUrl = null) {
	if (null === $baseUrl) {
		$baseUrl = lire_config('simulateur/base_server_url');
	}
	$scheme = preg_replace("/:\/\/.*$/", "", url_de_base());
	return preg_replace("/^https?/", $scheme, $baseUrl) . "/" . $simulator . "/api";
}

function simulateur_attributes(string $simulator = null) {
	$url = simulateur_url($simulator) . '/json';
	[$ok, $api] = fetch($url);
	if ($ok) {
		$api = json_decode($api, true);
		return $api['data']['attributes'];
	} else {
		return [ 'title' => $api, 'description' => $api ];
	}
}

function simulateur_title(string $simulator = null) {
	$attributes = simulateur_attributes($simulator);
	return $attributes[ 'title' ];
}

function simulateur_description(string $simulator = null) {
	$attributes = simulateur_attributes($simulator);
	return $attributes[ 'description' ];
}

function simulateur_simulators($baseUrl = null) {
	$url = simulateur_url('simulators', $baseUrl);
	[$ok, $api] = $this->fetch($url);
	$simulators = [];
	if ($ok) {
		$api = json_decode($api, true);
		$data = $api['included']['data'];
		foreach($data as $simu) {
			$simulators[] = $simu['id'];
		}
		return $simulators;
	}
	return false;
}

function simulateur_markup($simulator) {
	$url = simulateur_url($simulator) . '/html';
	$options = [
		'markup' => lire_config('simulateur/html_markup', 'fragment'), // 'fragment' or 'page'
		'primaryColor' => lire_config('simulateur/primary_color', '#2b4e6b'), // optional
		'secondaryColor' => lire_config('simulateur/secondary_color', ''), // optional
		'breadcrumbColor' => lire_config('simulateur/breadcrumb_color', '#2b4e6b'), // optional
		'tabColor' => lire_config('simulateur/tab_color', '#2b4e6b'), // optional
		'globalErrorColor' => lire_config('simulateur/global_error_color', '#ff0000'), // optional
		'globalWarningColor' => lire_config('simulateur/global_warning_color', '#800000'), // optional
		'fieldErrorColor' => lire_config('simulateur/field_error_color', '#ff0000'), // optional
		'fieldWarningColor' => lire_config('simulateur/field_warning_color', '#800000'), // optional
		'fontFamily' => lire_config('simulateur/font_family', 'Arial, Verdana'), // optional
		'fontSize' => lire_config('simulateur/font_size', '1em'), // optional
	];
	$bootstrap = lire_config('simulateur/adding_bootstrap_classes', '0');
	if ('1' === $bootstrap) {
		$options['bootstrap'] = lire_config('simulateur/bootstrap_version'); // bootstrap version;
		$options['addBootstrapStylesheet'] = lire_config('simulateur/adding_bootstrap_stylesheet', '0')  == '1' ? 'true' : 'false';
		$options['addBootstrapScript'] = lire_config('simulateur/adding_bootstrap_library', '0') == '1' ? 'true' : 'false'; 
		$options['addJQueryScript'] = lire_config('simulateur/adding_jquery_library', '0')== '1' ? 'true' : 'false';
	}
	for ($i = 1; $i <= 5; $i++) {
		$observer = lire_config('simulateur/data' . $i . '_observer');
		if ($observer != '') {
			if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
				if ($m[1] == $simulator) {
					$options[$m[2]] = 'ResultObserver.field';
				}
			}
		}
	}
	for ($i = 1; $i <= 5; $i++) {
		$observer = lire_config('simulateur/button' . $i . '_observer');
		if ($observer != '') {
			if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
				if ($m[1] == $simulator) {
					$options[$m[2]] = 'ResultObserver.button';
				}
			}
		}
	}
	[$ok, $markup] = fetch($url, $options);
	return $markup;
}

	function fetch(string $url, array $options = []) {
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST"); 
		curl_setopt($ch, CURLOPT_FAILONERROR, true);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $options);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		$result = curl_exec($ch);
		if (!curl_errno($ch)){
			$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			$ok = $status == 200;
		} else {
			$ok = false;
			$result =  "Oops, something went wrong. Please try again later. " . $url . " #: " . curl_error($ch);
		}
		curl_close($ch);
		return [$ok, $result];
		
	}