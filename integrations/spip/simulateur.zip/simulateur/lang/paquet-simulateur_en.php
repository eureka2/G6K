<?php

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = [

	// S
	'simulateur_description' => "The simulator is inserted into an article using the tag: <code><simulateur|name=simulatorname> </code>",
	'simulateur_nom' => "Integration of the G6K API into SPIP",
	'simulateur_slogan' => "Integration of the simulators developed with the G6K API into the SPIP articles"
];
