<?php

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = [

	// S
	'simulateur_description' => "Le simulateur s’insère dans un article au moyen du tag : <code><simulateur|nom=nomsimulateur></code>",
	'simulateur_nom' => "Intégration de l'API G6K à SPIP",
	'simulateur_slogan' => "Intégration des simulateurs développés avec l'API G6K aux articles SPIP"
];
