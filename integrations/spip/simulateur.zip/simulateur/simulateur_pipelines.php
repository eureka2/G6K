<?php

if (!defined("_ECRIRE_INC_VERSION")) return;

function simulateur_timestamp($fichier) {
	if ($m = filemtime($fichier)) {
		return "$fichier?$m";
	}
	return $fichier;
}

function simulateur_insert_head($flux) {
	if (test_espace_prive()) {
		$lang = utiliser_langue_visiteur();
		if (! file_exists(__DIR__ . '/javascript/lang/' . $lang . '.js')) {
			$lang = 'en';
		}
		$flux .= '<script src="' . simulateur_timestamp(find_in_path('javascript/lang/' . $lang . '.js')) . '" type="text/javascript"></script>';
		$flux .= '<script src="' . simulateur_timestamp(find_in_path('javascript/settings.js')) . '" type="text/javascript"></script>';
	} else {
		$flux .= '<script src="' . simulateur_timestamp(find_in_path('javascript/script.js')) . '" type="text/javascript"></script>';
	}
	return $flux;
}

function simulateur_insert_head_css($flux) {
	if (test_espace_prive()) {
		$css = find_in_path('stylesheets/settings.css');
		$flux .= "<link rel='stylesheet' type='text/css' media='all' href='$css' />";
	} else {
		$css = find_in_path('stylesheets/style.css');
		$flux .= "<link rel='stylesheet' type='text/css' media='all' href='$css' />";
	}
	return $flux;
}
