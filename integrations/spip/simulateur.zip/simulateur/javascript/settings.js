window.addEventListener('DOMContentLoaded', function(event) {

		var Simulator = {};

		var baseServerUrl = null;
		var baseServerUrlValidated = '';
		var addingBootstrap = null;
		var bootstrapVersion = null;
		var addingStyleSheet = null;
		var addingLibrary = null;
		var addingJQuery = null;
		var fontSize = null;
		var dataObservers = [];
		var buttonObservers = [];
		var simulators = null;

		function fetchSimulators() {
			return new Promise(function (resolve, reject) {
				var xhr = new XMLHttpRequest();
				xhr.open('POST', baseServerUrl.value + '/simulators/api', true);
				xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
				xhr.onload = function() {
					if (xhr.status === 200) {
						var response = JSON.parse(xhr.responseText);
						response = response['included']['data'];
						var simus =  [];
						response.forEach (simu => simus.push(simu.id));
						resolve(simus);
					} else {
						reject(null);
					}
				};
				xhr.onerror  = function() {
					reject(null);
				};
				xhr.send(null);
			});
		}

		function hide(input) {
			if (input !== null) {
				var container = input.closest('.form-group');
				if (container !== null) {
					container.style.display = 'none';
				}
			}
		}

		function show(input) {
			if (input !== null) {
				var container = input.closest('.form-group');
				if (container !== null) {
					container.style.display = '';
				}
			}
		}

		function removeMessage(input) {
			var elt = input.nextElementSibling;
			if (elt !== null && (elt.classList.contains('simulator-field-error') || elt.classList.contains('simulator-field-info'))) {
				elt.parentElement.removeChild(elt);
			}
		}

		function error(input, message) {
			var elt = input.nextElementSibling;
			if (elt !== null && (elt.classList.contains('simulator-field-error') || elt.classList.contains('simulator-field-info'))) {
				elt.classList.remove('simulator-field-info');
			} else {
				var elt = document.createElement('p');
				input.insertAdjacentElement('afterend', elt);
			}
			elt.classList.add('simulator-field-error');
			elt.textContent = message;
		}

		function info(input, message) {
			var elt = input.nextElementSibling;
			if (elt !== null && (elt.classList.contains('simulator-field-error') || elt.classList.contains('simulator-field-info'))) {
				elt.classList.remove('simulator-field-error');
			} else {
				var elt = document.createElement('p');
				input.insertAdjacentElement('afterend', elt);
			}
			elt.classList.add('simulator-field-info');
			elt.textContent = message;
		}

		async function validateBaseServerUrl(callback) {
			if (baseServerUrl.value === '') {
				error(baseServerUrl, _T["simulator_base_url_required"]);
				baseServerUrl.closest('.form-group').classList.add('has-error');
			} else if (!/^https?:\/\/.+$/.test(baseServerUrl.value)) {
				error(baseServerUrl, _T["simulator_base_url_invalid"]);
				baseServerUrl.closest('.form-group').classList.add('has-error');
			} else {
				try {
					if (baseServerUrlValidated != baseServerUrl.value || simulators === null) {
						info(baseServerUrl, _T["simulator_base_url_access"].replace("%s", baseServerUrl.value));
						simulators = await fetchSimulators();
						if (simulators === null) {
							baseServerUrl.closest('.form-group').classList.add('has-error');
							return;
						}
					}
					baseServerUrlValidated = baseServerUrl.value;
					baseServerUrl.closest('.form-group').classList.remove('has-error');
					removeMessage(baseServerUrl);
					callback && callback();
				} catch(err) {
					error(baseServerUrl, _T["simulator_base_url_not_responding"].replace("%s", baseServerUrl.value));
					baseServerUrl.closest('.form-group').classList.add('has-error');
				}
			}
		}

		function validateFontSize() {
			if (fontSize.value !== '') {
				var allowedSizes = [ 'xx-small', 'x-small', 'small', 'medium', 'large', 'x-large', 'xx-large', 'larger', 'smaller', 'inherit', 'initial', 'unset' ];
				if (allowedSizes.indexOf(fontSize.value) < 0) {
					if (!/^\d+(\.\d+)?(px|pt|pc|ex|cm|mm|in|em|rem|%)$/.test(fontSize.value)) {
						error(fontSize, _T["simulator_font_size_invalid"].replace("%s", fontSize.value));
						fontSize.closest('.form-group').classList.add('has-error');
						return false;
					}
				}
			}
			fontSize.closest('.form-group').classList.remove('has-error');
			removeMessage(fontSize);
			return true;
		}

		function validateBootstrapVersion() {
			if (addingBootstrap.checked) {
				if (bootstrapVersion.value == '') { 
					error(bootstrapVersion, _T["simulator_bootstrap_version_required"]);
					bootstrapVersion.closest('.form-group').classList.add('has-error');
					return false;
				} else if (!/^\d+\.\d+\.\d+$/.test(bootstrapVersion.value)) {
					error(bootstrapVersion, _T["simulator_bootstrap_version_invalid"]);
					bootstrapVersion.closest('.form-group').classList.add('has-error');
					return false;
				}
			} else if (bootstrapVersion.value !== '') {
				error(bootstrapVersion, _T["simulator_bootstrap_version_empty"]);
				bootstrapVersion.closest('.form-group').classList.add('has-error');
				return false;
			}
			bootstrapVersion.closest('.form-group').classList.remove('has-error');
			removeMessage(bootstrapVersion);
			return true;
		}

		function validateDataObserver(num) {
			var observer = dataObservers[num];
			if (observer.value != '') {
				var m = observer.value.match(/^([\-\w]+):[\-\w]+$/);
				if (m) {
					if (simulators !== null && simulators.indexOf(m[1]) < 0) {
						error(observer, _T["simulator_observer_not_known"].replace("%s", m[1]));
						observer.closest('.form-group').classList.add('has-error');
						return false;
					}
				} else {
					error(observer, _T["simulator_data_observer_invalid"].replace("%s", observer.value));
					observer.closest('.form-group').classList.add('has-error');
					return false;
				}
			}
			observer.closest('.form-group').classList.remove('has-error');
			removeMessage(observer);
			return true;
		}

		function validateDataObservers() {
			var ok = true;
			for (var i = 0; i < 5; i++) {
				if (dataObservers[i]) {
					if (!validateDataObserver(i)) {
						ok = false;
					}
				}
			}
			return ok;
		}

		function validateButtonObserver(num) {
			var observer = buttonObservers[num];
			if (observer.value != '') {
				var m = observer.value.match(/^([\-\w]+):[\-\w]+$/);
				if (m) {
					if (simulators !== null && simulators.indexOf(m[1]) < 0) {
						error(observer, _T["simulator_unknown"].replace("%s", m[1]));
						observer.closest('.form-group').classList.add('has-error');
						return false;
					}
				} else {
					error(observer, _T["simulator_button_invalid"].replace("%s", observer.value));
					observer.closest('.form-group').classList.add('has-error');
					return false;
				}
			}
			observer.closest('.form-group').classList.remove('has-error');
			removeMessage(observer);
			return true;
		}

		function validateButtonObservers() {
			var ok = true;
			for (var i = 0; i < 5; i++) {
				if (buttonObservers[i]) {
					if (!validateButtonObserver(i)) {
						ok = false;
					}
				}
			}
			return ok;
		}

		function validateAll() {
			return validateBootstrapVersion()
				&& validateFontSize()
				&& validateDataObservers()
				&& validateButtonObservers();
		}

		function register(input) {
			if (input.name == 'base_server_url') {
				if (baseServerUrl === null) {
					baseServerUrl = input;
				} else if (baseServerUrl !== input) {
					baseServerUrl = input;
					simulators = null;
				}
				baseServerUrl.addEventListener('blur', function(e) {
					validateBaseServerUrl();
				});
			} else if (input.name == 'adding_bootstrap_classes') {
				addingBootstrap = input;
				addingBootstrap.addEventListener('change', function(e) {
					if (this.checked) {
						show(bootstrapVersion);
						show(addingStyleSheet);
						show(addingLibrary);
						show(addingJQuery);
					} else {
						hide(bootstrapVersion);
						hide(addingStyleSheet);
						hide(addingLibrary);
						hide(addingJQuery);
					}
				});
				var form = addingBootstrap.closest('form');
				if (form !== null) {
					var submitButton = form.querySelector("input[type='submit']");
					submitButton.addEventListener('click', function(e) {
						if (baseServerUrlValidated == '' || baseServerUrlValidated != baseServerUrl.value) {
							e.stopPropagation();
							e.preventDefault();
							validateBaseServerUrl(function() {
								if (validateAll()) {
									submitButton.dispatchEvent(new MouseEvent('click'));
								}
							});
						} else if (! validateAll()) {
							e.stopPropagation();
							e.preventDefault();
						}
					});
				}
				setTimeout(function() {
					addingBootstrap.dispatchEvent(new Event('change'));
				}, 0);
			} else if (input.name == 'bootstrap_version') {
				bootstrapVersion = input;
				bootstrapVersion.addEventListener('blur', function(e) {
					if (! validateBootstrapVersion()) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'adding_bootstrap_stylesheet') {
				addingStyleSheet = input;
			} else if (input.name == 'adding_bootstrap_library') {
				addingLibrary = input;
			} else if (input.name == 'adding_jquery_library') {
				addingJQuery = input;
			} else if (input.name == 'font_size') {
				fontSize = input;
				fontSize.addEventListener('blur', function(e) {
					if (! validateFontSize()) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'data1_observer') {
				dataObservers[0] = input;
				dataObservers[0].addEventListener('blur', function(e) {
					if (! validateDataObserver(0)) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'data2_observer') {
				dataObservers[1] = input;
				dataObservers[1].addEventListener('blur', function(e) {
					if (! validateDataObserver(1)) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'data3_observer') {
				dataObservers[2] = input;
				dataObservers[2].addEventListener('blur', function(e) {
					if (! validateDataObserver(2)) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'data4_observer') {
				dataObservers[3] = input;
				dataObservers[3].addEventListener('blur', function(e) {
					if (! validateDataObserver(3)) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'data5_observer') {
				dataObservers[4] = input;
				dataObservers[4].addEventListener('blur', function(e) {
					if (! validateDataObserver(4)) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'button1_observer') {
				buttonObservers[0] = input;
				buttonObservers[0].addEventListener('blur', function(e) {
					if (! validateButtonObserver(0)) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'button2_observer') {
				buttonObservers[1] = input;
				buttonObservers[1].addEventListener('blur', function(e) {
					if (! validateButtonObserver(1)) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'button3_observer') {
				buttonObservers[2] = input;
				buttonObservers[2].addEventListener('blur', function(e) {
					if (! validateButtonObserver(2)) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'button4_observer') {
				buttonObservers[3] = input;
				buttonObservers[3].addEventListener('blur', function(e) {
					if (! validateButtonObserver(3)) {
						e.preventDefault();
					}
				});
			} else if (input.name == 'button5_observer') {
				buttonObservers[4] = input;
				buttonObservers[4].addEventListener('blur', function(e) {
					if (! validateButtonObserver(4)) {
						e.preventDefault();
					}
				});
			}
		}

		function observe(mutations) {
			mutations.forEach(mutation => {
				mutation.addedNodes.forEach( node => {
					if (node.nodeName == 'INPUT') {
						register(node);
					} else if (node.nodeType == 1) {
						var inputs = node.querySelectorAll("input:not([type='hidden']), select");
						inputs.forEach( input => {
							register(input);
						});
					}
				});
			});
		}

		var observeDOM = (function(){
			var MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
			return function( obj, callback ){
				if( !obj || obj.nodeType !== 1 ) return;
				if ( MutationObserver ){
					var mutationObserver = new MutationObserver(callback)
					mutationObserver.observe( obj, { childList:true, subtree:true })
					return mutationObserver
				}
				else if( window.addEventListener ){
				  obj.addEventListener('DOMNodeInserted', callback, false)
				  obj.addEventListener('DOMNodeRemoved', callback, false)
				}
			}
		})();

		Simulator.init = function() {
			observeDOM( document.body, function(mutations){ 
				observe(mutations);
			});
		};

		Simulator.init();

		return Simulator;
});

