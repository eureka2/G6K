_T = {
	'simulator_base_url_required': "L'url de base du serveur est requis",
	'simulator_base_url_invalid': "L'url de base du serveur est invalide",
	'simulator_base_url_access': "Accès au serveur '%s' en cours ...",
	'simulator_base_url_not_responding': "Le serveur '%s' ne répond pas ou n'est pas un serveur API G6K.",
	'simulator_font_size_invalid': "La taille de police '%s' n'est pas valide",
	'simulator_bootstrap_version_required': "La version de bootstrap est requise",
	'simulator_bootstrap_version_invalid': "La version bootstrap n'est pas au format requis",
	'simulator_bootstrap_version_empty': "La version bootstrap ne doit pas être renseignée",
	'simulator_observer_not_known': "Le simulateur '%s' n'est pas connu par le serveur d'API",
	'simulator_data_observer_invalid': "La donnée '%s' à observer n'est pas au format requis",
	'simulator_button_observer_invalid': "Le bouton '%s' à observer n'est pas au format requis",
	'simulator_base_server_url_not_responding': "Le serveur '%s' ne répond pas ou n'est pas un serveur API G6K.",
	'simulator_data_invalid': "La donnée '%s' à observer n'est pas au format requis",
	'simulator_button_invalid': "Le bouton '%s' à observer n'est pas au format requis",
	'simulator_unknown': "Le simulateur '%s' n'est pas connu par le serveur d'API"
};
