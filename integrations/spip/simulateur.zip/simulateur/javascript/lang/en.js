_T = {
	'simulator_base_url_required': "The base url of the server is required",
	'simulator_base_url_invalid': "The base url of the server is invalid",
	'simulator_base_url_access': "Access to server '%s' in progress ...",
	'simulator_base_url_not_responding': "Server '%s' is not responding or is not a G6K API server.",
	'simulator_font_size_invalid': "The font size '%s' is not valid",
	'simulator_bootstrap_version_required': "The bootstrap version is required",
	'simulator_bootstrap_version_invalid': "The bootstrap version is not in the required format",
	'simulator_bootstrap_version_empty': "The bootstrap version must not be entered",
	'simulator_observer_not_known': "The simulator '%s' is not known by the API server",
	'simulator_data_observer_invalid': "The data '%s' to observe is not in the required format",
	'simulator_button_observer_invalid': "The button '%s' to observe is not in the required format",
	'simulator_base_server_url_not_responding': "The server '%s' is not responding or is not a G6K API server.",
	'simulator_data_invalid': "The data '%s' to observe is not in the required format",
	'simulator_button_invalid': "The button '%s' to observe is not in the required format",
	'simulator_unknown': "The simulator '%s' is not known by the API server"
};
