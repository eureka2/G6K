<?php
if (txpinterface === 'admin') {
	require_once(__DIR__ . '/src/SimulatorSettings.php');
	new SimulatorSettings();
} else {
	require_once(__DIR__ . '/src/Simulator.php');
	new Simulator();
}
