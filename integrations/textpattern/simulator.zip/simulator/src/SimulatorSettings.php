<?php

/**
 * Admin-side plugin
 */
class SimulatorSettings {
	/**
	 * The plugin's event as registered in Textpattern.
	 *
	 * @var string
	 */
	protected $event = __CLASS__;

	/**
	 * Constructor to set up callbacks and environment.
	 */
	public function __construct() {
		add_privs($this->event, '1'); // Publishers only
		register_tab('extensions', $this->event, gTxt('simulator_menu_label'));
		register_callback([$this, 'settingsPanel'], $this->event);
		register_callback([$this, 'admin'], 'admin_side');
	}

	/**
	 * Plugin dispatcher: handle steps.
	 */
	public function settingsPanel($event, $step) {
		// Only the following steps are valid. The 'false' just states that we are
		// not using admin-side injection defences (CSRF). Steps that commit things
		// to the database or make changes (as opposed to just displaying content)
		// should use 'true'. You must then add a tInput() or form_token() to the
		// payload or your request will be rejected.
		$available_steps = [
			'settings' => false,
			'save' => false, // Should use 'true' in real code
		];

		// bouncer() checks CSRF tokens and if the step is permitted.
		// If not, the default 'list' step is used.
		if (!$step or !bouncer($step, $available_steps)) {
			$step = 'settings';
		}

		$this->$step();
	}

	public function admin($event, $step, $pre = 0) {
		if (gps('event') == $this->event) {
			if ($step == 'head_end') {
				echo '<link rel="stylesheet" href="plugins/simulator/css/settings.css">';
			} elseif ($step == 'main_content_end') {
				echo script_js('plugins/simulator/js/lang/' . get_pref('language', 'en') . '.js', TEXTPATTERN_SCRIPT_URL);
				echo script_js('plugins/simulator/js/settings.js', TEXTPATTERN_SCRIPT_URL);
				echo script_js('$( function() { $( "#simulator-tabs" ).tabs(); } );');
			}
		}
	}

	/**
	 * Display the user interface with some hyperlink actions.
	 */
	public function settings() {
		pagetop(gTxt('simulator_panel'));
		echo '<h1>' . gTxt('simulator_menu_description') . '</h1>';
		echo '<form class="prefs-form" id="prefs_form" method="post" action="?event=SimulatorSettings&step=save">';
		echo '<div id="simulator-tabs">';
		echo '  <ul>';
		echo '    <li><a href="#server-tab">' . gTxt('simulator_g6k_api_server_tab') . '</a></li>';
		echo '    <li><a href="#markup-tab">' . gTxt('simulator_markup_tab') . '</a></li>';
		echo '    <li><a href="#colors-tab">' . gTxt('simulator_colors_tab') . '</a></li>';
		echo '    <li><a href="#font-tab">' . gTxt('simulator_font_tab') . '</a></li>';
		echo '    <li><a href="#data-observers-tab">' . gTxt('simulator_data_observers_tab') . '</a></li>';
		echo '    <li><a href="#buttons-observers-tab">' . gTxt('simulator_buttons_observers_tab') . '</a></li>';
		echo '  </ul>';
		echo '<div id="server-tab">';
		echo $this->input(gTxt('simulator_base_url_title'), 'url', 'simulator_baseurl', get_pref('simulator_baseurl', ''), gTxt('simulator_base_url_description'));
		echo '</div>';
		echo '<div id="markup-tab">';
		echo $this->input(gTxt('simulator_html_markup_title'), 'select', 'simulator_markup', get_pref('simulator_markup', 'fragment'), '', [
			'fragment' => gTxt('simulator_html_markup_fragment'),
			'page' => gTxt('simulator_html_markup_page')
		]);
		echo $this->input(gTxt('simulator_bootstrap_classes_title'), 'checkbox', 'simulator_adding_bootstrap_classes', get_pref('simulator_adding_bootstrap_classes', 0), gTxt('simulator_bootstrap_classes_description'));
		echo $this->input(gTxt('simulator_bootstrap_version_title'), 'text', 'simulator_bootstrap_version', get_pref('simulator_bootstrap_version', ''), gTxt('simulator_bootstrap_version_description'));
		echo $this->input(gTxt('simulator_bootstrap_stylesheet_title'), 'checkbox', 'simulator_adding_bootstrap_stylesheet', get_pref('simulator_adding_bootstrap_stylesheet', 0), gTxt('simulator_bootstrap_stylesheet_description'));
		echo $this->input(gTxt('simulator_bootstrap_library_title'), 'checkbox', 'simulator_adding_bootstrap_library', get_pref('simulator_adding_bootstrap_library', 0), gTxt('simulator_bootstrap_library_description'));
		echo $this->input(gTxt('simulator_bootstrap_jquery_title'), 'checkbox', 'simulator_adding_jquery_library', get_pref('simulator_adding_jquery_library', 0), gTxt('simulator_bootstrap_jquery_description'));
		echo '</div>';
		echo '<div id="colors-tab">';
		echo $this->input(gTxt('simulator_primary_color_title'), 'color', 'simulator_primary_color', get_pref('simulator_primary_color', '#2b4e6b'));
		echo $this->input(gTxt('simulator_secondary_color_title'), 'color', 'simulator_secondary_color', get_pref('simulator_secondary_color', '#c0c0c0'));
		echo $this->input(gTxt('simulator_breadcrumb_color_title'), 'color', 'simulator_breadcrumb_color', get_pref('simulator_breadcrumb_color', '#2b4e6b'));
		echo $this->input(gTxt('simulator_tab_color_title'), 'color', 'simulator_tab_color', get_pref('simulator_tab_color', '#2b4e6b'));
		echo $this->input(gTxt('simulator_global_error_color_title'), 'color', 'simulator_global_error_color', get_pref('simulator_global_error_color', '#ff0000'));
		echo $this->input(gTxt('simulator_global_warning_color_title'), 'color', 'simulator_global_warning_color', get_pref('simulator_global_warning_color', '#800000'));
		echo $this->input(gTxt('simulator_field_error_color_title'), 'color', 'simulator_field_error_color', get_pref('simulator_field_error_color', '#ff0000'));
		echo $this->input(gTxt('simulator_field_warning_color_title'), 'color', 'simulator_field_warning_color', get_pref('simulator_field_warning_color', '#800000'));
		echo '</div>';
		echo '<div id="font-tab">';
		echo $this->input(gTxt('simulator_font_family_title'), 'text', 'simulator_font_family', get_pref('simulator_font_family', 'Arial, Verdana'), gTxt('simulator_font_family_description'));
		echo $this->input(gTxt('simulator_font_size_title'), 'text', 'simulator_font_size', get_pref('simulator_font_size', '1em'), gTxt('simulator_font_size_description'));
		echo '</div>';
		echo '<div id="data-observers-tab">';
		for ($i = 1; $i <= 5; $i++) {
			echo $this->input(sprintf(gTxt('simulator_data_observer_title'), $i), 'text', 'simulator_data' . $i . '_observer', get_pref('simulator_data' . $i . '_observer', ''), gTxt('simulator_data_observer_description'));
		}
		echo '</div>';
		echo '<div id="buttons-observers-tab">';
		for ($i = 1; $i <= 5; $i++) {
			echo $this->input(sprintf(gTxt('simulator_button_observer_title'), $i), 'text', 'simulator_button' . $i . '_observer', get_pref('simulator_button' . $i . '_observer', ''), gTxt('simulator_button_observer_description'));
		}
		echo '</div>';
		echo '</div>';
		echo '<input type="submit" name="Save">';
		echo '</form>';
		
	}

	public function input($label, $type, $name, $value, $hint = '', $options = []) {
		$field = [];
		$field[] = '<div class="simulator-settings-field">';
		$field[] = '  <label class="simulator-' . $type . '-label" for="' . $name . '">' . $label . '</label>';
		if ($type == 'select') {
			$field[] = '  <select id="' . $name . '" name="' . $name . '">';
			foreach($options as $val => $option) {
				$selected = $val == $value ? ' selected' : '';
				$field[] = '    <option value="' . $val . '"' . $selected . '>' . $option . '</option>';
			}
			$field[] = '  </select>';
		} else {
			$field[] = '  <input type="' . $type . '" id="' . $name . '" name="' . $name . '" value="' . $value . '">';
			if ($type == 'color') {
				$field[] = '  <span class="simulator-color-value">' . $value . '</span>';
			}
		}
		if ($hint != '') {
			$field[] = '  <p class="simulator-field-hint">' . $hint . '</p>';
		}
		$field[] = '</div>';
		return implode("\n", $field);
	}

	/**
	 * Perform a save action.
	 */
	public function save() {
		$fields = [
			'simulator_baseurl', 'simulator_markup',
			'simulator_adding_bootstrap_classes',
			'simulator_bootstrap_version', 'simulator_adding_bootstrap_stylesheet',
			'simulator_adding_bootstrap_library', 'simulator_adding_jquery_library',
			'simulator_primary_color', 'simulator_secondary_color',
			'simulator_breadcrumb_color', 'simulator_tab_color',
			'simulator_global_error_color', 'simulator_global_warning_color',
			'simulator_field_error_color', 'simulator_field_warning_color',
			'simulator_font_family', 'simulator_font_size',
			'simulator_data1_observer', 'simulator_button1_observer',
			'simulator_data2_observer', 'simulator_button2_observer',
			'simulator_data3_observer', 'simulator_button3_observer',
			'simulator_data4_observer', 'simulator_button4_observer',
			'simulator_data5_observer', 'simulator_button5_observer',
		];
		foreach($fields as $field) {
			set_pref($field, ps($field), $this->event, PREF_PLUGIN);
		}
		echo gTxt('Settings saved successfully !');
		$this->settings();
	}

}
