<?php declare(strict_types=1);

/*
The MIT License (MIT)

Copyright (c) 2021 Jacques Archimède

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

use Symfony\Component\HttpClient\HttpClient;

class SimulatorAPI {

	public function url($simulator = null, $baseUrl = null) {
		$this->check($simulator);
		if (null === $baseUrl) {
			$baseUrl = Configuration::get('simulator-server-url');
		}
		$scheme = isset($_SERVER['HTTPS']) ? 'https' : 'http';
		return preg_replace("/^https?/", $scheme, $baseUrl) . "/" . $simulator . "/api";
	}

	public function attributes(string $simulator = null) {
		$this->check($simulator);
		$url = $this->url($simulator) . '/json';
		[$ok, $api] = $this->fetch($url);
		if ($ok) {
			$api = json_decode($api, true);
			return $api['data']['attributes'];
		} else {
			return [ 'title' => $api ];
		}
	}

	public function simulators($baseUrl = null) {
		$url = $this->url('simulators', $baseUrl);
		[$ok, $api] = $this->fetch($url);
		$simulators = [];
		if ($ok) {
			$api = json_decode($api, true);
			$data = $api['included']['data'];
			foreach($data as $simu) {
				$simulators[] = $simu['id'];
			}
			return $simulators;
		}
		return false;
	}

	public function markup(string $simulator = null) {
		$this->check($simulator);
		$url = $this->url($simulator) . '/html';

		$options = [
			'markup' => Configuration::get('simulator-html-markup') ?? 'fragment', // 'fragment' or 'page'
			'primaryColor' => Configuration::get('simulator-primary-color') ?? '#2b4e6b', // optional
			'secondaryColor' => Configuration::get('simulator-secondary-color') ?? '#c0c0c0', // optional
			'fontFamily' => Configuration::get('simulator-font-family') ?? 'Arial, Verdana', // optional
			'fontSize' => Configuration::get('simulator-font-size') ?? '1em', // optional
			'breadcrumbColor' => Configuration::get('simulator-breadcrumb-color') ?? '#2b4e6b', // optional
			'tabColor' => Configuration::get('simulator-tab-color') ?? '#2b4e6b', // optional
			'globalErrorColor' => Configuration::get('simulator-global-error-color') ?? '#ff0000', // optional
			'globalWarningColor' => Configuration::get('simulator-global-warning-color') ?? '#800000', // optional
			'fieldErrorColor' => Configuration::get('simulator-field-error-color') ?? '#ff0000', // optional
			'fieldWarningColor' => Configuration::get('simulator-field-warning-color') ?? '#800000', // optional
		];
		if (Configuration::get( 'simulator-adding-bootstrap' ) == "1") {
			$options['bootstrap'] = Configuration::get('simulator-bootstrap-version') ?? ''; // bootstrap version
			$options['addBootstrapStylesheet'] = Configuration::get('simulator-adding-bootstrap-stylesheet') == "1" ? 'true' : 'false';
			$options['addBootstrapScript'] = Configuration::get('simulator-adding-bootstrap-library') == "1" ? 'true' : 'false';
			$options['addJQueryScript'] = Configuration::get('simulator-adding-jquery-library') == "1" ? 'true' : 'false';
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer = Configuration::get('simulator-data-observer' . $i) ?? '';
			if ($observer != '') {
				[$simu, $field] = explode(":", $observer);
				if ($simu == $simulator) {
					$options[$field] = 'ResultObserver.field';
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer = Configuration::get('simulator-button-observer' . $i) ?? '';
			if ($observer != '') {
				[$simu, $field] = explode(":", $observer);
				if ($simu == $simulator) {
					$options[$field] = 'ResultObserver.button';
				}
			}
		}
		[$ok, $markup] = $this->fetch($url, $options);
		return $markup;
	}

	protected function fetch(string $url, array $options = []) {
		try {
			$client = HttpClient::create([
				'max_redirects' => 7,
			]);
			$request = $client->request('POST', $url, [
				'body' => $options,
				'verify_peer' => false,
				'verify_host' => false
			]);
			$statusCode = $request->getStatusCode();
			$response = $request->getContent();
			return [$statusCode == 200, $response];
		} catch (\Exception $e){
			var_dump($options);
			return [false, "Oops, something went wrong.  Please try again later.  #:" . $e->getMessage()];
		}
	}

	protected function check(&$simulator) {
		if ($simulator === null) {
			$simulator = Tools::getValue('simulator');
		}
	}

}