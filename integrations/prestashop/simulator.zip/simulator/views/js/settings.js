(function (document, window) {
	'use strict';
	
	function changeHandler(event) {
		var that = this;
		[ 'simulator-bootstrap-version', 'simulator-adding-bootstrap-stylesheet', 'simulator-adding-bootstrap-library', 'simulator-adding-jquery-library'].forEach(function(name) {
			var input = document.querySelector("input[name='" + name + "']");
			if ( that.value === '0' && that.checked) {
				input.closest('.form-group').classList.add('hidden');
				if (input.type = 'text') input.value = '';
			} else if ( that.value === '1' && that.checked) {
				input.closest('.form-group').classList.remove('hidden');
			}
		});
	}

	function manageAddingBootstrapClasses() {
		var radios = document.querySelectorAll('input[type=radio][name="simulator-adding-bootstrap"]');
		Array.prototype.forEach.call(radios, function(radio) {
			radio.addEventListener('change', changeHandler);
			radio.dispatchEvent(new Event('change'));

		});
	}

	window.addEventListener('DOMContentLoaded', function(event) {
		manageAddingBootstrapClasses();
	});

}(document, window));
