<?php

require_once dirname(dirname(__DIR__)). "/classes/SimulatorAPI.php";

class SimulatorDisplayModuleFrontController extends ModuleFrontController {

	public function initContent() {
		parent::initContent();
		$api = new SimulatorAPI();

		$this->context->smarty->assign(
			[
				'simulator_name' =>  Tools::getValue('simulator'),
				'simulator_title' => $api->attributes(Tools::getValue('simulator'))['title'],
				'simulator_markup' => $api->markup(Tools::getValue('simulator')),
			]
		);
		$this->setTemplate('module:simulator/views/templates/front/simulator.tpl');
	}

	public function getBreadcrumbLinks() {
		$breadcrumb = parent::getBreadcrumbLinks();
		$api = new SimulatorAPI();
		$breadcrumb['links'][] = [
			'title' => $this->module->l('Simulator'),
			'url' => $this->context->link->getModuleLink('simulator', 'display', [ 'id' => Tools::getValue('simulator') ]),
		];
		$breadcrumb['links'][] = [
			'title' => $api->attributes(Tools::getValue('simulator'))['title'],
		];
		return $breadcrumb;
	}
}