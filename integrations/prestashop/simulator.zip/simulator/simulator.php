<?php

/*
The MIT License (MIT)

Copyright (c) 2021 Jacques Archimède

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Module\WidgetInterface;

require_once __DIR__ . "/classes/SimulatorAPI.php";

class Simulator extends Module implements WidgetInterface {

	private $api;

	public function __construct() {
		$this->name = 'simulator';
		$this->tab = 'front_office_features';
		$this->version = '1.0.0';
		$this->author = 'Eureka and Co';
		$this->ps_versions_compliancy = [
			'min' => '1.6',
			'max' => _PS_VERSION_
		];
		$this->bootstrap = true;

		parent::__construct();

		$this->displayName = $this->l('Simulator');
		$this->description = $this->l('Prestashop / G6K Integration module.');

		$this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
		$this->templateFile = 'module:simulator/views/templates/hook/simulator.tpl';

		$this->api = new SimulatorAPI();
	}


	public function install() {
		if (Shop::isFeatureActive()) {
			Shop::setContext(Shop::CONTEXT_ALL);
		}

		return parent::install()
			&& $this->registerHook('rightColumn')
			&& $this->registerHook('actionFrontControllerSetMedia')
			&& $this->registerHook('moduleRoutes')
			&& Configuration::updateValue('simulator-server-url', '')
			&& Configuration::updateValue('simulator-primary-color', '#2B4E6B')
			&& Configuration::updateValue('simulator-secondary-color', '#C0C0C0')
			&& Configuration::updateValue('simulator-breadcrumb-color', '#2B4E6B')
			&& Configuration::updateValue('simulator-tab-color', '#2B4E6B')
			&& Configuration::updateValue('simulator-global-error-color', '#FF0000')
			&& Configuration::updateValue('simulator-global-warning-color', '#800000')
			&& Configuration::updateValue('simulator-field-error-color', '#FF0000')
			&& Configuration::updateValue('simulator-field-warning-color', '#800000')
			&& Configuration::updateValue('simulator-font-family', 'Arial, Verdana')
			&& Configuration::updateValue('simulator-font-size', '1em')
			&& Configuration::updateValue('simulator-html-markup', 'fragment')
			&& Configuration::updateValue('simulator-adding-bootstrap', '0')
			&& Configuration::updateValue('simulator-bootstrap-version', '')
			&& Configuration::updateValue('simulator-adding-bootstrap-stylesheet', '0')
			&& Configuration::updateValue('simulator-adding-bootstrap-library', '0')
			&& Configuration::updateValue('simulator-adding-jquery-library', '0')
			&& Configuration::updateValue('simulator-data-observer1', '')
			&& Configuration::updateValue('simulator-data-observer2', '')
			&& Configuration::updateValue('simulator-data-observer3', '')
			&& Configuration::updateValue('simulator-data-observer4', '')
			&& Configuration::updateValue('simulator-data-observer5', '')
			&& Configuration::updateValue('simulator-button-observer1', '')
			&& Configuration::updateValue('simulator-button-observer2', '')
			&& Configuration::updateValue('simulator-button-observer3', '')
			&& Configuration::updateValue('simulator-button-observer4', '')
			&& Configuration::updateValue('simulator-button-observer5', '')
			;
	}

	public function uninstall() {
		if (parent::uninstall()) {
			return true;
		}

		return false;
	}

	public function getContent() {
		$output = '';

		if (Tools::isSubmit('submit'.$this->name)) {
			$ok = $this->validateFields();
			if ($ok !== true) {
				$output = $ok;
			} else {
				Configuration::updateValue('simulator-server-url', strval(Tools::getValue('simulator-server-url')));
				Configuration::updateValue('simulator-primary-color', strval(Tools::getValue('simulator-primary-color')));
				Configuration::updateValue('simulator-secondary-color', strval(Tools::getValue('simulator-secondary-color')));
				Configuration::updateValue('simulator-breadcrumb-color', strval(Tools::getValue('simulator-breadcrumb-color')));
				Configuration::updateValue('simulator-tab-color', strval(Tools::getValue('simulator-tab-color')));
				Configuration::updateValue('simulator-global-error-color', strval(Tools::getValue('simulator-global-error-color')));
				Configuration::updateValue('simulator-global-warning-color', strval(Tools::getValue('simulator-global-warning-color')));
				Configuration::updateValue('simulator-field-error-color', strval(Tools::getValue('simulator-field-error-color')));
				Configuration::updateValue('simulator-field-warning-color', strval(Tools::getValue('simulator-field-warning-color')));
				Configuration::updateValue('simulator-font-family', strval(Tools::getValue('simulator-font-family')));
				Configuration::updateValue('simulator-font-size', strval(Tools::getValue('simulator-font-size')));
				Configuration::updateValue('simulator-html-markup', strval(Tools::getValue('simulator-html-markup')));
				Configuration::updateValue('simulator-adding-bootstrap', (bool)(Tools::getValue('simulator-adding-bootstrap')));
				Configuration::updateValue('simulator-bootstrap-version', strval(Tools::getValue('simulator-bootstrap-version')));
				Configuration::updateValue('simulator-adding-bootstrap-stylesheet', (bool)(Tools::getValue('simulator-adding-bootstrap-stylesheet')));
				Configuration::updateValue('simulator-adding-bootstrap-library', (bool)(Tools::getValue('simulator-adding-bootstrap-library')));
				Configuration::updateValue('simulator-adding-jquery-library', (bool)(Tools::getValue('simulator-adding-jquery-library')));
				Configuration::updateValue('simulator-data-observer1', strval(Tools::getValue('simulator-data-observer1')));
				Configuration::updateValue('simulator-data-observer2', strval(Tools::getValue('simulator-data-observer2')));
				Configuration::updateValue('simulator-data-observer3', strval(Tools::getValue('simulator-data-observer3')));
				Configuration::updateValue('simulator-data-observer4', strval(Tools::getValue('simulator-data-observer4')));
				Configuration::updateValue('simulator-data-observer5', strval(Tools::getValue('simulator-data-observer5')));
				Configuration::updateValue('simulator-button-observer1', strval(Tools::getValue('simulator-button-observer1')));
				Configuration::updateValue('simulator-button-observer2', strval(Tools::getValue('simulator-button-observer2')));
				Configuration::updateValue('simulator-button-observer3', strval(Tools::getValue('simulator-button-observer3')));
				Configuration::updateValue('simulator-button-observer4', strval(Tools::getValue('simulator-button-observer4')));
				Configuration::updateValue('simulator-button-observer5', strval(Tools::getValue('simulator-button-observer5')));
				$output = $this->displayConfirmation($this->l('Settings updated'));
			}
		}
		$this->context->controller->addJS(_MODULE_DIR_.$this->name.'/views/js/settings.js');
		return $output.$this->displayForm();
	}

	private function validateFields() {
		$errors = [];
		$baseUrl = strval(Tools::getValue('simulator-server-url'));
		$simulators = [];
		if (empty($baseUrl)) {
			$errors[] = $this->displayError($this->l("The base url of the API server is required"));
		} elseif (! preg_match("/^https?:\/\/[^ ]+$/", $baseUrl)) {
			$errors[] = $this->displayError($this->l("The base url of the API server is not a valid url"));
		} else {
			$simus = $this->api->simulators($baseUrl);
			if ($simus === false) {
				$errors[] = $this->displayError(sprintf($this->l("The server '%s' is not responding or is not a G6K API server."), $baseUrl));
			} else {
				$simulators = $simus;
			}
		}
		$bootstrap = (bool)(Tools::getValue('simulator-adding-bootstrap'));
		$version = strval(Tools::getValue('simulator-bootstrap-version'));
		if ($bootstrap) {
			if (empty($version)) {
				$errors[] = $this->displayError($this->l("The bootstrap version is required"));
			} elseif (!preg_match("/^\d+\.\d+\.\d+$/", $version)) {
				$errors[] = $this->displayError($this->l("The bootstrap version is not in the required format"));
			}
		} elseif (!empty($version)) {
			$errors[] = $this->displayError($this->l("The bootstrap version must be empty"));
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer =  strval(Tools::getValue('simulator-data-observer' . $i));
			if ($observer != '') {
				if (!preg_match("/^([\-\w]+):[\-\w]+$/", $observer, $m)) {
					$errors[] = $this->displayError(sprintf($this->l("The data '%s' to observe is not in the required format"), $observer ));
				} elseif (! in_array($m[1], $simulators)) {
					$errors[] = $this->displayError(sprintf($this->l("The simulator '%s' is not known by the API server"), $m[1] ));
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer =  strval(Tools::getValue('simulator-button-observer' . $i));
			if ($observer != '') {
				if (!preg_match("/^([\-\w]+):[\-\w]+$/", $observer, $m)) {
					$errors[] = $this->displayError(sprintf($this->l("The button '%s' to observe is not in the required format"), $observer ));
				} elseif (! in_array($m[1], $simulators)) {
					$errors[] = $this->displayError(sprintf($this->l("The simulator '%s' is not known by the API server"), $m[1] ));
				}
			}
		}
		return count($errors) > 0 ? implode("", $errors) : true;
	}

	public function displayForm() {
		// Get default language
		$defaultLang = (int)Configuration::get('PS_LANG_DEFAULT');

		// Init Fields form array
		$fieldsForm[0]['form'] = [
			'legend' => [
				'title' => $this->l('Settings'),
			],
			'tabs' => [
				'g6k_api_server_tab' => $this->l('G6K API Server'),
				'colors_tab' => $this->l('Colors'),
				'font_tab' => $this->l('Font'),
				'html_markup_tab' => $this->l('HTML Markup'),
				'data_observers_tab' => $this->l('Data observers'),
				'buttons_observers_tab' => $this->l('Buttons observers')
			],
			'input' => [
				[
					'type' => 'text',
					'label' => $this->l('Base url of the server'),
					'name' => 'simulator-server-url',
					'desc' => $this->l('Enter the absolute url pointing to the pulic directory of the API server'),
					'size' => 30,
					'required' => true,
					'tab' => 'g6k_api_server_tab'
				],
				[
					'type' => 'color',
					'label' => $this->l('Primary color'),
					'name' => 'simulator-primary-color',
					'required' => false,
					'tab' => 'colors_tab'
				],
				[
					'type' => 'color',
					'label' => $this->l('Secondary color'),
					'name' => 'simulator-secondary-color',
					'required' => false,
					'tab' => 'colors_tab'
				],
				[
					'type' => 'color',
					'label' => $this->l('Breadcrumb color'),
					'name' => 'simulator-breadcrumb-color',
					'required' => false,
					'tab' => 'colors_tab'
				],
				[
					'type' => 'color',
					'label' => $this->l('Tab color'),
					'name' => 'simulator-tab-color',
					'required' => false,
					'tab' => 'colors_tab'
				],
				[
					'type' => 'color',
					'label' => $this->l('Global error color'),
					'name' => 'simulator-global-error-color',
					'required' => false,
					'tab' => 'colors_tab'
				],
				[
					'type' => 'color',
					'label' => $this->l('Global warning color'),
					'name' => 'simulator-global-warning-color',
					'required' => false,
					'tab' => 'colors_tab'
				],
				[
					'type' => 'color',
					'label' => $this->l('Field error color'),
					'name' => 'simulator-field-error-color',
					'required' => false,
					'tab' => 'colors_tab'
				],
				[
					'type' => 'color',
					'label' => $this->l('Field warning color'),
					'name' => 'simulator-field-warning-color',
					'required' => false,
					'tab' => 'colors_tab'
				],
				[
					'type' => 'text',
					'label' => $this->l('Font family'),
					'name' => 'simulator-font-family',
					'desc' => $this->l('Enter the font names separated by commas'),
					'required' => false,
					'tab' => 'font_tab'
				],
				[
					'type' => 'text',
					'label' => $this->l('Font size'),
					'name' => 'simulator-font-size',
					'desc' => $this->l('Enter the font size as a number followed by a unit (ex: 1em, 14px, etc.)'),
					'required' => false,
					'tab' => 'font_tab'
				],
				[
					'type' => 'select',
					'label' => $this->l('HTML Markup'),
					'name' => 'simulator-html-markup',
					'required' => false,
					'options' => [
						'query' => [
							[
								'id' => 'fragment',
								'name' => $this->l('html fragment only'),
							],
							[
								'id' => 'page',
								'name' => $this->l('full html page'),
							]
						],
						'id' => 'id',
						'name' => 'name',
					],
					'tab' => 'html_markup_tab'
				],
				[
					'type' => 'switch',
					'label' => $this->l('Adding Bootstrap classes'),
					'name' => 'simulator-adding-bootstrap',
					'class' => 'fixed-width-xs',
					'desc' => $this->l('Enable if you want bootstrap classes to be added to the relevant markup allowing bootstrap styles to apply (default: no).'),
					'values' => [
						[
							'id' => 'active_on',
							'value' => 1,
							'label' => $this->trans('Yes', [], 'Admin.Global'),
						],
						[
							'id' => 'active_off',
							'value' => 0,
							'label' => $this->trans('No', [], 'Admin.Global'),
						]
					],
					'tab' => 'html_markup_tab'
				],
				[
					'type' => 'text',
					'label' => $this->l('Bootstrap version'),
					'name' => 'simulator-bootstrap-version',
					'desc' => $this->l('Enter the three groups of digits of the version number separated by periods'),
					'required' => false,
					'tab' => 'html_markup_tab'
				],
				[
					'type' => 'switch',
					'label' => $this->l('Adding Bootstrap stylesheet'),
					'name' => 'simulator-adding-bootstrap-stylesheet',
					'class' => 'fixed-width-xs',
					'desc' => $this->l('Enable if you prefer the Bootstrap stylesheet to be loaded by the API from bootstrapcdn.'),
					'values' => [
						[
							'id' => 'active_on',
							'value' => 1,
							'label' => $this->trans('Yes', [], 'Admin.Global'),
						],
						[
							'id' => 'active_off',
							'value' => 0,
							'label' => $this->trans('No', [], 'Admin.Global'),
						]
					],
					'tab' => 'html_markup_tab'
				],
				[
					'type' => 'switch',
					'label' => $this->l('Adding Bootstrap library'),
					'name' => 'simulator-adding-bootstrap-library',
					'class' => 'fixed-width-xs',
					'desc' => $this->l('Enable if you prefer the Bootstrap library to be loaded by the API from bootstrapcdn.'),
					'values' => [
						[
							'id' => 'active_on',
							'value' => 1,
							'label' => $this->trans('Yes', [], 'Admin.Global'),
						],
						[
							'id' => 'active_off',
							'value' => 0,
							'label' => $this->trans('No', [], 'Admin.Global'),
						]
					],
					'tab' => 'html_markup_tab'
				],
				[
					'type' => 'switch',
					'label' => $this->l('Adding jQuery library'),
					'name' => 'simulator-adding-jquery-library',
					'class' => 'fixed-width-xs',
					'desc' => $this->l('Enable if you prefer the jQuery library to be loaded by the API from code.jquery.com.'),
					'values' => [
						[
							'id' => 'active_on',
							'value' => 1,
							'label' => $this->trans('Yes', [], 'Admin.Global'),
						],
						[
							'id' => 'active_off',
							'value' => 0,
							'label' => $this->trans('No', [], 'Admin.Global'),
						]
					],
					'tab' => 'html_markup_tab'
				],
			],
			'submit' => [
				'title' => $this->l('Save'),
				'class' => 'btn btn-default pull-right'
			]
		];
		for ($i = 1; $i <= 5; $i++) {
			$fieldsForm[0]['form']['input'][] = [
				'type' => 'text',
				'label' => sprintf( $this->l('Data %d'), $i),
				'name' => 'simulator-data-observer' . $i,
				'desc' => $this->l('Enter the data to observe with the following format: <simulator name>:<data name>'),
				'required' => false,
				'tab' => 'data_observers_tab'
			];
		}
		for ($i = 1; $i <= 5; $i++) {
			$fieldsForm[0]['form']['input'][] = [
				'type' => 'text',
				'label' => sprintf( $this->l('Button %d'), $i),
				'name' => 'simulator-button-observer' . $i,
				'desc' => $this->l('Enter the button to observe with the following format: <simulator name>:<data name>'),
				'required' => false,
				'tab' => 'buttons_observers_tab'
			];
		}
		$helper = new HelperForm();

		// Module, token and currentIndex
		$helper->module = $this;
		$helper->name_controller = $this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;

		// Language
		$helper->default_form_language = $defaultLang;
		$helper->allow_employee_form_lang = $defaultLang;

		// Title and toolbar
		$helper->title = $this->displayName;
		$helper->show_toolbar = true;        // false -> remove toolbar
		$helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
		$helper->submit_action = 'submit'.$this->name;
		$helper->toolbar_btn = [
			'save' => [
				'desc' => $this->l('Save'),
				'href' => AdminController::$currentIndex.'&configure='.$this->name.'&save'.$this->name.
				'&token='.Tools::getAdminTokenLite('AdminModules'),
			],
			'back' => [
				'href' => AdminController::$currentIndex.'&token='.Tools::getAdminTokenLite('AdminModules'),
				'desc' => $this->l('Back to list')
			]
		];

		// Load current value
		$helper->fields_value['simulator-server-url'] = Tools::getValue('simulator-server-url', Configuration::get('simulator-server-url'));
		$helper->fields_value['simulator-primary-color'] = Tools::getValue('simulator-primary-color', Configuration::get('simulator-primary-color'));
		$helper->fields_value['simulator-secondary-color'] = Tools::getValue('simulator-secondary-color', Configuration::get('simulator-secondary-color'));
		$helper->fields_value['simulator-breadcrumb-color'] = Tools::getValue('simulator-breadcrumb-color', Configuration::get('simulator-breadcrumb-color'));
		$helper->fields_value['simulator-tab-color'] = Tools::getValue('simulator-tab-color', Configuration::get('simulator-tab-color'));
		$helper->fields_value['simulator-global-error-color'] = Tools::getValue('simulator-global-error-color', Configuration::get('simulator-global-error-color'));
		$helper->fields_value['simulator-global-warning-color'] = Tools::getValue('simulator-global-warning-color', Configuration::get('simulator-global-warning-color'));
		$helper->fields_value['simulator-field-error-color'] = Tools::getValue('simulator-field-error-color', Configuration::get('simulator-field-error-color'));
		$helper->fields_value['simulator-field-warning-color'] = Tools::getValue('simulator-field-warning-color', Configuration::get('simulator-field-warning-color'));
		$helper->fields_value['simulator-font-family'] = Tools::getValue('simulator-font-family', Configuration::get('simulator-font-family'));
		$helper->fields_value['simulator-font-size'] = Tools::getValue('simulator-font-size', Configuration::get('simulator-font-size'));
		$helper->fields_value['simulator-html-markup'] = Tools::getValue('simulator-html-markup', Configuration::get('simulator-html-markup'));
		$helper->fields_value['simulator-adding-bootstrap'] = Tools::getValue('simulator-adding-bootstrap', Configuration::get('simulator-adding-bootstrap'));
		$helper->fields_value['simulator-bootstrap-version'] = Tools::getValue('simulator-bootstrap-version', Configuration::get('simulator-bootstrap-version'));
		$helper->fields_value['simulator-adding-bootstrap-stylesheet'] = Tools::getValue('simulator-adding-bootstrap-stylesheet', Configuration::get('simulator-adding-bootstrap-stylesheet'));
		$helper->fields_value['simulator-adding-bootstrap-library'] = Tools::getValue('simulator-adding-bootstrap-library', Configuration::get('simulator-adding-bootstrap-library'));
		$helper->fields_value['simulator-adding-jquery-library'] = Tools::getValue('simulator-adding-jquery-library', Configuration::get('simulator-adding-jquery-library'));
		$helper->fields_value['simulator-data-observer1'] = Tools::getValue('simulator-data-observer1', Configuration::get('simulator-data-observer1'));
		$helper->fields_value['simulator-data-observer2'] = Tools::getValue('simulator-data-observer2', Configuration::get('simulator-data-observer2'));
		$helper->fields_value['simulator-data-observer3'] = Tools::getValue('simulator-data-observer3', Configuration::get('simulator-data-observer3'));
		$helper->fields_value['simulator-data-observer4'] = Tools::getValue('simulator-data-observer4', Configuration::get('simulator-data-observer4'));
		$helper->fields_value['simulator-data-observer5'] = Tools::getValue('simulator-data-observer5', Configuration::get('simulator-data-observer5'));
		$helper->fields_value['simulator-button-observer1'] = Tools::getValue('simulator-button-observer1', Configuration::get('simulator-button-observer1'));
		$helper->fields_value['simulator-button-observer2'] = Tools::getValue('simulator-button-observer2', Configuration::get('simulator-button-observer2'));
		$helper->fields_value['simulator-button-observer3'] = Tools::getValue('simulator-button-observer3', Configuration::get('simulator-button-observer3'));
		$helper->fields_value['simulator-button-observer4'] = Tools::getValue('simulator-button-observer4', Configuration::get('simulator-button-observer4'));
		$helper->fields_value['simulator-button-observer5'] = Tools::getValue('simulator-button-observer5', Configuration::get('simulator-button-observer5'));

		return $helper->generateForm($fieldsForm);
	}

	// public function hookRightColumn($params) {
		// $this->context->smarty->assign([
			// 'simulator_name' => Configuration::get('simulator'),
			// 'simuator_link' => $this->context->link->getModuleLink('simulator', 'display'),
			// 'simulator_message' => 'simulator message'
		// ]);

		// return $this->display(__FILE__, 'simulator.tpl');
	// }

	// public function hookLeftColumn($params) {
		// return $this->hookRightColumn($params);
	// }

	public function renderWidget($hookName = null, array $configuration = []) {
		$simulator = isset($configuration['simulator']) ? $configuration['simulator'] : '';
		if (!$this->isCached($this->templateFile, $this->getCacheId('simulator-' . $simulator))) {
			$this->smarty->assign($this->getWidgetVariables($hookName, $configuration));
		}

		return $this->fetch($this->templateFile, $this->getCacheId('simulator-' . $simulator));
	}

	public function getWidgetVariables($hookName = null, array $configuration = []) {
		$simulator = isset($configuration['simulator']) ? $configuration['simulator'] : '';
		return [
			'simulator_name' =>  $simulator,
			'simulator_title' => $this->api->attributes($simulator)['title'],
			'simulator_markup' => $this->api->markup($simulator),
		];
	}

	public function hookActionFrontControllerSetMedia() {
		$this->context->controller->addCSS(_MODULE_DIR_.$this->name.'/views/css/style.css','all'); 
		$this->context->controller->addJS(_MODULE_DIR_.$this->name.'/views/js/script.js');
	}

	public function hookModuleRoutes($params) {
		return [
			'module-simulator-display' => [
				'controller' => 'display',
				'rule' => $this->l('simulator') . '{/:id}',
				'keywords' => [
					'id' => ['regexp' => '[-\w]+', 'param' => 'simulator']
				],
				'params' => [
					'fc' => 'module',
					'module' => 'simulator'
				]
			]
		];
	}

}
