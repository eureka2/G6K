<?php

if( !defined('CMS_VERSION') ) exit;
$this->RemoveSmartyPlugin('simulator');
$this->RemovePermission(Simulators::MANAGE_PERM);
