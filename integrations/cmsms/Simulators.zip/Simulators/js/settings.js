(function (document, window) {
	'use strict';

	var baseServerUrl = null;
	var baseServerUrlValidated = '';
	var addingBootstrap = null;
	var bootstrapVersion = null;
	var addingStyleSheet = null;
	var addingLibrary = null;
	var addingJQuery = null;
	var fontSize = null;
	var dataObservers = [];
	var buttonObservers = [];
	var simulators = null;

	function _t(key) {
		return (i18n && i18n[key]) ? i18n[key] : key;
	}

	function init() {
		var serverTab = document.getElementById("g6kapiserver_c");
		baseServerUrl =  serverTab.querySelector("input[id='simulator_base_url']");;
		addMessageField(baseServerUrl);
		baseServerUrl.addEventListener('blur', function(e) {
			validateBaseServerUrl();
		});
		if (baseServerUrl.value !== '') {
			validateBaseServerUrl();
		}
		var markupTab = document.getElementById("markup_c");
		addingBootstrap = markupTab.querySelector("input[id='simulator_adding_bootstrap_classes']");
		addingBootstrap.addEventListener('change', function(e) {
			if (this.checked) {
				show(bootstrapVersion);
				show(addingStyleSheet);
				show(addingLibrary);
				show(addingJQuery);
			} else {
				hide(bootstrapVersion);
				hide(addingStyleSheet);
				hide(addingLibrary);
				hide(addingJQuery);
			}
		});
		var form = addingBootstrap.closest('form');
		if (form !== null) {
			var submitButton = form.querySelector("button[type='submit']");
			submitButton.addEventListener('click', function(e) {
				if (baseServerUrlValidated == '' || baseServerUrlValidated != baseServerUrl.value) {
					e.stopPropagation();
					e.preventDefault();
					validateBaseServerUrl(function() {
						if (validateAll()) {
							submitButton.dispatchEvent(new MouseEvent('click'));
						}
					});
				} else if (! validateAll()) {
					e.stopPropagation();
					e.preventDefault();
				}
			});
		}
		setTimeout(function() {
			addingBootstrap.dispatchEvent(new Event('change'));
		}, 0);
		bootstrapVersion = markupTab.querySelector("input[id='simulator_bootstrap_version']");
		addMessageField(bootstrapVersion);
		bootstrapVersion.addEventListener('blur', function(e) {
			if (! validateBootstrapVersion()) {
				e.preventDefault();
			}
		});
		addingStyleSheet = markupTab.querySelector("input[id='simulator_adding_bootstrap_stylesheet']");
		addingLibrary = markupTab.querySelector("input[id='simulator_adding_bootstrap_library']");
		addingJQuery = markupTab.querySelector("input[id='simulator_adding_jquery_library']");
		fixColors();
		var fontTab = document.getElementById("font_c");
		fontSize = fontTab.querySelector("input[id='simulator_font_size']");
		addMessageField(fontSize);
		fontSize.addEventListener('blur', function(e) {
			if (! validateFontSize()) {
				e.preventDefault();
			}
		});
		var dataObserversTab = document.getElementById("dataobservers_c");
		var buttonsObserversTab = document.getElementById("buttonsobservers_c");
		for (var i = 1; i <= 5; i++) {
			var dataObserver = dataObserversTab.querySelector("input[id='simulator_data" + i + "_observer']");
			dataObservers.push(dataObserver);
			addMessageField(dataObserver);
			dataObserver.addEventListener('blur', function(e) {
				if (! validateDataObserver(this)) {
					e.preventDefault();
				}
			});
			var buttonObserver = buttonsObserversTab.querySelector("input[id='simulator_button" + i + "_observer']");
			buttonObservers.push(buttonObserver);
			addMessageField(buttonObserver);
			buttonObserver.addEventListener('blur', function(e) {
				if (! validateButtonObserver(this)) {
					e.preventDefault();
				}
			});
		}
	}

	async function validateBaseServerUrl(callback) {
		if (baseServerUrl.value === '') {
			addError(baseServerUrl, _t("Simulator.BASE_URL_REQUIRED"));
		} else if (!/^https?:\/\/.+$/.test(baseServerUrl.value)) {
			addError(baseServerUrl, _t("Simulator.BASE_URL_INVALID"));
		} else {
			try {
				if (baseServerUrlValidated != baseServerUrl.value || simulators === null) {
					addNotice(baseServerUrl, _t("Simulator.BASE_URL_ACCESS").replace('%s', baseServerUrl.value), 50);
					simulators = await fetchSimulators();
					if (simulators === null) {
						baseServerUrl.closest('.simulator-settings-field').classList.add('has-error');
						return;
					}
				}
				baseServerUrlValidated = baseServerUrl.value;
				removeError(baseServerUrl);
				callback && callback();
			} catch(error) {
				addError(baseServerUrl, _t("Simulator.BASE_URL_NOT_RESPONDING").replace('%s', baseServerUrl.value));
			}
		}
	}

	function validateFontSize() {
		if (fontSize.value !== '') {
			var allowedSizes = [ 'xx-small', 'x-small', 'small', 'medium', 'large', 'x-large', 'xx-large', 'larger', 'smaller', 'inherit', 'initial', 'unset' ];
			if (allowedSizes.indexOf(fontSize.value) < 0) {
				if (!/^\d+(\.\d+)?(px|pt|pc|ex|cm|mm|in|em|rem|%)$/.test(fontSize.value)) {
					addError(fontSize, _t("Simulator.FONTSIZE_INVALID").replace('%s', fontSize.value));
					return false;
				}
			}
		}
		removeError(fontSize);
		return true;
	}

	function validateBootstrapVersion() {
		if (addingBootstrap.checked) {
			if (bootstrapVersion.value == '') { 
				addError(bootstrapVersion, _t("Simulator.BOOTSTRAP_VERSION_REQUIRED"));
				return false;
			} else if (!/^\d+\.\d+\.\d+$/.test(bootstrapVersion.value)) {
				addError(bootstrapVersion, _t("Simulator.BOOTSTRAP_VERSION_INVALID"));
				return false;
			}
		} else if (bootstrapVersion.value !== '') {
			addError(bootstrapVersion, _t("Simulator.BOOTSTRAP_VERSION_NOT_EMPTY"));
			return false;
		}
		removeError(bootstrapVersion);
		return true;
	}

	function validateDataObserver(observer) {
		if (observer.value != '') {
			var m = observer.value.match(/^([\-\w]+):[\-\w]+$/);
			if (m) {
				if (simulators !== null && simulators.indexOf(m[1]) < 0) {
					addError(observer, _t("Simulator.SIMULATOR_UNKNOWN").replace('%s', m[1]));
					return false;
				}
			} else {
				addError(observer, _t("Simulator.DATA_OBSERVER_INVALID").replace('%s', observer.value));
				return false;
			}
		}
		removeError(observer);
		return true;
	}

	function validateDataObservers() {
		var ok = true;
		for (var i = 0; i < 5; i++) {
			if (dataObservers[i]) {
				if (!validateDataObserver(dataObservers[i])) {
					ok = false;
				}
			}
		}
		return ok;
	}

	function validateButtonObserver(observer) {
		if (observer.value != '') {
			var m = observer.value.match(/^([\-\w]+):[\-\w]+$/);
			if (m) {
				if (simulators !== null && simulators.indexOf(m[1]) < 0) {
					addError(observer, _t("Simulator.SIMULATOR_UNKNOWN").replace('%s', m[1]));
					return false;
				}
			} else {
				addError(observer, _t("Simulator.BUTTON_OBSERVER_INVALID").replace('%s', observer.value));
				return false;
			}
		}
		removeError(observer);
		return true;
	}

	function validateButtonObservers() {
		var ok = true;
		for (var i = 0; i < 5; i++) {
			if (buttonObservers[i]) {
				if (!validateButtonObserver(buttonObservers[i])) {
					ok = false;
				}
			}
		}
		return ok;
	}

	function validateAll() {
		return validateBootstrapVersion()
			&& validateFontSize()
			&& validateDataObservers()
			&& validateButtonObservers();
	}

	function hide(input) {
		if (input !== null) {
			var container = input.closest('.simulator-settings-field');
			if (container !== null) {
				container.classList.add('simulator-settings-field-hidden');
			}
		}
	}

	function show(input) {
		if (input !== null) {
			var container = input.closest('.simulator-settings-field');
			if (container !== null) {
				container.classList.remove('simulator-settings-field-hidden');
			}
		}
	}

	function addMessageField(input) {
		var messageField = document.createElement('div');
		messageField.classList.add('simulator-alert', 'simulator-settings-field-hidden');
		var container = input.closest(".simulator-settings-field");
		container.appendChild(messageField);
	}

	function addError(input, error, duration) {
		var messageField = input.closest(".simulator-settings-field").lastElementChild;
		messageField.textContent = error;
		messageField.classList.remove('simulator-settings-field-hidden');
		messageField.classList.add('has-error');
		messageField.classList.remove('has-notice');
		input.closest('.simulator-settings-field').classList.add('has-error');
		input.closest('.simulator-settings-field').classList.remove('has-notice');
		if (duration) {
			setTimeout(function(e) {
				removeError(input);
			}, duration * 1000);
		}
	}

	function addNotice(input, notice, duration) {
		var messageField = input.closest(".simulator-settings-field").lastElementChild;
		messageField.textContent = notice;
		messageField.classList.remove('simulator-settings-field-hidden');
		messageField.classList.add('has-notice');
		messageField.classList.remove('has-error');
		input.closest('.simulator-settings-field').classList.add('has-notice');
		input.closest('.simulator-settings-field').classList.remove('has-error');
		if (duration) {
			setTimeout(function(e) {
				removeNotice(input);
			}, duration * 1000);
		}
	}

	function removeError(input) {
		var messageField = input.closest(".simulator-settings-field").lastElementChild;
		messageField.textContent = '';
		messageField.classList.add('simulator-settings-field-hidden');
		messageField.classList.remove('has-error');
		input.closest('.simulator-settings-field').classList.remove('has-error');
	}

	function removeNotice(input) {
		var messageField = input.closest(".simulator-settings-field").lastElementChild;
		messageField.textContent = '';
		messageField.classList.add('simulator-settings-field-hidden');
		messageField.classList.remove('has-notice');
		input.closest('.simulator-settings-field').classList.remove('has-notice');
	}

	function fetchSimulators() {
		return new Promise(function (resolve, reject) {
			var xhr = new XMLHttpRequest();
			xhr.open('POST', baseServerUrl.value + '/simulators/api', true);
			// xhr.responseType = 'json';
			xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			xhr.onload = function() {
				if (xhr.status === 200) {
					var response = JSON.parse(xhr.responseText);
					response = response['included']['data'];
					var simus =  [];
					response.forEach (simu => simus.push(simu.id));
					resolve(simus);
				} else {
					reject(null);
				}
			};
			xhr.onerror  = function() {
				reject(null);
			};
			xhr.send(null);
		});
	}

	function fixColors() {
		var defaults = ['#2b4e6b', '#c0c0c0', '#2b4e6b', '#2b4e6b', '#ff0000', '#800000', '#ff0000', '#800000'];
		var colorsTab = document.getElementById("colors_c");
		var colorInputs = colorsTab.querySelectorAll("input[type='color']");
		if (null !== colorInputs) {
			colorInputs.forEach( function(color) {
				var dflt = defaults.shift();
				if (color.value == '') {
					color.value = dflt;
				}
				color.addEventListener('change', function(e) {
					this.nextElementSibling.textContent = this.value;
				});
				color.dispatchEvent(new Event('change'));
			});
		}
	}

	window.addEventListener('DOMContentLoaded', function(event) {
		init();
	});

}(document, window));
