<?php
if(!isset($gCms) ) exit;
if( !$this->CheckPermission(Simulators::MANAGE_PERM) ) return;

include(dirname(__FILE__).'/action.admin_settings.php');

?>
