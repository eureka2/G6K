<?php
if( !isset($gCms) ) exit;
if( !$this->CheckPermission('Modify Site Preferences') ) return;

for ($i = 1; $i <= 5; $i++) {
	$smarty->assign('simulator_data' . $i . '_observer', $this->GetPreference('simulator_data' . $i . '_observer'));
}

// Display template
echo $this->ProcessTemplate('dataobservers.tpl');

?>
