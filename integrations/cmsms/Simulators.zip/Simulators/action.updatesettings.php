<?php
if (!isset($gCms)) exit;
if( !$this->CheckPermission(Simulators::MANAGE_PERM) ) return;

$this->SetPreference('simulator_base_url', $params['simulator_base_url']);
$this->SetPreference('simulator_markup', $params['simulator_markup']);
$this->SetPreference('simulator_adding_bootstrap_classes', (isset($params['simulator_adding_bootstrap_classes'])?'1':'0'));
$this->SetPreference('simulator_bootstrap_version',$params['simulator_bootstrap_version']);
$this->SetPreference('simulator_adding_bootstrap_stylesheet', (isset($params['simulator_adding_bootstrap_stylesheet'])?'1':'0'));
$this->SetPreference('simulator_adding_bootstrap_library', (isset($params['simulator_adding_bootstrap_library'])?'1':'0'));
$this->SetPreference('simulator_adding_jquery_library', (isset($params['simulator_adding_jquery_library'])?'1':'0'));
$this->SetPreference('simulator_primary_color', $params['simulator_primary_color']);
$this->SetPreference('simulator_secondary_color', $params['simulator_secondary_color']);
$this->SetPreference('simulator_breadcrumb_color', trim($params['simulator_breadcrumb_color']));
$this->SetPreference('simulator_tab_color', $params['simulator_tab_color']);
$this->SetPreference('simulator_global_error_color', $params['simulator_global_error_color']);
$this->SetPreference('simulator_global_warning_color', $params['simulator_global_warning_color']);
$this->SetPreference('simulator_field_error_color', $params['simulator_field_error_color']);
$this->SetPreference('simulator_field_warning_color', $params['simulator_field_warning_color']);
$this->SetPreference('simulator_font_family', $params['simulator_font_family']);
$this->SetPreference('simulator_font_size', $params['simulator_font_size']);

for ($i = 1; $i <= 5; $i++) {
	$this->SetPreference('simulator_data' . $i . '_observer', $params['simulator_data' . $i . '_observer']);
	$this->SetPreference('simulator_button' . $i . '_observer', $params['simulator_button' . $i . '_observer']);
}

// $params = ['tab_message'=> 'simulator_settings_updated', 'active_tab' => 'g6kapiserver'];
$this->SetMessage($this->Lang('simulator_settings_updated'));
$this->RedirectToAdminTab('g6kapiserver','','admin_settings');
?>
