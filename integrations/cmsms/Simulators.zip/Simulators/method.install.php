<?php
if( !defined('CMS_VERSION') ) exit;
$this->CreatePermission(Simulators::MANAGE_PERM,'Manage Simulators');

$this->SetPreference('simulator_base_url', '');

$this->SetPreference('simulator_markup', 'fragment');
$this->SetPreference('simulator_adding_bootstrap_classes', '0');
$this->SetPreference('simulator_bootstrap_version', '');
$this->SetPreference('simulator_adding_bootstrap_stylesheet', '0');
$this->SetPreference('simulator_adding_bootstrap_library', '0');
$this->SetPreference('simulator_adding_jquery_library', '0');

$this->SetPreference('simulator_primary_color', '#2b4e6b');
$this->SetPreference('simulator_secondary_color', '#c0c0c0');
$this->SetPreference('simulator_breadcrumb_color', '#2b4e6b');
$this->SetPreference('simulator_tab_color', '#2b4e6b');
$this->SetPreference('simulator_global_error_color', '#ff0000');
$this->SetPreference('simulator_global_warning_color', '#800000');
$this->SetPreference('simulator_field_error_color', '#ff0000');
$this->SetPreference('simulator_field_warning_color', '#800000');

$this->SetPreference('simulator_font_family', 'Arial, Verdana');
$this->SetPreference('simulator_font_size', '1em');

for ($i = 1; $i <= 5; $i++) {
	$this->SetPreference('simulator_data' . $i . '_observer', '');
	$this->SetPreference('simulator_button' . $i . '_observer', '');
}

$this->RegisterModulePlugin(true);
$this->RegisterSmartyPlugin('simulator', 'function', ['Simulators', 'simulator']);
