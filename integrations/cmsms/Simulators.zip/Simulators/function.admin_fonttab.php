<?php
if( !isset($gCms) ) exit;
if( !$this->CheckPermission('Modify Site Preferences') ) return;

$smarty->assign('simulator_font_family', $this->GetPreference('simulator_font_family'));
$smarty->assign('simulator_font_size', $this->GetPreference('simulator_font_size'));

// Display template
echo $this->ProcessTemplate('font.tpl');

?>
