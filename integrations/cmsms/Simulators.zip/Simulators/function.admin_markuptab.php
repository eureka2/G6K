<?php
if( !isset($gCms) ) exit;
if( !$this->CheckPermission('Modify Site Preferences') ) return;

$smarty->assign('simulator_markup', $this->GetPreference('simulator_markup'));
$smarty->assign('simulator_adding_bootstrap_classes', $this->GetPreference('simulator_adding_bootstrap_classes'));
$smarty->assign('simulator_bootstrap_version', $this->GetPreference('simulator_bootstrap_version'));
$smarty->assign('simulator_adding_bootstrap_stylesheet', $this->GetPreference('simulator_adding_bootstrap_stylesheet'));
$smarty->assign('simulator_adding_bootstrap_library', $this->GetPreference('simulator_adding_bootstrap_library'));
$smarty->assign('simulator_adding_jquery_library', $this->GetPreference('simulator_adding_jquery_library'));

// Display template
echo $this->ProcessTemplate('markup.tpl');

?>
