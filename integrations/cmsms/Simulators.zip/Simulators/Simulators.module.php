<?php

class Simulators extends CMSModule {

	const MANAGE_PERM = 'manage_simulators';

	public function GetVersion() {
		return '1.0';
	}

	public function GetFriendlyName() { 
		return $this->Lang('simulator_friendly_name'); 
	}

	public function GetAdminDescription() {
		return $this->Lang('simulator_admin_description');
	}

	public function IsPluginModule() {
		return true;
	}

	public function HasAdmin() {
		return true;
	}

	public function VisibleToAdminUser() {
		return $this->CheckPermission(self::MANAGE_PERM);
	}

	public function GetAuthor() {
		return 'Eureka2';
	}

	public function GetAuthorEmail() {
		return 'https://github.com/eureka2';
	}

	public function GetHelp() {
		return '
<div>
<h1>Textpattern 4.8/G6K integration plugin</h1>
<p>This plugin offers you the possibility of integrating the simulation forms developed with the G6K engine in the Textpattern pages using the G6K <span class="caps">API</span>.</p>
</div>
';
	}

	public function UninstallPreMessage() {
		return $this->Lang('simulator_ask_uninstall');
	}

	public function GetHeaderHTML() {
		return '<link rel="stylesheet" href="../modules/Simulators/css/settings.css" />';
	}

	public function initializefrontend() {
		\CMSMS\HookManager::add_hook('Core::PageHeadPostRender',
		 [$this,'addStyle'] );
		\CMSMS\HookManager::add_hook('Core::PageBodyPostRender',
		 [$this,'addScript'] );
	}

	public function addStyle($head) {
		$content = $head['content']->Show('content_en');
		if ($content !== null && preg_match("/\{simulator\s+/", $content)) {
			$head['html'] = str_replace('</head>', '<link rel="stylesheet" type="text/css" href="modules/Simulators/css/style.css" /></head>' . '', $head['html']);
		}
	}

	public function addScript($body) {
		$content = $body['content']->Show('content_en');
		if ($content !== null && preg_match("/\{simulator\s+/", $content)) {
			$body['html'] = str_replace('</body>', '<script src="modules/Simulators/js/script.js" /></script></body>' . '', $body['html']);
		}
	}

	public static function simulator($params, $smarty) {
		if (isset($params['name'])) {
			$api = new Simulators\Simulator();
			return $api->render($params['name']);
		}
		return '';
	}
}