<?php
if( !isset($gCms) ) exit;
if( !$this->CheckPermission(Simulators::MANAGE_PERM) ) return;

$smarty->assign('startform', $this->CreateFormStart($id, 'updatesettings', $returnid, 'post', 'multipart/form-data'));
echo $this->ProcessTemplate('startform.tpl');

echo $this->StartTabHeaders();
echo $this->SetTabHeader('g6kapiserver',$this->Lang('simulator_g6k_api_server_tab'));
echo $this->SetTabHeader('markup',$this->Lang('simulator_markup_tab'));
echo $this->SetTabHeader('colors',$this->Lang('simulator_colors_tab'));
echo $this->SetTabHeader('font',$this->Lang('simulator_font_tab'));
echo $this->SetTabHeader('dataobservers',$this->Lang('simulator_data_observers_tab'));
echo $this->SetTabHeader('buttonsobservers',$this->Lang('simulator_buttons_observers_tab'));
echo $this->EndTabHeaders();

echo $this->StartTabContent();

echo $this->StartTab('g6kapiserver', $params);
include(dirname(__FILE__).'/function.admin_g6kapiservertab.php');
echo $this->EndTab();

echo $this->StartTab('markup', $params);
include(dirname(__FILE__).'/function.admin_markuptab.php');
echo $this->EndTab();

echo $this->StartTab('colors', $params);
include(dirname(__FILE__).'/function.admin_colorstab.php');
echo $this->EndTab();

echo $this->StartTab('font', $params);
include(dirname(__FILE__).'/function.admin_fonttab.php');
echo $this->EndTab();

echo $this->StartTab('dataobservers', $params);
include(dirname(__FILE__).'/function.admin_dataobserverstab.php');
echo $this->EndTab();

echo $this->StartTab('buttonsobservers', $params);
include(dirname(__FILE__).'/function.admin_buttonsobserverstab.php');
echo $this->EndTab();

echo $this->EndTabContent();

$lang = CmsNlsOperations::get_current_language();
$smarty->assign('lang', substr($lang, 0, 2));
$smarty->assign('endform', $this->CreateFormEnd());
echo $this->ProcessTemplate('endform.tpl');

?>
