<?php
if( !isset($gCms) ) exit;
if( !$this->CheckPermission('Modify Site Preferences') ) return;

for ($i = 1; $i <= 5; $i++) {
	$smarty->assign('simulator_button' . $i . '_observer', $this->GetPreference('simulator_button' . $i . '_observer'));
}

// Display template
echo $this->ProcessTemplate('buttonsobservers.tpl');

?>
