<?php
if( !isset($gCms) ) exit;
if( !$this->CheckPermission(Simulators::MANAGE_PERM) ) return;

$smarty->assign('simulator_base_url', $this->GetPreference('simulator_base_url'));

// Display template
echo $this->ProcessTemplate('g6kapiserver.tpl');

?>
