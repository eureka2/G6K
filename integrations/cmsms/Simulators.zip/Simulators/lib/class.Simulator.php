<?php

namespace Simulators;

class Simulator {

	private function scheme() {
		$isHttps = 
			(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')
			|| (isset($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https')
			|| (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
			|| (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443)
		;
		return $isHttps ? 'https' : 'http';
	}

	private function url($simulator) {
		$baseUrl = $this->setting('simulator_base_url');
		$scheme = $this->scheme();
		$baseUrl = preg_replace("/^https?/", $scheme, $baseUrl);
		return $baseUrl . '/' . $simulator . '/api';
	}

	private function options($simulator) {
		$options = [
			'markup' => $this->setting('simulator_markup', 'fragment'), // 'fragment' or 'page'
			'primaryColor' => $this->setting('simulator_primary_color', '#2b4e6b'), // optional
			'secondaryColor' => $this->setting('simulator_secondary_color', '#c0c0c0'), // optional
			'breadcrumbColor' => $this->setting('simulator_breadcrumb_color', '#2b4e6b'), // optional
			'tabColor' => $this->setting('simulator_tab_color', '#2b4e6b'), // optional
			'globalErrorColor' => $this->setting('simulator_global_error_color', '#ff0000'), // optional
			'globalWarningColor' => $this->setting('simulator_global_warning_color', '#800000'), // optional
			'fieldErrorColor' => $this->setting('simulator_field_error_color', '#ff0000'), // optional
			'fieldWarningColor' => $this->setting('simulator_field_warning_color', '#800000'), // optional
			'fontFamily' => $this->setting('simulator_font_family', 'Arial, Verdana'), // optional
			'fontSize' => $this->setting('simulator_font_size', '1em') // optional
		];
		$bootstrap = $this->setting('simulator_adding_bootstrap_classes', '0');
		if ('1' === $bootstrap) {
			$options['bootstrap'] = $this->setting('simulator_bootstrap_version', ''); // bootstrap version;
			$options['addBootstrapStylesheet'] = $this->setting('simulator_adding_bootstrap_stylesheet', '0') == '1' ? 'true' : 'false';
			$options['addBootstrapScript'] = $this->setting('simulator_adding_bootstrap_library', '0') == '1' ? 'true' : 'false'; 
			$options['addJQueryScript'] = $this->setting('simulator_adding_jquery_library', '0') == '1' ? 'true' : 'false';
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_data' . $i . '_observer';
			$observer = $this->setting($field, '');
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_button' . $i . '_observer';
			$observer = $this->setting($field, '');
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.button';
					}
				}
			}
		}
		return $options;
	}

	public function render($simulator) {
		[$ok, $response] = $this->fetch($simulator, $this->options($simulator));
		return $response;
	}

	public function setting($name, $default = '') {
		return \cms_siteprefs::get('Simulators_mapi_pref_'.$name, $default);
 	}

	private function fetch($simulator, $options = []) {

		$url = $this->url($simulator) . '/html';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $options);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$response = curl_exec($ch);
		$ok = true;
		if (curl_error($ch)) {
			$response = "Oops something went wrong : " . curl_error($ch);
			$ok = false;
		}
		curl_close ($ch);

		return [$ok, $response];

	}
}