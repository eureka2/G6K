<?php
if( !isset($gCms) ) exit;
if( !$this->CheckPermission('Modify Site Preferences') ) return;

$smarty->assign('simulator_primary_color', $this->GetPreference('simulator_primary_color'));
$smarty->assign('simulator_secondary_color', $this->GetPreference('simulator_secondary_color'));
$smarty->assign('simulator_breadcrumb_color', $this->GetPreference('simulator_breadcrumb_color'));
$smarty->assign('simulator_tab_color', $this->GetPreference('simulator_tab_color'));
$smarty->assign('simulator_global_error_color', $this->GetPreference('simulator_global_error_color'));
$smarty->assign('simulator_global_warning_color', $this->GetPreference('simulator_global_warning_color'));
$smarty->assign('simulator_field_error_color', $this->GetPreference('simulator_field_error_color'));
$smarty->assign('simulator_field_warning_color', $this->GetPreference('simulator_field_warning_color'));

// Display template
echo $this->ProcessTemplate('colors.tpl');

?>
