<?php

namespace Eureka2\Simulator;

use App;
use Event;
use BackendAuth;
use Backend\Models\UserPreference;

class Plugin extends \System\Classes\PluginBase {

	public function pluginDetails() {
		return [
			'name' => 'eureka2.simulator::lang.plugin.name',
			'description' => 'eureka2.simulator::lang.plugin.description',
			'author' => 'Eureka2 & Co',
			'icon' => 'calculator'
		];
	}

	public function registerComponents() {
		return [
			'Eureka2\Simulator\Components\Simulator' => 'simulator'
		];
	}

	public function registerPermissions() {
		return [
			'eureka2.simulator.manage_settings' => [
				'tab'   => 'eureka2.simulator::lang.plugin.tab',
				'label' => 'eureka2.simulator::lang.plugin.manage_settings'
			]
		];
	}

	public function registerSettings() {
		return [
			'simulators' => [
				'label' => 'eureka2.simulator::lang.settings.menu_label',
				'description' => 'eureka2.simulator::lang.settings.menu_description',
				'category' => 'eureka2.simulator::lang.settings.menu_label',
				'icon' => 'icon-wpforms',
				'class' => 'Eureka2\Simulator\Models\Settings',
				'order' => 500,
				'keywords' => 'simulator g6k',
				'permissions' => ['eureka2.simulator.manage_settings']
			]
		];
	}

	public function boot() {
		// Check if we are currently in backend module.
		if (!App::runningInBackend()) {
			return;
		}
		// Listen for `backend.page.beforeDisplay` event and inject css and js to current controller instance.
		Event::listen('backend.page.beforeDisplay', function($controller, $action, $params) {
			if ($controller instanceof \System\Controllers\Settings 
				&& is_array($params)
				&& implode('.', $params) === 'eureka2.simulator.simulators') {
				$locale = App::getLocale();
				$user = BackendAuth::getUser();
				$pref = UserPreference::forUser($user);
				$prefs = $pref->get('backend::backend.preferences');
				if ($prefs !== null && is_array($prefs) && isset($prefs['locale'])) {
					$locale = substr($prefs['locale'], 0, 2);
				}
				$controller->addCss('/plugins/eureka2/simulator/assets/css/settings.css');
				$controller->addJs('/plugins/eureka2/simulator/assets/js/lang/' . $locale . '.js');
				$controller->addJs('/plugins/eureka2/simulator/assets/js/settings.js');
			}
		});
	}
}