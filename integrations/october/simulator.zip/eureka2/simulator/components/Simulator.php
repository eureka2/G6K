<?php

namespace Eureka2\Simulator\Components;

use Cms\Classes\ComponentBase;
use Eureka2\Simulator\Models\Settings;
use October\Rain\Network\Http;

class Simulator extends ComponentBase {

	public function componentDetails() {
		return [
			'name' => 'eureka2.simulator::lang.component.name',
			'description' => 'eureka2.simulator::lang.component.description'
		];
	}

	public function defineProperties() {
		return [
			'name' => [
				 'title'             => 'eureka2.simulator::lang.component.property_title',
				 'description'       => 'eureka2.simulator::lang.component.property_description',
				 'default'           => '',
				 'type'              => 'string',
			]
		];
	}

	public function init() {
		$this->addCss('/plugins/eureka2/simulator/assets/css/style.css');
		$this->addJs('/plugins/eureka2/simulator/assets/js/script.js');
	}

	/**
	 * Executed when this component is rendered on a page or layout.
	 */
	public function onRender() {
		$this->page['simulation'] = $this->render($this->property('name'));
	}

	private function url($simulator, $baseUrl = null) {

		$settings = Settings::instance();

		if (null === $baseUrl) {
			$baseUrl = $settings->base_url;
		}
		if (preg_match("|^(https?)://|", $this->pageUrl(''), $m)) {
			$baseUrl = preg_replace("|^https?|", $m[1], $baseUrl);
		}
		return $baseUrl . '/' . $simulator . '/api';
	}

	public function attributes(string $simulator = null) {
		$url = $this->url($simulator) . '/json';
		[$ok, $api] = $this->fetch($url);
		if ($ok) {
			$api = json_decode($api, true);
			return $api['data']['attributes'];
		} else {
			return [ 'title' => $api, 'description' => $api ];
		}
	}

	public function simulators($baseUrl = null) {
		$url = $this->url('simulators', $baseUrl);
		[$ok, $api] = $this->fetch($url);
		$simulators = [];
		if ($ok) {
			$api = json_decode($api, true);
			$data = $api['included']['data'];
			foreach($data as $simu) {
				$simulators[] = $simu['id'];
			}
			return $simulators;
		}
		return false;
	}

	private function options($simulator) {

		$settings = Settings::instance();

		$options = [
			'markup' => $settings->html_markup ?? 'fragment', // 'fragment' or 'page'
			'primaryColor' => $settings->primary_color ?? '#2b4e6b', // optional
			'secondaryColor' => $settings->secondary_color ?? '#c0c0c0', // optional
			'breadcrumbColor' => $settings->breadcrumb_color ?? '#2b4e6b', // optional
			'tabColor' => $settings->tab_color ?? '#2b4e6b', // optional
			'globalErrorColor' => $settings->global_error_color ?? '#ff0000', // optional
			'globalWarningColor' => $settings->global_warning_color ?? '#800000', // optional
			'fieldErrorColor' => $settings->field_error_color ?? '#ff0000', // optional
			'fieldWarningColor' => $settings->field_warning_color ?? '#800000', // optional
			'fontFamily' => $settings->font_family ?? 'Arial, Verdana', // optional
			'fontSize' => $settings->font_size ?? '1em', // optional
		];
		$bootstrap = $settings->adding_bootstrap_classes ?? '0';
		if ('1' === $bootstrap) {
			$options['bootstrap'] = $settings->bootstrap_version ?? ''; // bootstrap version;
			$options['addBootstrapStylesheet'] = $settings->adding_bootstrap_stylesheet ?? '0' == '1' ? 'true' : 'false';
			$options['addBootstrapScript'] = $settings->adding_bootstrap_library ?? '0' == '1' ? 'true' : 'false'; 
			$options['addJQueryScript'] = $settings->adding_jquery_library ?? '0'  == '1' ? 'true' : 'false';
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'data' . $i . '_observer';
			$observer = $settings->$field ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'button' . $i . '_observer';
			$observer = $settings->$field ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		return $options;
	}

	public function render($simulator) {
		$options = $this->options($simulator); 
		[$ok, $markup] = $this->fetch($this->url($simulator) . '/html', $options);
		return $markup;
	}

	private function fetch(string $url, array $options = []) {
		$response = Http::post($url, function($http) use ($options) {
			$http->data($options);
		});
		if ($response->code == 200) {
			$ok = true;
			$result = $response->body;
		} else {
			$ok = false;
			$result =  "Oops, something went wrong. Please try again " . $url . ' # ' . $response->info;
		}
		return [$ok, $result];
	}
}