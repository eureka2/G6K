<?php namespace Eureka2\Simulator\Models;

use October\Rain\Database\Model;

class Settings extends Model
{
    use \October\Rain\Database\Traits\Validation;

    public $implement = ['System.Behaviors.SettingsModel'];

    public $settingsCode = 'eureka2_simulator_settings';

    public $settingsFields = 'fields.yaml';

    public $rules = [
        'base_url' => ['string'],
        'adding_bootstrap_classes' => ['boolean'],
        'bootstrap_version' => ['string'],
        'adding_bootstrap_stylesheet' => ['boolean'],
        'adding_bootstrap_library' => ['boolean'],
        'adding_jquery_library' => ['boolean'],
        'primary_color' => ['string'],
        'secondary_color' => ['string'],
        'breadcrumb_color' => ['string'],
        'tab_color' => ['string'],
        'global_error_color' => ['string'],
        'global_warning_color' => ['string'],
        'field_error_color' => ['string'],
        'field_warning_color' => ['string'],
        'font_family' => ['string'],
        'font_size' => ['string'],
        'data1_observer' => ['string'],
        'data2_observer' => ['string'],
        'data3_observer' => ['string'],
        'data4_observer' => ['string'],
        'data5_observer' => ['string'],
        'button1_observer' => ['string'],
        'button2_observer' => ['string'],
        'button3_observer' => ['string'],
        'button4_observer' => ['string'],
        'button5_observer' => ['string'],
    ];
}
