<?php

namespace Eureka\Simulator\Validator;

class SimulatorSettingsValidator extends \TYPO3\CMS\Extbase\Validation\Validator\AbstractValidator {
	protected $settings = NULL;

	public function isValid($property) { 
		error_log(var_export($property, true));
		$this->addError('The value you are entered is not valid.', 1451318887);
	}

	public function getSettings() {
		if (is_null($this->settings)) {
			$this->settings = [];
			$objectManager = GeneralUtility::makeInstance(ObjectManager::class);
			$configurationManager = $objectManager->get(ConfigurationManager::class);
			$this->settings = $configurationManager->getConfiguration(
				ConfigurationManagerInterface::CONFIGURATION_TYPE_SETTINGS,
				'simulator'
			);
		}
		return $this->settings;
	}
}
