<?php

namespace Eureka\Simulator\Controller;

use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;
use Eureka\Simulator\SimulatorAPI;

class SimulatorController extends ActionController {

	public function markupAction() {
		$api = new SimulatorAPI();
		$markup = $api->markup();
		$this->view->assign('markup', $markup);
	}

}