<?php

namespace Eureka\Simulator;

use TYPO3\CMS\Core\Utility\GeneralUtility;
use Psr\Http\Message\RequestFactoryInterface;
use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;

class SimulatorAPI {

	/** @var RequestFactoryInterface */
	private $requestFactory;

	// Initiate the Request Factory, which allows to run multiple requests (prefer dependency injection)
	public function __construct() {
		$this->requestFactory = GeneralUtility::makeInstance(\TYPO3\CMS\Core\Http\RequestFactory::class);
	}

	/**
	* Output the current time in red letters
	*
	* @param  string          Empty string (no content to process)
	* @param  array           TypoScript configuration
	* @return string          HTML output, showing the current server time.
	*/
	public function html(string $content, array $conf): string {
		return '<p style="color: red;">Dynamic time: ' . date('H:i:s') . '</p><br />';
		// return $this->markup($conf['simulator']);
	}

	public function url($simulator = null, $baseUrl = null) {
		$this->check($simulator);
		if (null === $baseUrl) {
			$baseUrl = GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('simulator', 'base_server_url');
		}
		$request = $GLOBALS['TYPO3_REQUEST'];
		$scheme = $request->getUri()->getScheme();
		return preg_replace("/^https?/", $scheme, $baseUrl) . "/" . $simulator . "/api";
	}

	public function attributes(string $simulator = null) {
		$this->check($simulator);
		$url = $this->url($simulator) . '/json';
		[$ok, $api] = $this->fetch($url);
		if ($ok) {
			$api = json_decode($api, true);
			return $api['data']['attributes'];
		} else {
			return [ 'title' => $api ];
		}
	}

	public function simulators($baseUrl = null) {
		$url = $this->url('simulators', $baseUrl);
		[$ok, $api] = $this->fetch($url);
		$simulators = [];
		if ($ok) {
			$api = json_decode($api, true);
			$data = $api['included']['data'];
			foreach($data as $simu) {
				$simulators[] = $simu['id'];
			}
			return $simulators;
		}
		return false;
	}

	public function markup(string $simulator = null) {
		$this->check($simulator);
		$url = $this->url($simulator) . '/html';

		$config = GeneralUtility::makeInstance(ExtensionConfiguration::class);

		$options = [
			'markup' => $config->get('simulator', 'html_markup') ?? 'fragment', // 'fragment' or 'page'
			'primaryColor' => $config->get('simulator', 'primary_color') ?? '#2b4e6b', // optional
			'secondaryColor' => $config->get('simulator', 'secondary_color') ?? '#c0c0c0', // optional
			'fontFamily' => $config->get('simulator', 'font_family') ?? 'Arial, Verdana', // optional
			'fontSize' => $config->get('simulator', 'font_size') ?? '1em', // optional
			'breadcrumbColor' => $config->get('simulator', 'breadcrumb_color') ?? '#2b4e6b', // optional
			'tabColor' => $config->get('simulator', 'tab_color') ?? '#2b4e6b', // optional
			'globalErrorColor' => $config->get('simulator', 'global_error_color') ?? '#ff0000', // optional
			'globalWarningColor' => $config->get('simulator', 'global_warning_color') ?? '#800000', // optional
			'fieldErrorColor' => $config->get('simulator', 'field_error_color') ?? '#ff0000', // optional
			'fieldWarningColor' => $config->get('simulator', 'field_warning_color') ?? '#800000', // optional
		];
		if ($config->get ( 'simulator', 'adding_bootstrap_classes' ) == 1) {
			$options['bootstrap'] = $config->get('simulator', 'bootstrap_version') ?? ''; // bootstrap version
			$options['addBootstrapStylesheet'] = $config->get( 'simulator', 'adding_bootstrap_stylesheet') == 1 ? 'true' : 'false';
			$options['addBootstrapScript'] = $config->get( 'simulator', 'adding_bootstrap_library') == 1 ? 'true' : 'false'; 
			$options['addJQueryScript'] = $config->get( 'simulator', 'adding_jquery_library') == 1 ? 'true' : 'false';
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer = $config->get('simulator', 'data' . $i . '_observer') ?? '';
			if ($observer != '') {
				[$simu, $field] = explode(":", $observer);
				if ($simu == $simulator) {
					$options[$field] = 'ResultObserver.field';
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer = $config->get('simulator', 'button' . $i . '_observer') ?? '';
			if ($observer != '') {
				[$simu, $field] = explode(":", $observer);
				if ($simu == $simulator) {
					$options[$field] = 'ResultObserver.button';
				}
			}
		}
		[$ok, $markup] = $this->fetch($url, $options);
		return $markup;
	}

	protected function fetch(string $url, array $options = []) {
		try {
			$request = $this->requestFactory->request($url, 'POST', [
				'form_params' => $options,
				'verify' => false
			]);
			$statusCode = $request->getStatusCode();
			$response = $request->getBody()->getContents();
			return [$statusCode == 200, $response];
		}
		catch (\Exception $e){
			return [false, "Oops, something went wrong.  Please try again later.  #:" . $url . " = " . $e->getMessage()];
		}
	}

	protected function check(&$simulator) {
		if ($simulator === null) {
			$request = $GLOBALS['TYPO3_REQUEST'];
			$currentUrl = $request->getUri()->getPath();
			$simulator = end(explode("/", $currentUrl));
			if ($simulator == "" || $simulator == 'simulator') {
				$simulator = 'demo';
			}
		}
	}

}