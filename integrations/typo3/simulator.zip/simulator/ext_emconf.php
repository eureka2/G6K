<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'Simulator',
    'description' => 'TYPO3 9 / G6K Integration extension',
    'category' => 'plugin',
    'author' => 'Eureka2',
    'author_company' => 'TYPO3',
    'author_email' => 'documentation@typo3.org',
    'state' => 'alpha',
    'clearCacheOnLoad' => true,
    'version' => '1.0.0',
    'constraints' => [
        'depends' => [
            'typo3' => '9.5.24-9.9.99',
        ]
    ],
    'autoload' => [
        'psr-4' => [
            'Eureka\\Simulator\\' => 'Classes'
        ]
    ],
];