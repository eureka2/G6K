<?php

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
	'Eureka.Simulator',
	'Simulator',
	'The G6K API Integration',
	'EXT:simulator/Resources/Public/Icons/Extension.svg'
);
