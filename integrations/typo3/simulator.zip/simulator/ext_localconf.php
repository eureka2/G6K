<?php
defined('TYPO3_MODE') || die('Access denied.');

$langservice = $GLOBALS['LANG'];
$lang = $langservice->lang;
if ($lang == 'default' || $lang == 'en') {
	$lang = '';
}
if ($lang != '') {
	$lang .= '.';
	if (! file_exists(__DIR__ . "/Resources/Private/Language/" . $lang . "locallang.xlf")) {
		$lang = '';
	}
}
$renderer = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Page\PageRenderer::class);
$renderer->addInlineLanguageLabelFile('EXT:simulator/Resources/Private/Language/' . $lang . 'locallang.xlf');

$renderer->loadRequireJsModule(
   'TYPO3/CMS/Simulator/Simulator',
   'function() { require(["Simulator"], function(s) {s.init()}); }'
);
call_user_func(function() {
   $extensionKey = 'simulator';
   \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTypoScript(
      $extensionKey,
      'constants',
      "@import 'EXT:simulator/Configuration/TypoScript/constants.typoscript'"
   );
   \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTypoScript(
      $extensionKey,
      'setup',
      "@import 'EXT:simulator/Configuration/TypoScript/setup.typoscript'"
   );
});

call_user_func(
    function () {
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Eureka.Simulator',
            'Simulator',
            [ 'Simulator' => 'markup' ]
        );
    }
);
