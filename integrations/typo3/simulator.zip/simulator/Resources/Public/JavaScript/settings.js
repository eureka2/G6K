window.addEventListener('DOMContentLoaded', function(event) {

	var baseServerUrl = null;
	var addingBootstrap = null;
	var bootstrapVersion = null;
	var addingStyleSheet = null;
	var addingLibrary = null;
	var addingJQuery = null;
	var fontSize = null;
	var dataObservers = [];
	var buttonObservers = [];
	var simulators = null;

	function fetchSimulators() {
		return new Promise(function (resolve, reject) {
			var xhr = new XMLHttpRequest();
			xhr.open('POST', baseServerUrl.value + '/simulators/api', true);
			// xhr.responseType = 'json';
			xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			xhr.onload = function() {
				if (xhr.status === 200) {
					var response = JSON.parse(xhr.responseText);
					response = response['included']['data'];
					var simus =  [];
					response.forEach (simu => simus.push(simu.id));
					resolve(simus);
				} else if (xhr.status !== 200) {
					reject({ status: xhr.status, statusText: xhr.statusText });
				}
			};
			xhr.onerror  = function() {
				reject({ status: xhr.status, statusText: xhr.statusText });
			};
			xhr.send(null);
		});
	}

	function hide(input) {
		if (input !== null) {
			var container = input.closest('.form-group');
			if (container !== null) {
				container.style.display = 'none';
			}
		}
	}

	function show(input) {
		if (input !== null) {
			var container = input.closest('.form-group');
			if (container !== null) {
				container.style.display = '';
			}
		}
	}

	async function validateBaseServerUrl() {
		if (baseServerUrl.value === '') {
			top.TYPO3.Notification.error(TYPO3.lang['simulator.settings'], "The base url of the server is required", 5);
			baseServerUrl.closest('.form-group').classList.add('has-error');
			return false;
		} else if (!/^https?:\/\/.+$/.test(baseServerUrl.value)) {
			top.TYPO3.Notification.error('simulator settings', "The base url of the server is invalid", 5);
			baseServerUrl.closest('.form-group').classList.add('has-error');
			return false;
		} else {
			try {
				if (simulators === null) {
					simulators = await fetchSimulators();
				}
				baseServerUrl.closest('.form-group').classList.remove('has-error');
				return false;
			} catch(error) {
				top.TYPO3.Notification.error('simulator settings', "The server '%s' is not responding or is not a G6K API server.".replace("%s", baseServerUrl.value), 5);
				baseServerUrl.closest('.form-group').classList.add('has-error');
				return false;
			}
		}
	}

	function validateFontSize() {
		if (fontSize.value !== '') {
			var allowedSizes = [ 'xx-small', 'x-small', 'small', 'medium', 'large', 'x-large', 'xx-large', 'larger', 'smaller', 'inherit', 'initial', 'unset' ];
			if (allowedSizes.indexOf(fontSize.value) < 0) {
				if (!/^\d+(\.\d+)?(px|pt|pc|ex|cm|mm|in|em|rem|%)$/.test(fontSize.value)) {
					top.TYPO3.Notification.error('simulator settings', "The font size '%s' is invalid.".replace("%s", fontSize.value), 5);
					fontSize.closest('.form-group').classList.add('has-error');
					return false;
				}
			}
		}
		fontSize.closest('.form-group').classList.remove('has-error');
		return true;
	}

	function validateBootstrapVersion() {
		if (addingBootstrap.checked) {
			if (bootstrapVersion.value == '') { 
				top.TYPO3.Notification.error('simulator settings', "The bootstrap version is required", 5);
				bootstrapVersion.closest('.form-group').classList.add('has-error');
				return false;
			} else if (!/^\d+\.\d+\.\d+$/.test(bootstrapVersion.value)) {
				top.TYPO3.Notification.error('simulator settings', "The bootstrap version is not in the required format", 5);
				bootstrapVersion.closest('.form-group').classList.add('has-error');
				return false;
			}
		} else if (bootstrapVersion.value !== '') {
			top.TYPO3.Notification.error('simulator settings', "The bootstrap version must be empty", 5);
			bootstrapVersion.closest('.form-group').classList.add('has-error');
			return false;
		}
		bootstrapVersion.closest('.form-group').classList.remove('has-error');
		return true;
	}

	function validateDataObserver(num) {
		var observer = dataObservers[num];
		if (observer.value != '') {
			var m = observer.value.match(/^([\-\w]+):[\-\w]+$/);
			if (m) {
				if (simulators !== null && simulators.indexOf(m[1]) < 0) {
					top.TYPO3.Notification.error('simulator settings', "The simulator '%s' is not known by the API server".replace("%s", m[1]), 5);
					observer.closest('.form-group').classList.add('has-error');
					return false;
				}
			} else {
				top.TYPO3.Notification.error('simulator settings', "The data '%s' to observe is not in the required format".replace("%s", observer.value), 5);
				observer.closest('.form-group').classList.add('has-error');
				return false;
			}
		}
		observer.closest('.form-group').classList.remove('has-error');
		return true;
	}

	function validateDataObservers() {
		var ok = true;
		for (var i = 0; i < 5; i++) {
			if (dataObservers[i]) {
				if (!validateDataObserver(i)) {
					ok = false;
				}
			}
		}
		return ok;
	}

	function validateButtonObserver(num) {
		var observer = buttonObservers[num];
		if (observer.value != '') {
			var m = observer.value.match(/^([\-\w]+):[\-\w]+$/);
			if (m) {
				if (simulators !== null && simulators.indexOf(m[1]) < 0) {
					top.TYPO3.Notification.error('simulator settings', "The simulator '%s' is not known by the API server".replace("%s", m[1]), 5);
					observer.closest('.form-group').classList.add('has-error');
					return false;
				}
			} else {
				top.TYPO3.Notification.error('simulator settings', "The button '%s' to observe is not in the required format".replace("%s", observer.value), 5);
				observer.closest('.form-group').classList.add('has-error');
				return false;
			}
		}
		observer.closest('.form-group').classList.remove('has-error');
		return true;
	}

	function validateButtonObservers() {
		var ok = true;
		for (var i = 0; i < 5; i++) {
			if (buttonObservers[i]) {
				if (!validateButtonObserver(i)) {
					ok = false;
				}
			}
		}
		return ok;
	}

	function validateAll() {
		return validateBaseServerUrl()
			&& validateBootstrapVersion()
			&& validateFontSize()
			&& validateDataObservers()
			&& validateButtonObservers();
	}

	function register(input) {
		if (input.name == 'base_server_url') {
			if (baseServerUrl === null) {
				baseServerUrl = input;
			} else if (baseServerUrl !== input) {
				baseServerUrl = input;
				simulators = null;
			}
			baseServerUrl.addEventListener('blur', function(e) {
				if (! validateBaseServerUrl()) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'adding_bootstrap_classes') {
			addingBootstrap = input;
			addingBootstrap.addEventListener('change', function(e) {
				if (this.checked) {
					show(bootstrapVersion);
					show(addingStyleSheet);
					show(addingLibrary);
					show(addingJQuery);
				} else {
					hide(bootstrapVersion);
					hide(addingStyleSheet);
					hide(addingLibrary);
					hide(addingJQuery);
				}
			});
			var form = addingBootstrap.closest('form');
			if (form !== null) {
				form.addEventListener('submit', function(e) {
					if (!validateAll()) {
						e.stopPropagation();
						e.preventDefault();
					}
				});
			}
			setTimeout(function() {
				addingBootstrap.dispatchEvent(new Event('change'));
			}, 0);
		} else if (input.name == 'bootstrap_version') {
			bootstrapVersion = input;
			bootstrapVersion.addEventListener('blur', function(e) {
				if (! validateBootstrapVersion()) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'adding_bootstrap_stylesheet') {
			addingStyleSheet = input;
		} else if (input.name == 'adding_bootstrap_library') {
			addingLibrary = input;
		} else if (input.name == 'adding_jquery_library') {
			addingJQuery = input;
		} else if (input.name == 'font_size') {
			fontSize = input;
			fontSize.addEventListener('blur', function(e) {
				if (! validateFontSize()) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'data1_observer') {
			dataObservers[0] = input;
			dataObservers[0].addEventListener('blur', function(e) {
				if (! validateDataObserver(0)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'data2_observer') {
			dataObservers[1] = input;
			dataObservers[1].addEventListener('blur', function(e) {
				if (! validateDataObserver(1)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'data3_observer') {
			dataObservers[2] = input;
			dataObservers[2].addEventListener('blur', function(e) {
				if (! validateDataObserver(2)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'data4_observer') {
			dataObservers[3] = input;
			dataObservers[3].addEventListener('blur', function(e) {
				if (! validateDataObserver(3)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'data5_observer') {
			dataObservers[4] = input;
			dataObservers[4].addEventListener('blur', function(e) {
				if (! validateDataObserver(4)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'button1_observer') {
			buttonObservers[0] = input;
			buttonObservers[0].addEventListener('blur', function(e) {
				if (! validateButtonObserver(0)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'button2_observer') {
			buttonObservers[1] = input;
			buttonObservers[1].addEventListener('blur', function(e) {
				if (! validateButtonObserver(1)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'button3_observer') {
			buttonObservers[2] = input;
			buttonObservers[2].addEventListener('blur', function(e) {
				if (! validateButtonObserver(2)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'button4_observer') {
			buttonObservers[3] = input;
			buttonObservers[3].addEventListener('blur', function(e) {
				if (! validateButtonObserver(3)) {
					e.preventDefault();
				}
			});
		} else if (input.name == 'button5_observer') {
			buttonObservers[4] = input;
			buttonObservers[4].addEventListener('blur', function(e) {
				if (! validateButtonObserver(4)) {
					e.preventDefault();
				}
			});
		}
	}

	function observe(m) {
		m.forEach(record => {
			record.addedNodes.forEach( node => {
				if (node.nodeName == 'INPUT') {
					register(node);
				} else if (node.nodeType == 1) {
					var inputs = node.querySelectorAll("input:not([type='hidden']), select");
					inputs.forEach( input => {
						register(input);
					});
				}
			});
		});
	}

	var observeDOM = (function(){
		var MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
		return function( obj, callback ){
			if( !obj || obj.nodeType !== 1 ) return;
			if ( MutationObserver ){
				var mutationObserver = new MutationObserver(callback)
				mutationObserver.observe( obj, { childList:true, subtree:true })
				return mutationObserver
			}
			else if( window.addEventListener ){
			  obj.addEventListener('DOMNodeInserted', callback, false)
			  obj.addEventListener('DOMNodeRemoved', callback, false)
			}
		}
	})();

	observeDOM( document.body, function(m){ 
		observe(m);
	});
});

