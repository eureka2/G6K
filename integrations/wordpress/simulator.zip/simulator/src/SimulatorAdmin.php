<?php

/*
The MIT License (MIT)

Copyright (c) 2021 Jacques Archimède

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

class SimulatorAdmin {

	private static $initiated = false;
	private static $simulators = null;

	public static function init() {
		if ( ! self::$initiated ) {
			self::init_hooks();
		}
	}

	public static function init_hooks() {
		self::$initiated = true;
		add_filter(
			'plugin_action_links_simulator/simulator.php',
			function ( $links ) {
				array_unshift( $links, '<a href="' .
					admin_url( 'options-general.php?page=simulator_fields' ) .
					'">' . __('Settings') . '</a>');
				return $links;
			}
		);
		wp_enqueue_style( 
			'simulator/admin-settings-style', 
			SIMULATOR__ASSETS_URL . 'settings.css', 
			[], // no dependencies
			SIMULATOR_VERSION
		);
		wp_enqueue_script( 
			'simulator/admin-settings-script', 
			SIMULATOR__ASSETS_URL . 'settings.js', 
			[], // no dependencies
			SIMULATOR_VERSION
		);
	}

	public static function menu( ) {
		load_plugin_textdomain( 'simulator', false, basename( dirname( dirname( __FILE__ ) ) ) . '/languages/' );
		add_submenu_page(
			"options-general.php",
			esc_html__( "Simulator Plugin", 'simulator'),
			esc_html__( "Simulator Plugin", 'simulator'),
			"manage_options",
			"simulator_fields",
			["SimulatorAdmin", "page"]
		);
	}

	// for tabs, see : https://code.tutsplus.com/tutorials/the-wordpress-settings-api-part-5-tabbed-navigation-for-settings--wp-24971
	public static function page( ) {
		load_plugin_textdomain( 'simulator', false, basename( dirname( dirname( __FILE__ ) ) ) . '/languages/' );
	?>
<div class="wrap">
	<h2>
		<?php echo esc_html__( 'Simulator Plugin Settings', 'simulator'); ?>
	</h2>

	<form method="post" action="options.php">

	<h2 id="simulator-settings-tabs" class="nav-tab-wrapper">
		<a href="#simulator-settings-server" class="nav-tab nav-tab-active"><?php echo esc_html__( "G6K API Server", 'simulator'); ?></a>
		<a href="#simulator-settings-colors" class="nav-tab"><?php echo esc_html__( "Colors", 'simulator'); ?></a>
		<a href="#simulator-settings-font" class="nav-tab"><?php echo esc_html__( "Font", 'simulator'); ?></a>
		<a href="#simulator-settings-markup" class="nav-tab"><?php echo esc_html__( "HTML Markup", 'simulator'); ?></a>
		<a href="#simulator-settings-observers" class="nav-tab"><?php echo esc_html__( "Observers", 'simulator'); ?></a>
	</h2>
	<?php
	settings_fields ( "simulator_fields" );
	?>
	<div id="simulator-settings-server" class="simulator-settings-section nav-pane-active">
	<?php
		do_settings_sections ( "simulator_fields_server" );
	?>
	</div>
	<div id="simulator-settings-colors" class="simulator-settings-section">
	<?php
		do_settings_sections ( "simulator_fields_colors" );
	?>
	</div>
	<div id="simulator-settings-font" class="simulator-settings-section">
	<?php
		do_settings_sections ( "simulator_fields_font" );
	?>
	</div>
	<div id="simulator-settings-markup" class="simulator-settings-section">
	<?php
		do_settings_sections ( "simulator_fields_markup" );
	?>
	</div>
	<div id="simulator-settings-observers" class="simulator-settings-section">
	<?php
		do_settings_sections ( "simulator_fields_observers" );
	?>
	</div>
	<?php
	submit_button ();
	?>
	</form>
</div> 
<?php
	}

	public static function check_simulators( $input = null ) {
		if (self::$simulators === null || $input !== null ) {
			self::$simulators = Simulator::simulators($input);
		}
	}

	public static function settings( ) {
		load_plugin_textdomain( 'simulator', false, basename( dirname( dirname( __FILE__ ) ) ) . '/languages/' );
		add_settings_section (
			"simulator_server_url_section",
			esc_html__( "G6K API Server", 'simulator'),
			null,
			"simulator_fields_server"
		);
		add_settings_field (
			"simulator-server-url",
			esc_html__( "Base url of the server", 'simulator'),
			[ "SimulatorAdmin", "server_url"],
			"simulator_fields_server",
			"simulator_server_url_section"
		);
		register_setting ( "simulator_fields", "simulator-server-url", ["SimulatorAdmin", "validate_server_url"] );
		add_settings_section (
			"simulator_colors_section",
			esc_html__( "Colors settings", 'simulator'),
			null,
			"simulator_fields_colors"
		);
		add_settings_field (
			"simulator-primary-color",
			esc_html__( "Primary color", 'simulator'),
			[ "SimulatorAdmin", "primary_color"],
			"simulator_fields_colors",
			"simulator_colors_section"
		);
		register_setting ( "simulator_fields", "simulator-primary-color" );
		add_settings_field (
			"simulator-secondary-color",
			esc_html__( "Secondary color", 'simulator'),
			[ "SimulatorAdmin", "secondary_color"],
			"simulator_fields_colors",
			"simulator_colors_section"
		);
		register_setting ( "simulator_fields", "simulator-secondary-color" );
		add_settings_field (
			"simulator-breadcrumb-color",
			esc_html__( "Breadcrumb color", 'simulator'),
			[ "SimulatorAdmin", "breadcrumb_color"],
			"simulator_fields_colors",
			"simulator_colors_section"
		);
		register_setting ( "simulator_fields", "simulator-breadcrumb-color" );
		add_settings_field (
			"simulator-tab-color",
			esc_html__( "Tab color", 'simulator'),
			[ "SimulatorAdmin", "tab_color"],
			"simulator_fields_colors",
			"simulator_colors_section"
		);
		register_setting ( "simulator_fields", "simulator-tab-color" );
		add_settings_field (
			"simulator-global-error-color",
			esc_html__( "Global error color", 'simulator'),
			[ "SimulatorAdmin", "global_error_color"],
			"simulator_fields_colors",
			"simulator_colors_section"
		);
		register_setting ( "simulator_fields", "simulator-global-error-color" );
		add_settings_field (
			"simulator-global-warning-color",
			esc_html__( "Global warning color", 'simulator'),
			[ "SimulatorAdmin", "global_warning_color"],
			"simulator_fields_colors",
			"simulator_colors_section"
		);
		register_setting ( "simulator_fields", "simulator-global-warning-color" );
		add_settings_field (
			"simulator-field-error-color",
			esc_html__( "Field error color", 'simulator'),
			[ "SimulatorAdmin", "field_error_color"],
			"simulator_fields_colors",
			"simulator_colors_section"
		);
		register_setting ( "simulator_fields", "simulator-field-error-color" );
		add_settings_field (
			"simulator-field-warning-color",
			esc_html__( "Field warning color", 'simulator'),
			[ "SimulatorAdmin", "field_warning_color"],
			"simulator_fields_colors",
			"simulator_colors_section"
		);
		register_setting ( "simulator_fields", "simulator-field-warning-color" );
		add_settings_section (
			"simulator_font_section",
			esc_html__( "Font settings", 'simulator'),
			null,
			"simulator_fields_font"
		);
		add_settings_field (
			"simulator-field-font-family",
			esc_html__( "Font family", 'simulator'),
			[ "SimulatorAdmin", "font_family"],
			"simulator_fields_font",
			"simulator_font_section"
		);
		register_setting ( "simulator_fields", "simulator-field-font-family" );
		add_settings_field (
			"simulator-field-font-size",
			esc_html__( "Font size", 'simulator'),
			[ "SimulatorAdmin", "font_size"],
			"simulator_fields_font",
			"simulator_font_section"
		);
		register_setting ( "simulator_fields", "simulator-field-font-size" );
		add_settings_section (
			"simulator_markup_section",
			esc_html__( "Markup settings", 'simulator'),
			null,
			"simulator_fields_markup"
		);
		add_settings_field (
			"simulator-field-html-markup",
			esc_html__( "HTML Markup", 'simulator'),
			[ "SimulatorAdmin", "html_markup"],
			"simulator_fields_markup",
			"simulator_markup_section"
		);
		register_setting ( "simulator_fields", "simulator-field-html-markup" );
		add_settings_field (
			"simulator-field-insertion-mode",
			esc_html__( "Insertion mode in pages/articles", 'simulator'),
			[ "SimulatorAdmin", "insertion_mode"],
			"simulator_fields_markup",
			"simulator_markup_section"
		);
		register_setting ( "simulator_fields", "simulator-field-insertion-mode" );
		add_settings_field (
			"simulator-field-adding-bootstrap",
			esc_html__( "Adding Bootstrap classes", 'simulator'),
			[ "SimulatorAdmin", "adding_bootstrap"],
			"simulator_fields_markup",
			"simulator_markup_section"
		);
		register_setting ( "simulator_fields", "simulator-field-adding-bootstrap" );
		add_settings_field (
			"simulator-field-bootstrap-version",
			esc_html__( "Bootstrap version", 'simulator'),
			[ "SimulatorAdmin", "bootstrap_version"],
			"simulator_fields_markup",
			"simulator_markup_section"
		);
		register_setting ( "simulator_fields", "simulator-field-bootstrap-version", ["SimulatorAdmin", "validate_bootstrap_version"] );
		add_settings_section (
			"simulator-fields-observer-section",
			esc_html__( "Data observer", 'simulator'),
			function() { echo esc_html__( 'Enter the data to observe with the following format: <simulator name>:<data name>', 'simulator'); },
			"simulator_fields_observers"
		);
		for ($i = 1; $i <= 5; $i++) {
			add_settings_field (
				"simulator-field-observer" . $i,
				sprintf( esc_html__( 'Data %d', 'simulator' ), $i ),
				[ "SimulatorAdmin", "fields_observer"],
				"simulator_fields_observers",
				"simulator-fields-observer-section",
				[ 'id' => "simulator-field-observer" . $i ]
			);
			register_setting ( "simulator_fields", "simulator-field-observer" . $i, ["SimulatorAdmin", "validate_fields_observer"] );
		}
		add_settings_section (
			"simulator-buttons-observer-section",
			esc_html__( "Buttons observer", 'simulator'),
			function() { echo esc_html__( 'Enter the button to observe with the following format: <simulator name>:<button name>', 'simulator'); },
			"simulator_fields_observers"
		);
		for ($i = 1; $i <= 5; $i++) {
			add_settings_field (
				"simulator-button-observer" . $i,
				sprintf( esc_html__( 'Button %d', 'simulator' ), $i ),
				[ "SimulatorAdmin", "buttons_observer"],
				"simulator_fields_observers",
				"simulator-buttons-observer-section",
				[ 'id' => "simulator-button-observer" . $i ]
			);
			register_setting ( "simulator_fields", "simulator-button-observer" . $i, ["SimulatorAdmin", "validate_buttons_observer"] );
		}
	}

	public static function server_url() {
		printf(
			'<input type="url" name="simulator-server-url" value="%s" />',
			esc_attr ( get_option ( 'simulator-server-url', '' ) )
		);
		echo '<br>' . esc_html__( 'Enter the absolute url pointing to the pulic directory of the API server', 'simulator');
	}

	public static function validate_server_url( $input ) {
		if ($input != '') {
			self::check_simulators( $input );
			if ( self::$simulators === false) {
				add_settings_error(
					'simulator_server_url',
					'simulator_server_url_error',
					sprintf( __("The server '%s' is not responding or is not a G6K API server."), $input),
					'error'
				);
			}
		}
		return $input;
	}

	public static function primary_color() {
		$color = esc_attr ( get_option ( 'simulator-primary-color', '#2B4E6B' ) );
		printf(
			'<input type="color" name="simulator-primary-color" value="%s" />',
			$color
		);
		echo ' <span>' . $color . '</span>';
	}

	public static function secondary_color() {
		$color = esc_attr ( get_option ( 'simulator-secondary-color', '#C0C0C0' ) );
		printf(
			'<input type="color" name="simulator-secondary-color" value="%s" />',
			$color
		);
		echo ' <span>' . $color . '</span>';
	}

	public static function breadcrumb_color() {
		$color = esc_attr ( get_option ( 'simulator-breadcrumb-color', '#2B4E6B' ) );
		printf(
			'<input type="color" name="simulator-breadcrumb-color" value="%s" />',
			$color
		);
		echo ' <span>' . $color . '</span>';
	}

	public static function tab_color() {
		$color = esc_attr ( get_option ( 'simulator-tab-color', '#2B4E6B' ) );
		printf(
			'<input type="color" name="simulator-tab-color" value="%s" />',
			$color
		);
		echo ' <span>' . $color . '</span>';
	}

	public static function global_error_color() {
		$color = esc_attr ( get_option ( 'simulator-global-error-color', '#FF0000' ) );
		printf(
			'<input type="color" name="simulator-global-error-color" value="%s" />',
			$color
		);
		echo ' <span>' . $color . '</span>';
	}

	public static function global_warning_color() {
		$color = esc_attr ( get_option ( 'simulator-global-warning-color', '#800000' ) );
		printf(
			'<input type="color" name="simulator-global-warning-color" value="%s" />',
			$color
		);
		echo ' <span>' . $color . '</span>';
	}

	public static function field_error_color() {
		$color = esc_attr ( get_option ( 'simulator-field-error-color', '#FF0000' ) );
		printf(
			'<input type="color" name="simulator-field-error-color" value="%s" />',
			$color
		);
		echo ' <span>' . $color . '</span>';
	}

	public static function field_warning_color() {
		$color = esc_attr ( get_option ( 'simulator-field-warning-color', '#800000' ) );
		printf(
			'<input type="color" name="simulator-field-warning-color" value="%s" />',
			$color
		);
		echo ' <span>' . $color . '</span>';
	}

	public static function font_family() {
		printf(
			'<input type="text" name="simulator-field-font-family" value="%s" />',
			esc_attr ( get_option ( 'simulator-field-font-family', 'Arial, Verdana' ) )
		);
		echo '<br>' . esc_html__( 'Enter the font names separated by commas', 'simulator');
	}

	public static function font_size() {
		printf(
			'<input type="text" name="simulator-field-font-size" value="%s" />',
			esc_attr ( get_option ( 'simulator-field-font-size', '1em' ) )
		);
		echo '<br>' . esc_html__( 'Enter the font size as a number followed by a unit (ex: 1em, 14px, etc.)', 'simulator');
	}

	public static function html_markup() {
		$value = esc_attr ( get_option ( 'simulator-field-html-markup', 'fragment' ) );
		echo '<select name="simulator-field-html-markup">';
		foreach(['fragment', 'page'] as $markup) {
			echo '<option value="' . $markup . '"';
			if ($value == $markup) {
				echo ' selected="selected"';
			}
			echo '>';
			echo $markup == 'fragment'
				? esc_html__( 'html fragment only', 'simulator')
				: esc_html__( 'full html page', 'simulator');
			echo '</option>';
		}
		echo '</select>';
	}

	public static function insertion_mode() {
		$value = esc_attr ( get_option ( 'simulator-field-insertion-mode', 'block' ) );
		echo '<label>';
		echo '<input type="radio" name="simulator-field-insertion-mode" value="block"';
		if ($value == "block") {
			echo ' checked="checked"';
		}
		echo ' />';
		echo esc_html__( 'The HTML markup of the simulator will be rendered in a special custom block', 'simulator');
		echo '</label><br>';
		echo '<label>';
		echo '<input type="radio" name="simulator-field-insertion-mode" value="filter"';
		if ($value == "filter") {
			echo ' checked="checked"';
		}
		echo ' />';
		echo '</label>';
		printf(
			esc_html__( 'The HTML markup of the simulator will be added to the content using the filter : %s', 'simulator'), 
			'<br><code>$content = apply_filters ("simulator_content", $content, $simulator);</code>'
		);
	}

	public static function adding_bootstrap() {
		$value = esc_attr ( get_option ( 'simulator-field-adding-bootstrap', 0 ) );
		echo '<input type="checkbox" name="simulator-field-adding-bootstrap" value="1"';
		if ($value == "1") {
			echo ' checked="checked"';
		}
		echo ' />';
	}

	public static function bootstrap_version() {
		printf(
			'<input type="text" name="simulator-field-bootstrap-version" value="%s" />',
			esc_attr ( get_option ( 'simulator-field-bootstrap-version', '' ) )
		);
		echo '<br>' . esc_html__( 'Enter the three groups of digits of the version number separated by periods', 'simulator');
	}

	public static function validate_bootstrap_version( $input ) {
		$bootstrap = esc_attr ( get_option ( 'simulator-field-adding-bootstrap', 0 ) );
		if ($bootstrap != 1) {
			if ($input != '') {
				add_settings_error(
					'simulator_bootstrap_version',
					'simulator_bootstrap_version_error',
					__('The bootstrap version must be empty', 'simulator'),
					'error'
				);
			}
		} else {
			if ($input == '') {
				add_settings_error(
					'simulator_bootstrap_version',
					'simulator_bootstrap_version_error',
					__('The bootstrap version is required', 'simulator'),
					'error'
				);
			} elseif (!preg_match("/^\d+\.\d+\.\d+$/", $input)) {
				add_settings_error(
					'simulator_bootstrap_version',
					'simulator_bootstrap_version_error',
					__('The bootstrap version is not in the required format', 'simulator'),
					'error'
				);
			}
		}
		return $input;
	}

	public static function fields_observer($args) {
		$observer = esc_attr ( get_option ( $args['id'], '' ) );
		printf(
			'<input type="text" class="simulator-field-observer" name="%s" value="%s" />',
			$args['id'], $observer
		);
	}

	public static function validate_fields_observer( $input ) {
		if ($input != '') {
				if (!preg_match("/^([\-\w]+):[\-\w]+$/", $input, $m)) {
				add_settings_error(
					'simulator_fields_observer',
					'simulator_fields_observer_error',
					sprintf( __( "The data '%s' to observe is not in the required format", 'simulator'), $input ),
					'error'
				);
			}
			if (self::$simulators && ! in_array($m[1], self::$simulators)) {
				add_settings_error(
					'simulator_fields_observer',
					'simulator_fields_observer_error',
					sprintf( __("The simulator '%s' is not known by the API server"), $m[1] ),
					'error'
				);
			}
		}
		return $input;
	}

	public static function buttons_observer($args) {
		$observer = esc_attr ( get_option ( $args['id'], '' ) );
		printf(
			'<input type="text" class="simulator-button-observer" name="%s" value="%s" />',
			$args['id'], $observer
		);
	}

	public static function validate_buttons_observer( $input ) {
		if ($input != '') {
			if (!preg_match("/^([\-\w]+):[\-\w]+$/", $input, $m)) {
				add_settings_error(
					'simulator_buttons_observer',
					'simulator_buttons_observer_error',
					sprintf( __( "The button '%s' to observe is not in the required format", 'simulator'), $input ),
					'error'
				);
			}
			if (self::$simulators && ! in_array($m[1], self::$simulators)) {
				add_settings_error(
					'simulator_buttons_observer',
					'simulator_buttons_observer_error',
					sprintf( __("The simulator '%s' is not known by the API server"), $m[1] ),
					'error'
				);
			}
		}
		return $input;
	}

}
