<?php

/*
The MIT License (MIT)

Copyright (c) 2021 Jacques Archimède

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

const SIMULATOR_VERSION = '1.0.0';

class Simulator {

	private static $initiated = false;

	public static function init() {
		if ( ! self::$initiated ) {
			self::init_hooks();
		}
	}

	public static function init_hooks() {
		self::$initiated = true;
		add_action( 'wp_enqueue_scripts', function () {
			wp_enqueue_style( 'simulator-style', SIMULATOR__ASSETS_URL . 'style.css' );
			wp_enqueue_script( 'simulator-script', SIMULATOR__ASSETS_URL . 'script.js', [], false, true );
		});
		$insertionMode = esc_attr ( get_option ( 'simulator-field-insertion-mode', 'block' ) );
		if ($insertionMode == 'block') {
			self::register_block();
		} else {
			add_rewrite_rule( 
				'^([^/]+)([/]?)(.*)', 
				'index.php?simulator=$matches[1]', 
				'top'
			);
			add_filter('query_vars', function( $vars ){
				$vars[] = 'simulator'; 
				return $vars;
			});
			add_filter ( 'simulator_content', [ 'Simulator', 'content' ], 10, 2 );
		}
	}

	public static function plugin_activation() {
		if ( version_compare( $GLOBALS['wp_version'], SIMULATOR__MINIMUM_WP_VERSION, '<' ) ) {
			load_plugin_textdomain( 'simulator', false, basename( dirname( dirname( __FILE__ ) ) ) . '/languages/' );
			$message = '<strong>'.sprintf(esc_html__( 'The simulator plugin %s requires WordPress %s or higher.', 'simulator'), SIMULATOR_VERSION, SIMULATOR__MINIMUM_WP_VERSION ).'</strong> '.sprintf(__('Please <a href="%1$s">upgrade WordPress</a> to a current version', 'simulator'), 'https://codex.wordpress.org/Upgrading_WordPress');
		} elseif ( ! empty( $_SERVER['SCRIPT_NAME'] ) && false !== strpos( $_SERVER['SCRIPT_NAME'], '/wp-admin/plugins.php' ) ) {
			add_option( 'Activated_Simulator', true );
		}
	}

	public static function plugin_deactivation( ) {
	}

	/**
	 * Registers the dynamic server side block JS script and its styles
	 * @return void
	 */
	public function register_block () {

		$block_name = 'block-render';

		$block_namespace = 'simulator/' . $block_name;

		$script_slug = 'simulator-' . $block_name . '-script';
		$style_slug = 'simulator-' . $block_name . '-style';
		$editor_style_slug = 'simulator-' . $block_name . '-editor-style';

		// The JS block script
		 wp_register_script( 
			$script_slug, 
			SIMULATOR__ASSETS_URL . 'block.js', 
			['wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor'], // Required scripts for the block
			SIMULATOR_VERSION
		);

		// The block style for the editor only
		wp_register_style(
			$editor_style_slug,
			SIMULATOR__ASSETS_URL . 'editor.css', 
			['wp-edit-blocks'], // Style for the editor
			SIMULATOR_VERSION
		);
		
		// Registering the block
		register_block_type(
			$block_namespace,  // Block name with namespace
			[
				'style' => $style_slug,
				'editor_style' => $editor_style_slug,
				'editor_script' => $script_slug,
				'render_callback' => ['Simulator', 'block_content'],
				'attributes' => [
					'simulator' => [
						'type' => 'string',
						'default' => 'demo'
					]
				]
			]
		);
		wp_set_script_translations( $script_slug, 'simulator', SIMULATOR__LANGUAGES_DIR );

	}

	public static function block_content($attr) {
		return self::get_html( $attr['simulator'] );
	}

	public static function content($content, $simulator) {
		return $content . self::get_html( $simulator );
	}

	public static function get_html( $simulator ) {
		$body = [
			'markup' => esc_attr ( get_option ( 'simulator-field-html-markup', 'fragment' ) ), // 'fragment' or 'page'
			'primaryColor' => esc_attr ( get_option ( 'simulator-primary-color', '#2B4E6B' ) ), // optional
			'secondaryColor' => esc_attr ( get_option ( 'simulator-secondary-color', '#CCC' ) ), // optional
			'fontFamily' => esc_attr ( get_option ( 'simulator-field-font-family', 'Arial, Verdana' ) ), // optional
			'fontSize' => esc_attr ( get_option ( 'simulator-field-font-size', '1em' ) ), // optional
			'breadcrumbColor' => esc_attr ( get_option ( 'simulator-breadcrumb-color', '#2B4E6B' ) ), // optional
			'tabColor' => esc_attr ( get_option ( 'simulator-tab-color', '#2B4E6B' ) ), // optional
			'globalErrorColor' => esc_attr ( get_option ( 'simulator-global-error-color', '#FF0000' ) ), // optional
			'globalWarningColor' => esc_attr ( get_option ( 'simulator-global-warning-color', '#800000' ) ), // optional
			'fieldErrorColor' => esc_attr ( get_option ( 'simulator-field-error-color', '#FF0000' ) ), // optional
			'fieldWarningColor' => esc_attr ( get_option ( 'simulator-field-warning-color', '#800000' ) ), // optional
		];
		for ($i = 1; $i <= 5; $i++) {
			$observer = esc_attr ( get_option ( 'simulator-field-observer' . $i, '' ) );
			if ($observer != '') {
				[$simu, $field] = explode(":", $observer);
				if ($simu == $simulator) {
					$body[$field] = 'ResultObserver.field';
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$observer = esc_attr ( get_option ( 'simulator-button-observer' . $i, '' ) );
			if ($observer != '') {
				[$simu, $button] = explode(":", $observer);
				if ($simu == $simulator) {
					$body[$button] = 'ResultObserver.button';
				}
			}
		}
		if (esc_attr ( get_option ( 'simulator-field-adding-bootstrap', 0 ) ) == 1) {
			$body['bootstrap'] = esc_attr ( get_option ( 'simulator-field-bootstrap-version', '' ) ); // bootstrap version
		}
		$args = [
			'body'        => $body,
			'timeout'     => '5',
			'redirection' => '5',
			'httpversion' => '1.0',
			'sslverify'   => false,
			'blocking'    => true,
			'headers'     => [],
			'cookies'     => []
		];
		$url = esc_attr ( get_option ( 'simulator-server-url', '' ) ) . "/" . $simulator . "/api/html";
		preg_match("|^(https?)|", wp_guess_url(), $m);
		$url = preg_replace("/^https?/", $m[1], $url);
		$request = wp_remote_post( $url, $args );
		if ( is_wp_error( $request ) || wp_remote_retrieve_response_code( $request ) != 200 ) {
			return( print_r( $request, true ) );
		}
		$response = wp_remote_retrieve_body( $request );
		return $response;
	}
}
