(function (document, window) {
	'use strict';

	function hideAllPanes (simulatorTabs) {
		simulatorTabs.forEach( function(tab) {
			var pane = document.querySelector(tab.getAttribute('href'));
			if (pane !== null) {
				pane.classList.remove('nav-pane-active');
			}
			tab.classList.remove('nav-tab-active');
		});
	}

	function manageTabs() {
		var simulatorTabs = document.querySelectorAll('#simulator-settings-tabs a');
		if (null !== simulatorTabs) {
			simulatorTabs.forEach( function(tab) {
				tab.addEventListener('click', function(e) {
					e.preventDefault();
					hideAllPanes (simulatorTabs);
					this.classList.add('nav-tab-active');
					var pane = document.querySelector(this.getAttribute('href'));
					if (pane !== null) {
						pane.classList.add('nav-pane-active');
						var inputs = pane.querySelectorAll('input, select, textarea');
						if (inputs.length > 0) {
							inputs[0].focus();
						}
					}
				});
			});
		}
	}

	function manageColors() {
		var colorInputs = document.querySelectorAll("#simulator-settings-colors input[type='color']");
		if (null !== colorInputs) {
			colorInputs.forEach( function(color) {
				color.addEventListener('change', function(e) {
					this.nextElementSibling.textContent = this.value;
				});
			});
		}
	}

	function manageAddingBootstrapClasses() {
		var addingBootstrap = document.querySelector("#simulator-settings-markup input[name='simulator-field-adding-bootstrap']");
		if (null !== addingBootstrap) {
			addingBootstrap.addEventListener('change', function(e) {
				var bootstrapVersion = this.closest('tr').nextElementSibling;
				if (this.checked) {
					bootstrapVersion.classList.remove('simulator-settings-field-hidden');
				} else {
					bootstrapVersion.classList.add('simulator-settings-field-hidden');
				}
			});
			addingBootstrap.dispatchEvent(new Event('change'));
		}
	}

	window.addEventListener('DOMContentLoaded', function(event) {
		manageTabs();
		manageColors();
		manageAddingBootstrapClasses();
	});

}(document, window));
