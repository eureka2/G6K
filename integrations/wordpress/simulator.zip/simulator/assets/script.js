(function (global) {
	"use strict";

	function ResultObserver() {}
	
	ResultObserver.field = function(name, value) {
		console.log(name + ' => ' + value);
	}
	
	ResultObserver.button = function(name, what, f0r, uri) {
		console.log(name + ' => ' + what + ':' + f0r);
	}

	global.ResultObserver = ResultObserver;
}(this));