/**
The MIT License (MIT)

Copyright (c) 2021 Jacques Archimède

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/

// Required components
const { __ } = wp.i18n;
const { registerBlockType } = wp.blocks;
const { RichText } = wp.editor;
const { TextControl } = wp.components;

registerBlockType(
	'simulator/block-render', // Name of the block with a required name space
	{
		title: __('Simulator render block', 'simulator'), // Title, displayed in the editor
		icon: 'calculator', // Icon, from WP icons
		category: 'common', // Block category, where the block will be added in the editor
	
		/**
		 * Object with all binding elements between the view HTML and the functions
		 * It lets you bind data from DOM elements and storage attributes
		 */
		attributes: {
			simulator: {
				type: 'string'
			},
		},

		/**
		 * edit function
		 * 
		 * Makes the markup for the editor interface.
		 * 
		 * @param object props Let's you bind markup and attributes as well as other controls
		 * 
		 * @return JSX ECMAScript Markup for the editor 
		 */
		edit ( props ) {

			var simulator = props.attributes.simulator // To bind attribute simulator

			function onChangeSimulator ( content ) {
				props.setAttributes({simulator: content})
			}

			return wp.element.createElement(
				'div',
				{ id: 'block-dynamic-box' },
				' ',
				wp.element.createElement(
					'h1',
					null,
					__('Simulator render block', 'simulator')
				),
				wp.element.createElement(
					'p',
					null,
					__('This block contains the HTML tags of the simulator whose name is entered below', 'simulator')
				),
				wp.element.createElement(
					'label',
					null,
					__('Simulator name:', 'simulator')
				),
				wp.element.createElement(TextControl, {
					className: props.className // Automatic class: gutenberg-blocks-sample-block-editable
					, onChange: onChangeSimulator // onChange event callback
					, value: simulator // Binding
					, placeholder: __('Enter the simulator name', 'simulator')
				})
 			);
		},
 
		/**
		 * save function
		 * 
		 * Makes the markup that will be rendered on the site page
		 * 
		 * In this case, it does not render, because this block is rendered on server side
		 * 
		 * @param object props Let's you bind markup and attributes as well as other controls
		 * @return JSX ECMAScript Markup for the site
		 */
		save ( props ) {
			return null; // See PHP side. This block is rendered on PHP.
		},
	} 
);