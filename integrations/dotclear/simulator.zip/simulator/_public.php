<?php

global $core;

$core->addBehavior('publicHeadContent', ['simulator', 'publicHeadContent']);
$core->addBehavior('publicBeforeContentFilter', ['simulator', 'publicBeforeContentFilter']);

$core->tpl->addValue('simulator', ['simulatorTpl','render']);
 
class simulatorTpl {

	public static function render($args) {
		$simulator = $args->offsetGet('name');
		if ($simulator) {
			return simulator::render($simulator);
		}
	}
}
