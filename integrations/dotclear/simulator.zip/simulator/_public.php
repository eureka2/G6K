<?php

global $core;

$core->addBehavior('publicHeadContent', ['simulator', 'publicHeadContent']);
$core->addBehavior('publicBeforeContentFilter', ['simulator', 'publicBeforeContentFilter']);
