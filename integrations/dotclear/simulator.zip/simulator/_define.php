<?php
if (!defined('DC_RC_PATH')) {return;}
 
$this->registerModule(
	'Simulator',                        // Name
	'G6K simulator integration plugin', // Description
	'Eureka2',                          // Author
	'1.0',                              // Version
	array(                              // Properties
		'permissions' => 'usage,contentadmin',
		'type'        => 'plugin'
	)
);