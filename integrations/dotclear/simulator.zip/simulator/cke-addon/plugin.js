dotclear.ck_simulator = getData('ck_editor_simulator');

CKEDITOR.plugins.add('simulator', {
	requires: "dialog",
	init: function(editor) {
		editor.addCommand('simulatorCommand', new CKEDITOR.dialogCommand( 'simulatorDialog' ));
		CKEDITOR.dialog.add( 'simulatorDialog', this.path + 'dialogs/simulator.js' );
		editor.ui.addButton("simulator", {
			label: dotclear.ck_simulator.title,
			icon: this.path + 'icons/icon.png',
			command: 'simulatorCommand',
			toolbar: 'insert'
		});
	}
});
