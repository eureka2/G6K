CKEDITOR.dialog.add( 'simulatorDialog', function( editor ) {
	return {
		title: dotclear.ck_simulator.title,
		minWidth: 400,
		minHeight: 200,

		contents: [
			{
				id: 'tab-simulator',
				label: dotclear.ck_simulator.name,
				elements: [{
					type: 'text',
					id: 'name',
					label: dotclear.ck_simulator.name,
					validate: CKEDITOR.dialog.validate.functions(
									CKEDITOR.dialog.validate.notEmpty(),
									CKEDITOR.dialog.validate.regex(/^[\w-]+$/),
									dotclear.ck_simulator.simulator_invalid
								)
				}]
			}
		],
		onOk: function() {
			var dialog = this;

			var shortcode = editor.document.createElement( 'p' );
			shortcode.setText( "[simulator name='" + dialog.getValueOf( 'tab-simulator', 'name' ) + "']" );
			editor.insertElement( shortcode );
		}
	};
});
