<?php
if (!defined('DC_RC_PATH')) {return;}
 
global $core;
 
# enregistrer l'URL "simulator"
$core->url->register(
	'simulator',                 // le type d'URL, utilisé par Dotclear pour l'identifier
	'simulator',                 // l'URL de base de la page
	'^simulator(?:/(.+))?$',     // l'expression régulière de l'URL de la page
	['simulatorDocument','page'] // un callback, un nom de fonction ou un tableau avec le nom d'une classe et d'une fonction à appeler lorsque cette URL est demandée
);

global $__autoload;
$__autoload['simulator'] = dirname(__FILE__).'/inc/class.simulator.php';