i18n = {
	"Simulator.BASE_URL_REQUIRED": "The base url of the server is required",
	"Simulator.BASE_URL_INVALID": "The base url of the server is invalid",
	"Simulator.BASE_URL_ACCESS": "Access to the server '%s' in progress ....",
	"Simulator.BASE_URL_NOT_RESPONDING": "The server '%s' is not responding or is not a G6K API server.",
	"Simulator.FONTSIZE_INVALID": "The font size '%s' is invalid.",
	"Simulator.BOOTSTRAP_VERSION_REQUIRED": "The bootstrap version is required",
	"Simulator.BOOTSTRAP_VERSION_INVALID": "The bootstrap version is not in the required format",
	"Simulator.BOOTSTRAP_VERSION_NOT_EMPTY": "The bootstrap version must be empty",
	"Simulator.SIMULATOR_UNKNOWN": "The simulator '%s' is not known by the API server",
	"Simulator.DATA_OBSERVER_INVALID": "The data '%s' to observe is not in the required format",
	"Simulator.BUTTON_OBSERVER_INVALID": "The button '%s' to observe is not in the required format"
};
