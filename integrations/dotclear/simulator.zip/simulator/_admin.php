<?php
if (!defined('DC_CONTEXT_ADMIN')) {return;}
 
global $core;

if (!$core->auth->isSuperAdmin()) {return;}

__('Simulator'); /* Name */
__('G6K simulator integration plugin'); /* Description */

# ajouter le plugin dans la liste des plugins du menu de l'administration
$_menu['Plugins']->addItem(
	# nom du lien (en anglais)
	__('Simulator'),
	# URL de base de la page d'administration
	'plugin.php?p=simulator',
	# URL de l'image utilisée comme icône
	'index.php?pf=simulator/icon.png',
	# expression régulière de l'URL de la page d'administration
	preg_match('/plugin.php\?p=simulator(&.*)?$/', $_SERVER['REQUEST_URI']),
	# persmissions nécessaires pour afficher le lien
	$core->auth->check('usage,contentadmin',$core->blog->id)
);

$core->addBehavior('adminPostEditor', 'adminPostEditor');
$core->addBehavior('ckeditorExtraPlugins', 'ckeditorExtraPlugins');

function adminPostEditor($editor = '', $context = '', array $tags = [], $syntax = '') {
	global $core;

	$core->blog->settings->addNamespace('simulator');
	return dcPage::jsJson('ck_editor_simulator', [
		'title'             => __('Insert simulator'),
		'name'              => __('Simulator name'),
		'simulator_invalid' => __('Simulator name is empty or invalid.'),
	]);
}

function ckeditorExtraPlugins(ArrayObject $extraPlugins, $context) {
	$extraPlugins[] = [
		'name' => 'simulator',
		'button' => 'simulator',
		'url' => DC_ADMIN_URL.'index.php?pf=simulator/cke-addon/'
	];
}