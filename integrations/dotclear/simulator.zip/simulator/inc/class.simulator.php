<?php

class simulator {

	public static function publicHeadContent($core) {
		echo dcUtils::cssLoad($core->blog->getPF('simulator/style/style.css'));
		echo dcUtils::jsLoad($core->blog->getPF('simulator/js/script.js'));
	}

	public static function publicBeforeContentFilter ($core, $tag, &$args){
		if ($tag == "EntryContent") {
			$content = $args[0];
			if (preg_match("/\[simulator name='([^']+)'\]/", $content, $m )) {
				$args[0] = str_replace($m[0], self::render($m[1]), $content);
			}
		}
	}

	private static function url($simulator, $baseUrl = null) {

		$settings =& $GLOBALS['core']->blog->settings->simulator;

		if (null === $baseUrl) {
			$baseUrl = $settings->simulator_baseurl;
		}
		$host = http::getHost();
		if (preg_match("|^(https?)://|", $host, $m)) {
			$baseUrl = preg_replace("|^https?|", $m[1], $baseUrl);
		}
		return $baseUrl . '/' . $simulator . '/api';
	}

	public static function attributes(string $simulator = null) {
		$url = self::url($simulator) . '/json';
		[$ok, $api] = self::fetch($url);
		if ($ok) {
			$api = json_decode($api, true);
			return $api['data']['attributes'];
		} else {
			return [ 'title' => $api, 'description' => $api ];
		}
	}

	public static function simulators($baseUrl = null) {
		$url = self::url('simulators', $baseUrl);
		[$ok, $api] = self::fetch($url);
		$simulators = [];
		if ($ok) {
			$api = json_decode($api, true);
			$data = $api['included']['data'];
			foreach($data as $simu) {
				$simulators[] = $simu['id'];
			}
			return $simulators;
		}
		return false;
	}

	private static function options($simulator) {

		$settings =& $GLOBALS['core']->blog->settings->simulator;

		$options = [
			'markup' => $settings->simulator_markup ?? 'fragment', // 'fragment' or 'page'
			'primaryColor' => $settings->simulator_primary_color ?? '#2b4e6b', // optional
			'secondaryColor' => $settings->simulator_secondary_color ?? '#c0c0c0', // optional
			'breadcrumbColor' => $settings->simulator_breadcrumb_color ?? '#2b4e6b', // optional
			'tabColor' => $settings->simulator_tab_color ?? '#2b4e6b', // optional
			'globalErrorColor' => $settings->simulator_global_error_color ?? '#ff0000', // optional
			'globalWarningColor' => $settings->simulator_global_warning_color ?? '#800000', // optional
			'fieldErrorColor' => $settings->simulator_field_error_color ?? '#ff0000', // optional
			'fieldWarningColor' => $settings->simulator_field_warning_color ?? '#800000', // optional
			'fontFamily' => $settings->simulator_font_family ?? 'Arial, Verdana', // optional
			'fontSize' => $settings->simulator_font_size ?? '1em', // optional
		];
		$bootstrap = $settings->simulator_adding_bootstrap_classes ?? '0';
		if ('1' === $bootstrap) {
			$options['bootstrap'] = $settings->simulator_bootstrap_version ?? ''; // bootstrap version;
			$options['addBootstrapStylesheet'] = $settings->simulator_adding_bootstrap_stylesheet ?? '0' == '1' ? 'true' : 'false';
			$options['addBootstrapScript'] = $settings->simulator_adding_bootstrap_library ?? '0' == '1' ? 'true' : 'false'; 
			$options['addJQueryScript'] = $settings->simulator_adding_jquery_library ?? '0'  == '1' ? 'true' : 'false';
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_data' . $i . '_observer';
			$observer = $settings->$field ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		for ($i = 1; $i <= 5; $i++) {
			$field = 'simulator_button' . $i . '_observer';
			$observer = $settings->$field ?? '';
			if ($observer != '') {
				if (preg_match("/^([\-\w]+):([\-\w]+)$/", $observer, $m)) {
					if ($m[1] == $simulator) {
						$options[$m[2]] = 'ResultObserver.field';
					}
				}
			}
		}
		return $options;
	}

	public static function render($simulator) {
		$options = self::options($simulator); 
		[$ok, $markup] = self::fetch(self::url($simulator) . '/html', $options);
		return $markup;
	}

	private static function fetch(string $url, array $options = []) {
		if (($http = netHttp::initClient($url, $path)) !== false) {
			if ($http->post($path, $options)) {
				$ok = $http->getStatus() == 200;
				$result = $http->getContent();
			} else {
				$ok = false;
				$result =  "Oops, something went wrong. Please try again " . $url . ' # ' . $http->getContent();
			}
		} else {
			$ok = false;
			$result =  "Oops, something went wrong. Please verify " . $url;
		}
		return [$ok, $result];
	}
}