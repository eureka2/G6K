<?php
if (!defined('DC_CONTEXT_ADMIN')) {return;}
 
global $core;

if (!$core->auth->isSuperAdmin()) {return;}

$default_tab = 'g6k-api-server-tab';
 
if (isset($_REQUEST['tab'])) {
	$default_tab = $_REQUEST['tab'];
}

$core->blog->settings->addNameSpace('simulator');
$settings =& $core->blog->settings->simulator;
if (!empty($_POST['save-configuration'])) {
	try {
		$settings->put('simulator_baseurl', $_POST['simulator_baseurl'], 'string', 'Base url of the server');
		$settings->put('simulator_markup', $_POST['simulator_markup'], 'string', 'HTML Markup');
		$settings->put('simulator_adding_bootstrap_classes', !empty($_POST['simulator_adding_bootstrap_classes']), 'boolean', 'Adding Bootstrap classes');
		$settings->put('simulator_bootstrap_version', $_POST['simulator_bootstrap_version'], 'string', 'Bootstrap version');
		$settings->put('simulator_adding_bootstrap_stylesheet', !empty($_POST['simulator_adding_bootstrap_stylesheet']), 'boolean', 'Adding Bootstrap stylesheet');
		$settings->put('simulator_adding_bootstrap_library', !empty($_POST['simulator_adding_bootstrap_library']), 'boolean', 'Adding Bootstrap library');
		$settings->put('simulator_adding_jquery_library', !empty($_POST['simulator_adding_jquery_library']), 'boolean', 'Adding jQuery library');
		$settings->put('simulator_primary_color', $_POST['simulator_primary_color'], 'string', 'Primary color');
		$settings->put('simulator_secondary_color', $_POST['simulator_secondary_color'], 'string', 'Secondary color');
		$settings->put('simulator_breadcrumb_color', $_POST['simulator_breadcrumb_color'], 'string', 'Breadcrumb color');
		$settings->put('simulator_tab_color', $_POST['simulator_tab_color'], 'string', 'Tab color');
		$settings->put('simulator_global_error_color', $_POST['simulator_global_error_color'], 'string', 'Global error color');
		$settings->put('simulator_global_warning_color', $_POST['simulator_global_warning_color'], 'string', 'Global warning color');
		$settings->put('simulator_field_error_color', $_POST['simulator_field_error_color'], 'string', 'Field error color');
		$settings->put('simulator_field_warning_color', $_POST['simulator_field_warning_color'], 'string', 'Field warning color');
		$settings->put('simulator_font_family', $_POST['simulator_font_family'], 'string', 'Font family');
		$settings->put('simulator_font_size', $_POST['simulator_font_size'], 'string', 'Font size');
		for ($i = 1; $i <= 5; $i++) {
			$settings->put(
				sprintf('simulator_data%d_observer', $i),
				$_POST[sprintf('simulator_data%d_observer', $i)], 
				'string', 
				sprintf('Data %d', $i)
			);
			$settings->put(
				sprintf('simulator_button%d_observer', $i),
				$_POST[sprintf('simulator_button%d_observer', $i)], 
				'string', 
				sprintf('Button %d', $i)
			);
		}
		dcPage::addSuccessNotice(__('Simulator settings has been successfully updated.'));
		http::redirect($p_url.'&tab=' . $default_tab . '&save-configuration=1');
	} catch (Exception $e) {
		$core->error->add($e->getMessage());
	}
}

if (isset($_GET['save-configuration']))
{
	$msg = __('Configuration successfully updated.');
}
?>

<html>
<head>
	<title><?php echo(__('Simulator')); ?></title>
	<?php 
		$lang = $core->auth->getInfo('user_lang');
		echo dcPage::jsPageTabs($default_tab) .
		dcPage::jsLoad(dcPage::getPF('simulator/js/lang/' . substr($lang, 0, 2) . '.js')) .
		dcPage::jsLoad(dcPage::getPF('simulator/js/settings.js')) .
		dcPage::cssLoad(dcPage::getPF('simulator/style/settings.css'))
		; ?>
</head>
<body>
	<h2><?php echo html::escapeHTML($core->blog->name).' &rsaquo; ' . __('Simulator'); ?></h2>
	<form class="simulator-settings-form" method="post" action="<?php echo($p_url); ?>">
		<p><?php echo $core->formNonce(); ?></p>
		<div class="multi-part" id="g6k-api-server-tab" title="<?php echo __('G6K API Server'); ?>">
			<div class="simulator-settings-field">
				<p>
					<label class="classic required">
					<?php echo(__('Base url of the server') . form::field('simulator_baseurl',40,255, $settings->simulator_baseurl, 'maximal')); ?>
					</label>
				</p>
				<p class="form-note">
					<?php echo(__('Enter the absolute url pointing to the public directory of the API server')); ?>
				</p>
				<div class="simulator-alert simulator-settings-field-hidden"></div>
			</div>
		</div>
		<div class="multi-part" id="markup-tab" title="<?php echo __('Markup'); ?>">
			<div class="simulator-settings-field">
				<p>
					<label class="classic">
					<?php echo(__('HTML Markup') . form::combo('simulator_markup', [
						__('html fragment only') => 'fragment',
						__('full html page') => 'page'
					], $settings->simulator_markup)
					); ?>
					</label>
				</p>
			</div>
			<fieldset>
				<legend><?php echo(__('Bootstrap')); ?></legend>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(form::checkbox('simulator_adding_bootstrap_classes',
							'1',
							$settings->simulator_adding_bootstrap_classes).
							' '.__('Adding Bootstrap classes')
						); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Check this box if you want bootstrap classes to be added to the relevant markup allowing bootstrap styles to apply')); ?>
					</p>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(__('Bootstrap version') . form::field('simulator_bootstrap_version',40,255, $settings->simulator_bootstrap_version, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the three groups of digits of the version number separated by periods')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(form::checkbox('simulator_adding_bootstrap_stylesheet',
							'1',
							$settings->simulator_adding_bootstrap_stylesheet).
							' '.__('Adding Bootstrap stylesheet')
						); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('if this field is checked, the Bootstrap stylesheet will be loaded by the API from bootstrapcdn.')); ?>
					</p>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(form::checkbox('simulator_adding_bootstrap_library',
							'1',
							$settings->simulator_adding_bootstrap_library).
							' '.__('Adding Bootstrap library')
						); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('if this field is checked, Bootstrap library will be loaded by the API from bootstrapcdn.')); ?>
					</p>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(form::checkbox('simulator_adding_jquery_library',
							'1',
							$settings->simulator_adding_jquery_library).
							' '.__('Adding jQuery library')
						); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('if this field is checked, the jQuery library will be loaded by the API from code.jquery.com.')); ?>
					</p>
				</div>
			</fieldset>
		</div>
		<div class="multi-part" id="colors-tab" title="<?php echo __('Colors'); ?>">
			<div class="simulator-settings-field">
				<p>
					<label for="simulator_primary_color" class="classic"><?php echo __('Primary color'); ?></label>
					<?php echo form::color('simulator_primary_color', [ 'default' => $settings->simulator_primary_color ?? '#2b4e6b']); ?>
					<span class="simulator_color_value"><span>
				</p>
			</div>
			<div class="simulator-settings-field">
				<p>
					<label for="simulator_secondary_color" class="classic"><?php echo __('Secondary color'); ?></label>
					<?php echo form::color('simulator_secondary_color', [ 'default' => $settings->simulator_secondary_color ?? '#c0c0c0']); ?>
					<span class="simulator_color_value"><span>
				</p>
			</div>
			<div class="simulator-settings-field">
				<p>
					<label for="simulator_breadcrumb_color" class="classic"><?php echo __('Breadcrumb color'); ?></label>
					<?php echo form::color('simulator_breadcrumb_color', [ 'default' => $settings->simulator_breadcrumb_color ?? '#2b4e6b']); ?>
					<span class="simulator_color_value"><span>
				</p>
			</div>
			<div class="simulator-settings-field">
				<p>
					<label for="simulator_tab_color" class="classic"><?php echo __('Tab color'); ?></label>
					<?php echo form::color('simulator_tab_color', [ 'default' => $settings->simulator_tab_color ?? '#2b4e6b']); ?>
					<span class="simulator_color_value"><span>
				</p>
			</div>
			<div class="simulator-settings-field">
				<p>
					<label for="simulator_global_error_color" class="classic"><?php echo __('Global error color'); ?></label>
					<?php echo form::color('simulator_global_error_color', [ 'default' => $settings->simulator_global_error_color ?? '#ff0000']); ?>
					<span class="simulator_color_value"><span>
				</p>
			</div>
			<div class="simulator-settings-field">
				<p>
					<label for="simulator_global_warning_color" class="classic"><?php echo __('Global warning color'); ?></label>
					<?php echo form::color('simulator_global_warning_color', [ 'default' => $settings->simulator_global_warning_color ?? '#800000']); ?>
					<span class="simulator_color_value"><span>
				</p>
			</div>
			<div class="simulator-settings-field">
				<p>
					<label for="simulator_field_error_color" class="classic"><?php echo __('Field error color'); ?></label>
					<?php echo form::color('simulator_field_error_color', [ 'default' => $settings->simulator_field_error_color ?? '#ff0000']); ?>
					<span class="simulator_color_value"><span>
				</p>
			</div>
			<div class="simulator-settings-field">
				<p>
					<label for="simulator_field_warning_color" class="classic"><?php echo __('Field warning color'); ?></label>
					<?php echo form::color('simulator_field_warning_color', [ 'default' => $settings->simulator_field_warning_color ?? '#800000']); ?>
					<span class="simulator_color_value"><span>
				</p>
			</div>
		</div>
		<div class="multi-part" id="font-tab" title="<?php echo __('Font'); ?>">
			<div class="simulator-settings-field">
				<p>
					<label class="classic">
					<?php echo(__('Font family') . form::field('simulator_font_family',40,255, $settings->simulator_font_family, 'maximal')); ?>
					</label>
				</p>
				<p class="form-note">
					<?php echo(__('Enter the font names separated by commas')); ?>
				</p>
			</div>
			<div class="simulator-settings-field">
				<p>
					<label class="classic">
					<?php echo(__('Font size') . form::field('simulator_font_size',40,255, $settings->simulator_font_size, 'maximal')); ?>
					</label>
				</p>
				<p class="form-note">
					<?php echo(__('Enter the font size as a number followed by a unit (ex: 1em, 14px, etc.)')); ?>
				</p>
				<div class="simulator-alert simulator-settings-field-hidden"></div>
			</div>
		</div>
		<div class="multi-part" id="observers-tab" title="<?php echo __('Observers'); ?>">
			<fieldset>
				<legend><?php echo(__('Data')); ?></legend>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Data %d'), 1) . form::field('simulator_data1_observer',40,255, $settings->simulator_data1_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the data to observe with the following format: &lt;simulator name>:&lt;data name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Data %d'), 2) . form::field('simulator_data2_observer',40,255, $settings->simulator_data2_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the data to observe with the following format: &lt;simulator name>:&lt;data name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Data %d'), 3) . form::field('simulator_data3_observer',40,255, $settings->simulator_data3_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the data to observe with the following format: &lt;simulator name>:&lt;data name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Data %d'), 4) . form::field('simulator_data4_observer',40,255, $settings->simulator_data4_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the data to observe with the following format: &lt;simulator name>:&lt;data name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Data %d'), 5) . form::field('simulator_data5_observer',40,255, $settings->simulator_data5_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the data to observe with the following format: &lt;simulator name>:&lt;data name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
			</fieldset>
			<fieldset>
				<legend><?php echo(__('Buttons')); ?></legend>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Button %d'), 1) . form::field('simulator_button1_observer',40,255, $settings->simulator_button1_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the button to observe with the following format: &lt;simulator name>:&lt;button name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Button %d'), 2) . form::field('simulator_button2_observer',40,255, $settings->simulator_button2_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the button to observe with the following format: &lt;simulator name>:&lt;button name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Button %d'), 3) . form::field('simulator_button3_observer',40,255, $settings->simulator_button3_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the button to observe with the following format: &lt;simulator name>:&lt;button name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Button %d'), 4) . form::field('simulator_button4_observer',40,255, $settings->simulator_button4_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the button to observe with the following format: &lt;simulator name>:&lt;button name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
				<div class="simulator-settings-field">
					<p>
						<label class="classic">
						<?php echo(sprintf(__('Button %d'), 5) . form::field('simulator_button5_observer',40,255, $settings->simulator_button5_observer, 'maximal')); ?>
						</label>
					</p>
					<p class="form-note">
						<?php echo(__('Enter the button to observe with the following format: &lt;simulator name>:&lt;button name>')); ?>
					</p>
					<div class="simulator-alert simulator-settings-field-hidden"></div>
				</div>
			</fieldset>
		</div>
		<p><input type="submit" name="save-configuration" value="<?php echo __('Save'); ?>" /></p>
	</form>
</body>
</html>